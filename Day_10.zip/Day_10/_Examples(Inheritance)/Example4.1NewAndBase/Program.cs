﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4._1NewAndBase
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Сокрытие имен");

            double Wvehicle, W;

            Truck truck = new Truck(5.6, 3.5);
            truck.GetInfo(out Wvehicle, out W);

            Console.WriteLine("Масса автомобиля: {0}, масса груза: {1}", Wvehicle, W);

            Console.ReadKey();
        }
    }

    class Vehicle
    {
        protected double weight=0;
    }

    class Truck : Vehicle
    {
        // поле скрывает одноименное поле базового класса
        new private double weight; 

        public Truck(double Wvehicle, double W)
        {   // обращение к переменной из базового класса 
            // с использованием ключевого слова base
            base.weight = Wvehicle;
            weight = W;
        }

        public void GetInfo(out double Wvehicle, out double W)   
        {
             // обращение к переменной из базового класса 
             // с использованием ключевого слова base
            Wvehicle=base.weight;
            W = weight;
        }

    }
}
