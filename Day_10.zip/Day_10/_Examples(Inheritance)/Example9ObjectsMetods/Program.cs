﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example9ObjectsMetods
{
    class Program
    {
        static void Main(string[] args)
        {

            Vehicle vehicle = new Vehicle("Т/С", "общее", 50);
            Console.WriteLine(vehicle.ToString());
            Console.WriteLine(vehicle.GetType());
            Console.WriteLine(vehicle.GetHashCode());
            
            Vehicle vehicle2 = new Vehicle("Т/С", "общее", 50);
            Console.WriteLine(vehicle.Equals(vehicle2));

            Vehicle vehicle3 = vehicle;
            Console.WriteLine(vehicle.Equals(vehicle3));

            Console.WriteLine(Object.Equals(vehicle, vehicle2));
            Console.WriteLine(Object.Equals(vehicle, vehicle3));

            Console.WriteLine(Object.ReferenceEquals(vehicle, vehicle2));
            Console.WriteLine(Object.ReferenceEquals(vehicle, vehicle3));

            
  

            Console.ReadKey();
        }
    }

    class Vehicle
    {
        protected string TypeV;           // тип транспортного средства 
        protected string Name;            // название транспортного средства 
        protected double V;               // скорость транспортного средства 

        public Vehicle(string T, string N, double V)
        {
            this.TypeV = T; this.Name = N; this.V = V;
        }
        public override string ToString()    // virtual вирутальный метод
        {
            return String.Format("{0} {1}, скорость: {2}", TypeV, Name, V);
        }
    }
}
