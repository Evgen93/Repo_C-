﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Модификаторы доступа");
           
            Truck truck = new Truck("Транспортное средство", "Грузовик", 90, 3.8);
            // truck.Type = "Большой грузовик"; // ОШИБКА т.к. закрытое поле! (private)
            // truck.V = 100;                   // ОШИБКА т.к. защищенное поле! (protected)
            Console.WriteLine(truck.GetInfo());

            truck.UpdateTruck();
            Console.WriteLine(truck.GetInfo());

            Console.ReadKey();
        }
    }

    class Vehicle
    {
        string TypeV;            // тип транспортного средства 
        string Name;            // название транспортного средства 
        protected double V;     // скорость транспортного средства  (модификатор доступа защищенный)
        public string GetInfo()
        {
            return String.Format("{0} {1}, скорость: {2}", TypeV, Name, V);
        }

      
        public Vehicle(string T, string N, double V)
        {
            this.TypeV = T; this.Name = N; this.V = V;
        }
    }

    // класс грузовик (производный класс)
    class Truck : Vehicle  
    {
        public double Load;     // грузоподъемность

       
        public Truck(string T, string N, double V, double Load)
            : base(T, N, V)
        {
            this.Load = Load;
        }

        public void  UpdateTruck()
        {
            // truck.Type = "Большой грузовик"; // ОШИБКА т.к. закрытое поле! (private)
            V = 100;                            // ОШИБКИ НЕТ!
        }

    }
}
