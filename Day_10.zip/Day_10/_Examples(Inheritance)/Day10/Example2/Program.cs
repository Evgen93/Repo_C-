﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example2
{
    
        class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Наследование (конструкторы)");
                Vehicle vehicle = new Vehicle("Транспортное средство", "Обобщенное транспортное средство", 150);
                Console.WriteLine(vehicle.GetInfo());
               
                Truck truck = new Truck("Транспортное средство","Грузовик", 90, 3.8);
                Console.WriteLine(truck.GetInfo());  

                Console.ReadKey();
            }
        }

        // класс транспортное средство (базовый класс)
        class Vehicle
        {
            public string Type;  // тип транспортного средства 
            public string Name;  // название транспортного средства 
            public double V;     // скорость транспортного средства 
            public string GetInfo()
            {
                return String.Format("{0} {1}, скорость: {2}", Type, Name, V);
            }

            // конструкторы не наследуются
            public Vehicle(string T, string N, double V)
            {
                this.Type = T; this.Name = N; this.V = V;
            }
        }

        // класс грузовик (производный класс)
        class Truck : Vehicle  // наследование
        {
            public double Load;     // грузоподъемность
            
            //  конструктор производного класса, передача параметров в конструктор базового класса
            //  с использование ключевого слова base,  если имеется конструктор базового класса 
            public Truck(string T, string N, double V, double Load):base(T, N, V)
            {
                this.Load = Load; 
            }
        
        }
    }
