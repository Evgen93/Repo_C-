﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Сокрытие имен");

            Vehicle vehicle = new Vehicle("Транспортное средство", "Обобщенное транспортное средство", 150);
            Console.WriteLine(vehicle.GetInfo());

            Truck truck = new Truck("Транспортное средство", "Грузовик", 90, 3.8);
            Console.WriteLine(truck.GetInfo());

            Console.ReadKey();
        }
    }

    class Vehicle
    {
        protected string TypeV;           // тип транспортного средства 
        protected string Name;            // название транспортного средства 
        protected double V;               // скорость транспортного средства 
        
        public Vehicle(string T, string N, double V)
        {
            this.TypeV = T; this.Name = N; this.V = V;
        }
        public string GetInfo()
        {
            return String.Format("{0} {1}, скорость: {2}", TypeV, Name, V);
        }
    }

    // класс грузовик (производный класс)
    class Truck : Vehicle
    {
        public double Load;     // грузоподъемность

        public Truck(string T, string N, double V, double Load)
            : base(T, N, V)
        {
            this.Load = Load;
        }
        new  public  string   GetInfo()   // метод с одинаковым именем, как в базовом классе,
                                          // для исключения предупреждения о сокрытии имен используется new 
        {
            return base.GetInfo() + " грузоподъемность: " + Load;  // вызов варианта метода GetInfo() из базового класса
                                                                   // с использованием ключевого слова base
        }

    }
}
