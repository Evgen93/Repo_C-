﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ссылки базового класса");

            Vehicle[] park = new Vehicle[3];
            
            park[0] = new Vehicle("Транспортное средство", "Обобщенное транспортное средство", 150);
            Console.WriteLine(park[0].GetInfo());
            
            // сохранение объекта производного класс в ссылке базового класса
            park[1] = new Truck("Транспортное средство", "Грузовик", 90, 3.8);
            Console.WriteLine(park[1].GetInfo());                               // вызов метода базового класса
            
            // сохранение объекта производного класс в ссылке базового класса
            park[2] = new Bus("Транспортное средство", "Автобус", 50, 7.4, 75);
            Console.WriteLine(park[2].GetInfo());                               // вызов метода базового класса

            Console.ReadKey();
        }
    }

    class Vehicle
    {
        protected string TypeV;           // тип транспортного средства 
        protected string Name;            // название транспортного средства 
        protected double V;               // скорость транспортного средства 

        public Vehicle(string T, string N, double V)
        {
            this.TypeV = T; this.Name = N; this.V = V;
        }
        public string GetInfo()
        {
            return String.Format("{0} {1}, скорость: {2}", TypeV, Name, V);
        }
    }


    class Truck : Vehicle
    {
        protected double Load;     // грузоподъемность

        public Truck(string T, string N, double V, double Load)
            : base(T, N, V)
        {
            this.Load = Load;
        }
        new public string GetInfo()
        {
            return base.GetInfo() + " грузоподъемность: " + Load;
        }
    }
   
    class Bus : Vehicle  
    {
        protected int sitPlaces ;  //количество посадочных мест
        public Bus(string T, string N, double V, double L, int sPl)
            : base(T, N, V)
        {
            this.sitPlaces = sPl;
        }

        new public string GetInfo()
        {
            return base.GetInfo() + " кол-во мест: " + sitPlaces.ToString();
        }
    }
}
