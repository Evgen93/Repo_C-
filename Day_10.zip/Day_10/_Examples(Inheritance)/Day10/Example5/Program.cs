﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Иерархия классов. Запечатанный класс!");

            Vehicle vehicle = new Vehicle("Транспортное средство", "Обобщенное транспортное средство", 150);
            Console.WriteLine(vehicle.GetInfo());

            Truck truck = new Truck("Транспортное средство", "Грузовик", 90, 3.8);
            Console.WriteLine(truck.GetInfo());

            CrawlerTruck cRtruck = new CrawlerTruck("Транспортное средство", "Гусеничный грузовик", 50, 7.4, "плоские");
            Console.WriteLine(cRtruck.GetInfo());

            Console.ReadKey();
        }
    }

    class Vehicle
    {
        protected string TypeV;           // тип транспортного средства 
        protected string Name;            // название транспортного средства 
        protected double V;               // скорость транспортного средства 

        public Vehicle(string T, string N, double V)
        {
            this.TypeV = T; this.Name = N; this.V = V;
        }
        public string GetInfo()
        {
            return String.Format("{0} {1}, скорость: {2}", TypeV, Name, V);
        }
    }

   
    class Truck : Vehicle
    {
        protected double Load;     // грузоподъемность

        public Truck(string T, string N, double V, double Load)
            : base(T, N, V)
        {
            this.Load = Load;
        }
        new public string GetInfo()   
        {
            return base.GetInfo() + " грузоподъемность: " + Load;  
        }
    }
    // Иерархия классов: Vehicle->Truck->CrawlerTruck
    // Создать диаграмму классов: На проекте View->View Class Diagramm
    sealed class CrawlerTruck : Truck  // sealed - запечатанный класс (наследоваться от него невозможно!)
    {
        string CrawlerType;  // тип гусениц
        public CrawlerTruck(string T, string N, double V, double L, string crT)
            : base(T, N, V, L)
        {
            this.CrawlerType = crT;
        }

        new public string GetInfo()
        {
            return base.GetInfo() + " тип гусениц: " + CrawlerType;
        }
    }
}
