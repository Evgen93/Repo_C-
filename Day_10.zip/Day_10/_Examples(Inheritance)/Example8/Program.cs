﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Адстрактный метод");

            Vehicle[] park = new Vehicle[2];

            // сохранение объекта производного класс в ссылке базового класса
            park[0] = new Truck("Транспортное средство", "Грузовик", 90, 3.8);
            Console.WriteLine(park[0].GetInfo());            // вызов метода производного класса
                                                    // из ссылки на базовый т.к. переопределен абстрактый метод      

            // сохранение объекта производного класс в ссылке базового класса
            park[1] = new Bus("Транспортное средство", "Автобус", 50, 7.4, 75);
            Console.WriteLine(park[1].GetInfo());            // вызов метода производного класса
                                                   // из ссылки на базовый т.к. переопределен абстрактый метод    

            Console.ReadKey();
        }
    }

abstract class Vehicle    // класс помечается abstract т.к. имеется абстрактный метод
{
    protected string TypeV;           // тип транспортного средства 
    protected string Name;            // название транспортного средства 
    protected double V;               // скорость транспортного средства 

    public Vehicle(string T, string N, double V)
    {
        this.TypeV = T; this.Name = N; this.V = V;
    }
    public abstract string GetInfo();    // abstract - абстрактный  метод
       
}


class Truck : Vehicle
{
    protected double Load;     // грузоподъемность

    public Truck(string T, string N, double V, double Load)
        : base(T, N, V)
    {
        this.Load = Load;
    }
    public override string GetInfo()  // переопредение абстрактного метода из базового класса
    {
        return String.Format("{0} {1}, скорость: {2}, грузоподъемность: {3}", TypeV, Name, V, Load);
    }
}

    class Bus : Vehicle
    {
        protected int sitPlaces;  //количество посадочных мест
        public Bus(string T, string N, double V, double L, int sPl)
            : base(T, N, V)
        {
            this.sitPlaces = sPl;
        }

        public override string GetInfo()  // переопреление абстрактного метода из базового класса
        {
            return String.Format("{0} {1}, скорость: {2}, ко-во мест: {3}", TypeV, Name, V, sitPlaces);
        }
    }
}
