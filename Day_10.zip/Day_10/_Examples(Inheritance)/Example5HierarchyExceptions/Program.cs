﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Example5HierarchyExceptions
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Создание пользовательских исключений");
            try
            {
                Truck truck = new Truck();
                truck.Load = 3000;
                truck.Load = 2500;
            }
            catch (TruckException ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadLine();
        }
    }
   class Truck 
    {
        private double load;             // грузоподъемность
        private double loadMax=5000;     // макс. грузоподъемность
        // В свойстве генерируется исключение  TruckException
       public  double Load
        {  get { return Load; }
           set
            {   load += value;
                if (load>=loadMax)
                  throw new TruckException("Превышена грузоподъемность"); 
           }
        }
    }

    // атрибут для сериализации (далее в курсе)
    [Serializable]
    public class TruckException:Exception
    {   // конструкторы
        public TruckException()
        {         }
        // конструкторы для инициализации св-ва Message
        public TruckException(string message) : base(message) 
        {         }
        public TruckException(string message, Exception ex) : base(message) 
        {         }
        // Конструктор для обработки сериализации типа
        protected TruckException(SerializationInfo info,StreamingContext contex)
            : base(info, contex) 
        {         }
    }
}
