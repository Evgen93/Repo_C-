﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExampleDelegation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Наследование - Делегирование!");
            Vehicle vehicle = new Vehicle();
            vehicle.Type = "Транспортное средство";
            vehicle.Name = "Обобщенное транспортное средство";
            vehicle.V = 150;
            Console.WriteLine(vehicle.OnRadio(true));
            Console.WriteLine(vehicle.OnRadio(false));
            
            Console.ReadKey();
        }
    }

    // класс транспортное средство
    class Vehicle
    {
        public string Type;  // тип транспортного средства 
        public string Name;  // название транспортного средства 
        public double V;     // скорость транспортного средства 

        Radio radio = new Radio() { On=false};
        public string OnRadio(bool on)
        {  radio.On = on;
            return on ? "Радио вкл." : "Радио выкл.";
        }
    }

    // класс радио
    class Radio  
    {
        bool on;  // включение радио
        public bool On
        {
            get { return on; }
            set { on = value; }
        } 
    }
}
