﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Простейшее наследование");
            Vehicle vehicle = new Vehicle();
            vehicle.Type = "Транспортное средство";
            vehicle.Name = "Обобщенное транспортное средство";
            vehicle.V = 150;
            // vehicle.Load = 2.8;  // ОШИБКА
            Console.WriteLine(vehicle.GetInfo());
            
            Truck truck = new Truck();
            truck.Type = "Транспортное средство";  // наследование открытых полей
            truck.Name = "Грузовик";
            truck.V = 90;
            truck.Load = 3.8;
            Console.WriteLine(truck.GetInfo());  // наследование открытых методов
            
            Console.ReadKey();
        }
    }

    // класс транспортное средство
    class Vehicle
    {
        public string Type;  // тип транспортного средства 
        public string Name;  // название транспортного средства 
        public double V;     // скорость транспортного средства 
        public string GetInfo()
        {
            return String.Format("{0} {1}, скорость: {2}",Type, Name, V);
        }
    }

    // класс грузовик
    class Truck:Vehicle  // наследование
    {
        public double Load;     // грузоподъемность
    }

}
