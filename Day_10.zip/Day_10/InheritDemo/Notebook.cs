﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritDemo
{
    class Notebook : Pc
    {
        private double _dispalay;

        public double Display
        {
            get { return _dispalay; }
            set { _dispalay = value; }
        }

        public override decimal Caclularte()
        {
            return base.Caclularte() * 1.5m;
        }

        public Notebook(string model, double fp, double display = 1.7) : base(model, fp)
        {
            _dispalay = display;
        }
    }
}
