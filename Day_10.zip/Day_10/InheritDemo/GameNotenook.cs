﻿using System;

namespace InheritDemo
{
    internal class GameNotenook
    {
        public bool HasJoi
        {
            get
            {
                throw new System.NotImplementedException();
            }

            set
            {
            }
        }
    }
}