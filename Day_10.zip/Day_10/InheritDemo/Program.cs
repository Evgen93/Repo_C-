﻿using System;

namespace InheritDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Notebook noteBook = new Notebook("hp", 4.5, 2.1);
            Console.WriteLine(noteBook.Caclularte());
            Console.Read();
        }
    }
}
