﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritDemo
{
    internal class Pc
    {
        private string _model;

        public string Model
        {
            get { return _model; }
            private set { _model = value; }
        }

        private double _fp;

        public double Fp
        {
            get { return _fp; }
            private set { _fp = value; }
        }
        protected decimal _price;

        public virtual decimal Caclularte()
        {
            return _price;
        }

        public override string ToString()
        {
            return string.Format("{0} {1}", _model, _fp);
        }

        public Pc(string model, double fp)
        {
            _model = model;
            _fp = fp;
            _price = 1000;
        }
    }
}
