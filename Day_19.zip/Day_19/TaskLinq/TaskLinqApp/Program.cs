﻿using System;
using System.Collections.Generic;
using System.Linq;
using TaskLinqLib;

namespace TaskLinqApp
{
	class Program
	{
        static void Main(string[] args)
        {
            Repository repository = new Repository();
            var employees = repository.GetEmployees();
            var departments = repository.GetDepartments();

            // 1. Вывести зарплату только менеджеров
            // Вывод - Name,Position, Salary

            var managerSalary = from emp in employees where emp.Position.Equals("Manager") select new { emp.Name, emp.Position, emp.Salary };

            /*foreach (var item in managerSalary)
            {
                Console.WriteLine(item);
            }*/

            // 2. Вывести среднюю зарплату по должностям. Сортировка по зарплате
            // Вывод - Position, Salary

            Console.WriteLine();
            var managerSalary1 = from emp in employees group emp by emp.Position into res select new { key = res.Key, salary = res.Average(s => s.Salary), count = res.Count() };

           /* foreach (var item in managerSalary1)
            {
                Console.WriteLine(item);
            }*/

            // 3. Вывести информацию о сотруднике с выводом Name его начальника
            // Вывод - Name, Position, ChieName
            Console.WriteLine();
            var managerSalary2 = from emp in employees join e in employees on emp.ParentId equals e.ParentId select new { name = emp.Name, pos = emp.Position, chieName = e.Name };

            foreach (var item in managerSalary2)
            {
                Console.WriteLine(item);
            }

            // 4. Вывести информацию об отделах  с выводом информации  - кол-во сотрудников в данном отделе, суммарной ЗП отдела
            // Вывод - DepartmentName, CountEmployees, TotalSalary

                                 // 5. Вывести информацию о сотрудниках отдела, который был создан самым первым
                                 // Вывод - DepartmentName, DateCreated, Список сотрудников (Name,Position)

                                 // 6. Вевести информацию о должностях отделов, которые были созданы в марте и феврале 2010 года
                                 // Сортировка по наименованию отдела, дате создания, должности
                                 // Вывод - DepartmentName,DateCreated, Список должностей

            Console.ReadKey();
        }
	}
}
