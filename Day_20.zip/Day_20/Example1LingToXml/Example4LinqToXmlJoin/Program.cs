﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Example4LinqToXmlJoin
{
    class Program
    {
        static void Main(string[] args)
        {
            // установка разделитя в дробных суммах (зависит от настройки локализации)
            NumberFormatInfo formatSepar = new NumberFormatInfo();
            formatSepar.NumberDecimalSeparator = ".";


            // Загрузка документа в память
            XDocument xmlDoc = XDocument.Load("books.xml");
            XDocument xmlDoc2 = XDocument.Load("publ.xml");
                      
            Console.WriteLine("Использование операторов запросов...");

            var albumGroupsOp = from b in xmlDoc.Root.Elements("book")
                                join p in xmlDoc2.Root.Elements("publisher")
                                on b.Element("publisher").Value equals p.Element("Id").Value  
                                select new                   // формирование анонимного типа
                                {
                                    Name = b.Element("author").Value,
                                    Price = p.Element("title").Value
                                };
                              

            foreach (var a in albumGroupsOp)
                Console.WriteLine("{0} - {1}", a.Name, a.Price);

           

            Console.ReadKey();

        }
    }
}
