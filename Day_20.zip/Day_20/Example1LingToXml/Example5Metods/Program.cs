﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Example5Metods
{
    class Program
    {
        static void Main(string[] args)
        {
            XDocument doc = XDocument.Load("test.xml");
            XElement root = doc.Root;

            var elementBar = root.Elements("bar").ToList();
            elementBar.ForEach(p=>Console.WriteLine("Elements : " + p.Value));

            var descendantsBar = root.Descendants("bar").ToList();
            descendantsBar.ForEach(p => Console.WriteLine("Descendants : " + p.Value));

            Console.Read();

        }
    }
}
