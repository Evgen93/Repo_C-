﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StandInterface
{
    internal class CarInfo : IComparable
    {
        public string Model { get; set; }

        public decimal Price { get; set; }

        public int Year { get; set; }

        public int CompareTo(object obj)
        {
            return this.Price.CompareTo(((CarInfo)obj).Price);
        }

        public override string ToString()
        {
            return $"{Model} {Price} {Year}";
        }
    }
}
