﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StandInterface
{
    class Program
    {
        static void Main(string[] args)
        {
            CarInfo[] cars =
            {
                new CarInfo() {Model = "BMW", Price = 15000, Year = 2005},
                new CarInfo() {Model = "Ford", Price = 100000, Year = 2018},
                new CarInfo() {Model = "Audi", Price = 25000, Year = 2009},
                new CarInfo() {Model = "Opel", Price = 5000, Year = 2000}
            };
            Console.WriteLine(string.Join("\n", cars.ToList()));
            Array.Sort(cars);
            Console.WriteLine();
            Console.WriteLine(String.Join("\n", cars.ToList()));

            Console.Read();
        }
    }
}
