﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4._1InterfaceIn2
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }

    interface IBase
    {
        void Drawing();
    }

    interface IWork : IBase
    {
        void Working();
    }

    class Truck : IWork
    {
        public void Drawing()
        {
            Console.WriteLine("Drawing - реализация интерфейса IWork");
        }

        public void Working()
        {
            Console.WriteLine("Working - реализация интерфейса IWork");
        }
    }
}
