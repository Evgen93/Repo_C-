﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example3
{
    class InterProperty
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Интерфейсные свойства/индексаторы ");
            Truck truck = new Truck();
            Console.WriteLine(truck[2]);
            truck.Working(5000);
            Console.WriteLine(truck.Status);

            Bus bus = new Bus();
            Console.WriteLine(bus[12]);
            bus.Working(18);
            Console.WriteLine(bus.Status);


            Console.ReadKey();
        }
    }
    class Truck : IWork  // наследование интерфейса  IWork
    {                     // обязательная реализация методов из интерфейса IWork
        double Load { get; set; }
        double MaxLoad = 5000;
        int[] ClassTruck = new int[] { 5000, 3000, 1000 };
        public void Working(int delta)
        {   Load = Load + delta;
            if (Load >= MaxLoad)
                Console.WriteLine("Грузоподъемность превышена");
        }
        public string Status
        {  get
            { return String.Format("Масса груза {0}", Load); }
        }

        public string this[int index]
        {  get
            {   MaxLoad = (int)ClassTruck[index];
                return String.Format("Мак. масса {0}", ClassTruck[index]); }
        }
    }


    class Bus : IWork  // наследование интерфейса  IWork
    {                     // обязательная реализация методов из интерфейса IWork
        public int NumPass { get; set; }
        const double MaxPass = 25;
        public void Working(int delta)
        {
            NumPass = NumPass + delta;
            if (NumPass >= MaxPass)
            {
                Console.WriteLine("Автобус полный. Лишних: {0}", NumPass - MaxPass);
            }
        }
        public string Status
        { get
            {
                return String.Format("Всего пассажиров {0}", NumPass);
            }
        }

        public string this[int index]
        {  get
            {   string info = String.Empty;
                info = index % 2 == 0 ? "Водитель 1" : "Водитель 2";
                return info;
            }
        }
        
    }

    interface IWork                  // создание интерфейса
    {
        void Working(int delta);     // спецификатор доступа по умолчанию public
                                     // отсуствует реализация методов
      
        string Status { get; }        // интерфейсное свойство (только для чтения)
                                      // не автоматическое свойство!
        string this[int index] { get; }   // интерфейсный индексатор!
    
    }
}
