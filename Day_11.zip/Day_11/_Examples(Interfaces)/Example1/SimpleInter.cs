﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example1
{
    class SimpleInter
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Простейший интерфейс!");

            Truck truck = new Truck();
            truck.Working(3000);
            
            Bus bus = new Bus() { NumPass=17};
            bus.Working(10);

            Teacher teach = new Teacher();
            teach.Working(5);

           

            Console.ReadKey();
        }
    }


    class Truck  : IWork  // наследование интерфейса  IWork
    {                     // обязательная реализация методов из интерфейса IWork
        public double Load { get; set; } 
        const double MaxLoad = 5000;
        public void Working(int delta)
        {
            Load=Load+delta;
            if (Load >= MaxLoad)
                Console.WriteLine("Грузоподъемность превышена");
        }
    }

    class Bus : IWork     // наследование интерфейса  IWork
    {                     // обязательная реализация методов из интерфейса IWork
        public int NumPass { get; set; }
        const double MaxPass = 25;
        public void Working(int delta)
        {
            NumPass = NumPass + delta;
            if (NumPass >= MaxPass)
            {
                Console.WriteLine("Автобус полный. Лишних: {0}", NumPass-MaxPass);
            }
        }
    }

    class Teacher:IWork
    {
        public void Working(int delta)
        {
            Console.WriteLine("Вам оценка {0}", new Random().Next(1, delta));
        }
    }

    interface IWork  // создание интерфейса
    {
        void Working(int delta);   // модификатор доступа по умолчанию public
                                   // отсуствует реализация методов
        
    }
}
