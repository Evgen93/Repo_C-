﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example2
{
    class InterRef
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Интерфейсные ссылки!");

            IWork Worker;  // объявление интерфейсной ссылки!

            Truck truck = new Truck();
            Worker = truck;                         // присваивание объекта интерфейсной ссылке !
            Worker.Working(2);
            Worker.ShowState();
            // Worker.LoadReset();                  // Ошибка метод недоступен т.к. реализован в классе Truck


            Bus bus = new Bus();
            Worker = bus;
            Worker.Working(120);
            Worker.ShowState();

            IWork[] vehicles = new IWork[2];        // создание массива интерфейсных ссылок!
            vehicles[0] = new Truck();
            vehicles[1] = new Bus();

            foreach (IWork worker in vehicles)
            {
                worker.Working(100);
                worker.ShowState();
            }
            Console.ReadKey();
        }
    }


    class Truck : IWork  // наследование интерфейса  IWork
    {                     // обязательная реализация методов из интерфейса IWork
        public double Load { get; set; }
        const double MaxLoad = 5000;
        public void Working(int delta)
        {
            Load = Load + delta;
            if (Load >= MaxLoad)
                Console.WriteLine("Грузоподъемность превышена");
        }
        void ShowState()
        {
            Console.WriteLine("Масса груза: {0}", Load);
        }

        // метод класса Truck
        public void LoadReset()
        {
            Load = 0;
        }
    }

    class Bus : IWork     // наследование интерфейса  IWork
    {                     // обязательная реализация методов из интерфейса IWork
        public int NumPass { get; set; }
        const double MaxPass = 25;
        public void Working(int delta)
        {   NumPass = NumPass + delta;
            if (NumPass >= MaxPass)
            {
                Console.WriteLine("Автобус полный. Лишних: {0}", NumPass - MaxPass);
            }
        }
        void ShowState()
        {
            Console.WriteLine("Пассажиров: {0}", NumPass);
        }
    }

    interface IWork  // создание интерфейса
    {
        void Working(int delta);   // спецификатор доступа по умолчанию public
                                   // отсуствует реализация методов
        void ShowState(); 

    }
}
