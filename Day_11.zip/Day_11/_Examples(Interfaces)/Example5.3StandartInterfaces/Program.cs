﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example5._3StandartInterfaces
{
    class Program
    {
        static void Main(string[] args)
        {

            Car[] car = new Car[]
            {
                new Car(){Name="BMW", Price=5000},
                new Car(){Name="Ford", Price=7500},
                new Car(){Name="Opel", Price=5500},
                new Car(){Name="BMW", Price=7900},
                new Car(){Name="Audi", Price=8600},
            };

            ComparerCars comparer = new ComparerCars();
            Car[] uniqueCars = car.Distinct(comparer).ToArray();
            for (int i = 0; i < uniqueCars.Length; i++)
            {
                Console.WriteLine(uniqueCars[i]);
            }


            Console.Read();
        }
    }


    class ComparerCars : IEqualityComparer
    {

        public bool Equals(object x, object y)
        {
            return ((Car)x).Name.Equals(((Car)y).Name);
        }

        public int GetHashCode(object obj)
        {
            return ((Car)obj).GetHashCode();
        }
    }

    class Car
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        public override string ToString()
        {
            return String.Format("{0} {1}.", Name, Price);
        }
    }

}
