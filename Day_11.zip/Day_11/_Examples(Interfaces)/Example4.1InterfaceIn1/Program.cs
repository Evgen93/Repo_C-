﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4._1InterfaceIn1
{
    // НАСЛЕДОВАНИЕ КЛАССА И ИНТРЕФЕЙСА
    class Program
    {
        static void Main(string[] args)
        {
            Truck truck = new Truck();
            truck.Draw();
            truck.Working();
            truck.Upgrade();

            Car car = new Car();
            car.Draw();

            Console.ReadKey();
        }
    }

    class Truck:Car, IWork, IBase
    {

        public void Working()
        {
            Console.WriteLine("Метод IWork - Working()");
        }

        public void Upgrade()
        {
            Console.WriteLine("Метод IBase -Upgrade()");
        }
    }

    class Car
    {
        public void Draw()
        {
            Console.WriteLine("Метод класса Car - Draw()");
        }
    }

    interface IWork
    {
        public void Working();
       
    }

    interface IBase
    {
        public void Upgrade();
      
    }
}
