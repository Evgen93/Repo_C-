﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example2._2InterRef
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Интерфейсные ссылки!");
            Truck truck = new Truck();
            // truck.Working(5);    //ОШИБКА! т.к. метод Working() явно реализован и private
            truck.ShowState();

            IWork worker = new Truck();
            worker.Working(5);
            // worker.ShowState();  //ОШИБКА! т.к. метод ShowState() явно реализован интрефейсе IShow

            IShow shower = new Truck();
            shower.Working(5);
            shower.ShowState();

            Console.ReadKey();
        }
    }


    class Truck : IWork, IShow  
    {
        void IWork.Working()
        {
            
        }

        void IShow.Working()
        {

        }

        public void ShowState()
        { 
        
        }
    }


    interface IWork 
    {
        void Working(int delta);   
    }
    interface IShow
    {
        void Working(int delta);  
        void ShowState();
    }
}
