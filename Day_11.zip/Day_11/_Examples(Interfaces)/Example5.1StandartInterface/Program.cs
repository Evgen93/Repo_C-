﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example5._1StandartInterface
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Копирование объектов");       //
            Car car1 = new Car() { Name="BMW", Price=15000};
            Car carCopy = car1;
            car1.Price = 5000;
            car1.Name = "Ford";
            Console.WriteLine(car1);
            Console.WriteLine(carCopy);

            Console.WriteLine("Клонирование объектов"); 
            Car car2 = new Car() { Name = "BMW", Price = 15000 };
            Car carClone = (Car)car2.Clone();
            car2.Price = 5000;
            car2.Name = "Ford";
            Console.WriteLine(car2);
            Console.WriteLine(carClone);  // обратите внимание на строку


            Console.WriteLine("Клонирование объектов + ссылочные типы");
            Car car3 = new Car() { Name = "BMW", Price = 15000 };
            Car carCloneRef = (Car)car3.Clone();
            car3.Price = 5000;
            car3.Name = "Ford";
            Console.WriteLine(car3);
            Console.WriteLine(carCloneRef);

                     
            Console.Read();
        }
    }


    class Car:ICloneable
    {
        public string Name { get; set; }
        public decimal Price { get; set; }

        private Radio radio;

        public Car()
        {
            radio = new Radio() {RadioType="FM" };
        }

        public object Clone()
        {
            // создание нового объекта с параметрами текущего
            //   return new Car() { Name = this.Name, Price = this.Price };   

            // метод создает поверхностную копию объекта. определен в классе Object
               return this.MemberwiseClone();  

            // создание нового объекта с параметрами текущего 
            // создание объекта radio т.к. this.MemberwiseClone() создает неглубокую копию объекта
            //return new Car() { Name = this.Name, Price = this.Price, radio = new Radio() { RadioType=this.radio.RadioType} };
        }

        public override string ToString()
        {
            return String.Format("{0} {1}. - {2}", Name, Price, radio.RadioType);
        }
    }

    class Radio
    {
        public string RadioType { get; set; }
    }

}
