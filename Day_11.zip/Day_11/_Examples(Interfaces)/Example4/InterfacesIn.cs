﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4
{
    class InterfacesIn
    {
        static void Main(string[] args)
        {
           Console.WriteLine("Наследование интерфейсов! ");

           Truck truck = new Truck();
           truck.Drive(100);
           // truck.Working(); // ошибка 
           IWork work = truck;
           work.Working();

           IBasic basic = truck;
           basic.Working();

           Console.ReadKey();
        }
    }

    class Truck :  IWork   
    {                      
        void IWork.Working()  //явная реализация интерфейса (модификатор доступа private)
        {
            Console.WriteLine(" Working из IWork");
        }
        void IBasic.Working()
        {
            Console.WriteLine(" Working из IBasic");
        }
        public void Drive(double V)
        {
            Console.WriteLine(" Drive...{0} km",V);
        }
    }

    interface IWork : IBasic       // НАСЛЕДОВАНИЕ ИНТЕРФЕЙСОВ
    {
        new void Working();              // МЕТОД С ТАКИМ ИМЕНЕМ ИМЕЕТСЯ В ИНТЕФЕЙСЕ IBasic
                                         // т.е. скрывает метод Working из IBasic
    }                                    // оператор new необязательный

    interface IBasic                // базовый интерфейс
    {
        void Drive(double V);      
        void Working();       
    }

    

}
