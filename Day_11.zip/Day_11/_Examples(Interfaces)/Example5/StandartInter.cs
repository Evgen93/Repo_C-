﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example5
{
    class StandartInter
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Стандартные интерфейсы");
            int[] masInt = new int[5] { 2, 7, 5, 3, 8 };
            
            Console.WriteLine("Исходный массив целых чисел!");
            foreach(int i in masInt)
            Console.Write(i+" ");
            
            Console.WriteLine("Упорядоченный  массив целых чисел!");
            Array.Sort(masInt);                                     // сортировка массива
            
            foreach (int i in masInt)
                Console.Write(i + " ");

           
            Car[] masCars = new Car[] {
                                      new Car{ID=1, Name="Reno", Speed=240,  Weight=5.5},
                                      new Car{ID=1, Name="Ford", Speed=250,  Weight=4.9},
                                      new Car{ID=1, Name="Audi", Speed=220,  Weight=6.1}
                                      };
            Console.WriteLine("\nИсходный массив объектов класса Car!");
            foreach (Car car in masCars)
                Console.WriteLine(car);

            Array.Sort(masCars);     // СОРТИРОВКА МАССИВА, ЭЛЕМЕНТАМИ КОТОРОГО ЯВЛЯЮТСЯ ОБЪЕКТЫ КЛАССА Car
                                     // ЕСЛИ ОТСУТСТВУЕТ РЕАЛИЗАЦИЯ В КЛАССЕ Car ИНТЕРФЕЙСА IComparable
                                     // ТО СОРТИРОВКА НЕ ВЫПОЛНИЛАСЬ

            Console.WriteLine("\nУпорядоченный массив объектов класса Car!");
            foreach (Car car in masCars)
                Console.WriteLine(car);


            Console.WriteLine("\nВывод объектов класса Car из гаража!");
            Garage garage = new Garage();
            foreach (Car car in garage)
                Console.WriteLine(car);


            Console.ReadKey();
        }
    }

    class Car:IComparable
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public double Speed { get; set; }
        public double Weight { get; set; }

        public override string ToString()
        {
            return String.Format("№{0}. {1} V={2}, M={3}", ID, Name, Speed, Weight);
        }

        public int CompareTo(object obj)
        {
            Car NextCar = (Car)obj;
            if (NextCar.Speed > this.Speed) return -1;
            else return 1;
 
        }
    }

    class Garage:IEnumerable
    {
        Car[] masCars = new Car[]    {
                                      new Car{ID=1, Name="Reno", Speed=240,  Weight=5.5},
                                      new Car{ID=1, Name="Ford", Speed=250,  Weight=4.9},
                                      new Car{ID=1, Name="Audi", Speed=220,  Weight=6.1}
                                      };

        public IEnumerator GetEnumerator()
        {
            return masCars.GetEnumerator();
        }
    }
}
