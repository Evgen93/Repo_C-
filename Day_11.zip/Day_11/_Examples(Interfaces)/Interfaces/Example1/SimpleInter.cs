﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example1
{
    class SimpleInter
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Простейший интерфейс!");
            Student st = new Student();
            st.Working(3);
            Console.WriteLine("Студент на {0} курсе!", st.CurrentCurs);

            Teacher tch = new Teacher() {UchWork=1080};
            tch.Working(120);
            Console.WriteLine("Нагрузка преподавателя {0} часов!", tch.UchWork);

            Console.ReadKey();
        }
    }


    class Student  : IWork  // наследование интерфейса  IWork
    {                       // обязательная реализация методов из интерфейса IWork
        public int CurrentCurs { get; set; }
        public void Working(int nextCurs)
        {
            CurrentCurs += nextCurs;
           
        }
    }

    class Teacher : IWork     // наследование интерфейса  IWork
    {                         // обязательная реализация методов из интерфейса IWork
        public double UchWork { get; set; }
        public void Working(int mNorma)
        {
            UchWork -= mNorma;
        }
        
    }

    interface IWork  // создание интерфейса
    {
        void Working(int delta);   // спецификатор доступа по умолчанию public
                                   // отсуствует реализация методов
        
    }
}
