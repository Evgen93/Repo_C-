﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example2
{
    class InterRef
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Интерфейсные ссылки!");

            IWork Worker;  // объявление интерфейсной ссылки!
            
            Student st = new Student();
            Worker = st;                         // присваивание объекта интерфейсной ссылке !
            Worker.Working(2);
            Worker.ShowInfo();

            Teacher tch = new Teacher() { UchWork = 1080 };
            Worker = tch;
            Worker.Working(120);
            Worker.ShowInfo(); 
          
            IWork[] studies = new IWork[2];   // создание массива интерфейсных ссылок!
            studies[0] = new Student();
            studies[1] = new Teacher() {UchWork=1000};

            foreach (IWork worker in studies)
            {
                if (worker is Student)   // проверка явлется ли worker объектом класса Student 
                    worker.Working(1);
                else 
                    worker.Working(160);
                worker.ShowInfo();
            }
            Console.ReadKey();
        }
    }


    class Student : IWork  // наследование интерфейса  IWork
    {                       // обязательная реализация методов из интерфейса IWork
        public int CurrentCurs { get; set; }
        public void Working(int nextCurs)
        {
            CurrentCurs += nextCurs;

        }
        public void ShowInfo()
        {
            Console.WriteLine("Студент на {0} курсе!", CurrentCurs);
        }
    }

    class Teacher : IWork     // наследование интерфейса  IWork
    {                         // обязательная реализация методов из интерфейса IWork
        public double UchWork { get; set; }
        public void Working(int mNorma)
        {
            UchWork -= mNorma;
        }
        public void ShowInfo()
        {
            Console.WriteLine("Нагрузка преподавателя {0} часов!", UchWork);
        }
    }

    interface IWork  // создание интерфейса
    {
        void Working(int delta);   // спецификатор доступа по умолчанию public
                                   // отсуствует реализация методов
        void ShowInfo();           // спецификатор доступа по умолчанию public
                                   // отсуствует реализация методов    
    }
}
