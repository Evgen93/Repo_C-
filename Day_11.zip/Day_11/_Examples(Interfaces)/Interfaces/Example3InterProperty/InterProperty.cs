﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example3
{
    class InterProperty
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Интерфейсные свойства/индексаторы ");
           

            IWork[] studies = new IWork[4];   // создание массива интерфейсных ссылок!
            studies[0] = new Student();
            studies[1] = new Teacher() { UchWork = 1000 };
            studies[2] = new Student() { CurrentCurs=4};
            studies[3] = new Teacher() { UchWork = 150 };
            foreach (IWork worker in studies)
            {
                if (worker is Student)   // проверка явлется ли worker объектом класса Student 
                    worker.Working(1);
                else
                    worker.Working(160);

              
                worker.ShowInfo();
                Console.WriteLine(worker.Status);
            }

            Console.ReadKey();
        }
    }

    class Student : IWork   // наследование интерфейса  IWork
    {                       // обязательная реализация методов из интерфейса IWork
        int[] marks = new int[3];
        public int CurrentCurs { get; set; }
        public void Working(int nextCurs)
        {
            CurrentCurs += nextCurs;

        }
        public void ShowInfo()
        {
            Console.WriteLine("Студент на {0} курсе!", CurrentCurs);
        }


        public string Status                        // реализация интерфейсного свойства
        {
            get
            {   if (CurrentCurs <= 5) return "Учиться еще...";
                else return "Выпуск!!!";
            }
        }

        public int this[int index]                 // реализация интерфейсного индексатора!
        {
            get
            {   switch (index)
                {
                 case 0: return marks[index];
                 case 1: return marks[index];
                 case 2: return marks[index];
                 default: return 0;     
                }
            }
            set
            {
                switch (index)
                {
                    case 0: marks[index] = value; break;
                    case 1: marks[index] = value; break;
                    case 2: marks[index] = value; break;
                }
            }
        }
    }

    class Teacher : IWork     // наследование интерфейса  IWork
    {                         // обязательная реализация методов из интерфейса IWork
        public double UchWork { get; set; }

        int[] groups = new int[5] { 1101, 1102, 1103,1201,1305 };
        public void Working(int mNorma)
        {
            UchWork -= mNorma;
        }
        public void ShowInfo()
        {
            Console.WriteLine("Нагрузка преподавателя {0} часов!", UchWork);
        }

        public string Status         // реализация интерфейсного свойства
        {
            get
            {   if (UchWork > 0) return "Работа...";
                else return "Отпуск!";
            }
        }

        public int this[int index]   // реализация интерфейсного индексатора!
        {
            get
            { if (0 <= index && index < groups.Length)
                { return groups[index]; }
                else return 0;
            }
            set
            {   if (0 <= index && index < groups.Length)
                { groups[index] = value; }
            }
        }
    }

    interface IWork                // создание интерфейса
    {
        void Working(int delta);   // спецификатор доступа по умолчанию public
                                   // отсуствует реализация методов
        void ShowInfo();           // спецификатор доступа по умолчанию public
                                   // отсуствует реализация методов    

        string Status { get; }              // интерфейсное свойство (только для чтения)
                                            // не автоматическое свойство!
        int this[int index] { get; set; }   // интерфейсный индексатор!
    
    }
}
