﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4
{
    class InterfacesIn
    {
        static void Main(string[] args)
        {
             Console.WriteLine("Наследование интерфейсов! ");



            IWork st1 = new Student();                    // используем интерефейсную ссылку
            st1.Working(1); st1.ShowInfo();

            IWork tch1 = new Teacher() { UchWork = 860 }; // используем интерефейсную ссылку
            tch1.Working(120); tch1.ShowInfo();

            ILive st2 = new Student();                    // используем интерефейсную ссылку
            st2.Working(-1); 
            //st2.ShowInfo();                             // метод вызвать нельзя т.к. он определен в интефейсе IWork

            ILive tch2 = new Teacher() { UchWork = 0 };   // используем интерефейсную ссылку
            tch2.Working(120);
            //tch2.ShowInfo();                            // метод вызвать нельзя т.к. он определен в интефейсе IWork

            Student st3 = new Student();
           // st3.Working(2);                             // ОШИБКА! т.к. яввная реализация метода из интерфейса 

            Console.ReadKey();
        }
        }
    
    class Student : IWork   
    {                       
        public int CurrentCurs { get; set; }
        void IWork.Working(int nextCurs)      // явная реализация метода Working из интерфейса IWork
        {                                     // спецификатор доступа при явной реализации - private
            CurrentCurs += nextCurs;

        }
        void ILive.Working(int mNorma)        // явная реализация метода Working из интерфейса ILive
        {                                     // спецификатор доступа при явной реализации - private
            Console.WriteLine("Не учусь!");
        }
        public void ShowInfo()
        {
            Console.WriteLine("Студент на {0} курсе!", CurrentCurs);
        }
        public string Status                       
        {
            get
            {   if (CurrentCurs <= 5) return "Учиться еще...";
                else return "Выпуск!!!";
            }
        }
        public void Go(double V)              // Реализация метода Go из базового интерфейса
        {
            Console.WriteLine("Бегаю бысто, со скоростью {0} км/ч", V);
        }
        public void Sleep(int T)
        {
            Console.WriteLine("Сплю мало, всего {0} часов", T);
        }           // Реализация метода Sleep из базового интерфейса
    }

    class Teacher : IWork     // наследование интерфейса  IWork
    {                         // обязательная реализация методов из интерфейса IWork
        public double UchWork { get; set; }
        void IWork.Working(int mNorma)       // явная реализация метода Working из интерфейса IWork
        {                                    // спецификатор доступа при явной реализации - private
            UchWork -= mNorma;
        }
        void ILive.Working(int mNorma)        // явная реализация метода Working из интерфейса ILive
        {                                     // спецификатор доступа при явной реализации - private
            Console.WriteLine("Работаю без нагрузки");
        }
        public void ShowInfo()
        {
            Console.WriteLine("Нагрузка преподавателя {0} часов!", UchWork);
        }
        public string Status                      // Реализация интерфейсного свойства
        {
            get
            {   if (UchWork > 0) return "Работа...";
                else return "Отпуск!";
            }
        }
        public void Go(double V)
        {
            Console.WriteLine("Неспешняа прогулка, скорость {0} км/с", V);
        }              // Реализация метода Go из базового интерфейса
        public void Sleep(int T)
        {
            Console.WriteLine("Здоровый сон - {0} часов", T);
        }              // Реализация метода Go из базового интерфейса
    }

    interface IWork : ILive           // наследование интерфейса
    {
      new  void Working(int delta);   
        void ShowInfo();              

        string Status { get; }        
       new void Go(double V);         
    }

    interface ILive              // базовый интерфейс
    {
        void Go(double V);       // наследуются в производный интерфейс и должны быть  реализованы в классе
        void Sleep(int T);

        void Working(int delta);  // МЕТОД С ТАКИМ ИМЕНЕМ ИМЕЕТСЯ В ИНТЕФЕЙСЕ IWork

    }

}
