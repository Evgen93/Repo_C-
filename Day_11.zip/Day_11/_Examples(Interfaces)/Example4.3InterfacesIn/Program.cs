﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4._3InterfacesIn
{
    class InterfacesIn
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Наследование интерфейсов! ");
            
            Truck truck = new Truck();
            truck.Working();
            truck.Drawing();
            
            Car carTrack = new Truck();
            carTrack.Working();
            carTrack.Drawing();

            Console.ReadKey();
        }
    }

    class Truck : Car
    {
        public void Drawing()  // метод реализован для двух интерфейсов IWork, IBasic 
        {
            Console.WriteLine(" Drawing Truck...");
        }
    }

    interface IWork
    {
        void Working();
        void Drawing();
    }

   

    abstract class Car:IWork  // абстрактный класс наследует интрефейс
    {
        public void Working()  //
        {
            Console.WriteLine(" Working Car...");
        }

        public abstract void Drawing();  // 
        
    }
}
