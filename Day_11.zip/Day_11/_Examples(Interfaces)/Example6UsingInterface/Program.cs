﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example6UsingInterface
{
    class Program
    {
        static void Main(string[] args)
        {

            Soldier solder = new Soldier();
            solder.SetWeapon(new Automat());
            solder.Fire();

            solder.SetWeapon(new Gun());
            solder.Fire();

            Console.ReadKey();
        }
    }

    // интерфейс, определяюший поведение
    interface IShoot
    {
        void Shoot();
    }
    // конкретная реализация поведения
    class Automat : IShoot
    {
        public void Shoot()
        {
            Console.WriteLine("Автомат...");
        }
    }
    // конкретная реализация поведения
    class Gun : IShoot
    {
    public void Shoot()
        {
            Console.WriteLine("Пистолет...");
        }
    }

    // абстрактный класс
    abstract class Warrior 
    {
       protected  IShoot shoot;

       public void SetWeapon(IShoot sht)
       {
           shoot = sht;
       }

       public void Fire()
       {
           shoot.Shoot();
       }


    }
    // конкретная реализация Warrior
    class Officer :Warrior
    {
     
    }
    // конкретная реализация Warrior
    class Soldier : Warrior
    {
       
    }
}
