﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4._1InterfaceIn
{

    class InterfacesIn
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Наследование интерфейсов! ");
            Truck truck = new Truck();
            truck.Working();
            truck.Drawing();

            Car car = new Car();
            car.Working();
            

            Car carTrack = new Truck();
            carTrack.Working();

            Console.ReadKey();
        }
    }

    class Truck : Car, IWork, IBasic 
    {
        // IWork требует реализацию метода Working()
        // реализация метода наследуется из класс Car
        public void Drawing()  // метод реализован для двух интерфейсов IWork, IBasic
                               // т.к. нет явной реализации интерфейсов
        {
            Console.WriteLine(" Drawing Truck...");
        }
    }

    interface  IWork       
    {
        void Working();
        void Drawing();
    }

    interface IBasic               
    {
        void Drawing();
    }

    class Car 
    {
        public void Working() // метод базового класса  будет использован в производном классе 
                              // для реализации интерфейса IWork 
        {
            Console.WriteLine(" Working Car...");
        }
    }
}
