﻿using System;

namespace interfaceDemo.Interfaces
{
    internal interface ISending
    {
        string ProtocolName { get; }
        void Send(string fileName);
    }
}
