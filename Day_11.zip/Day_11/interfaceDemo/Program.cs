﻿using interfaceDemo.BLL;
using interfaceDemo.Interfaces;
using System;


namespace interfaceDemo
{
    class Program
    {
        static void Main(string[] args)
        { 
            string[] files = new string[500];
            ISending[] senders =
            {
                new SenderFtp("ftp"),
                new SenderHttp()
            };

            for (int i = 0; i < files.Length; i++)
            {
                for (int j = 0; j < senders.Length; j++)
                {
                    Console.WriteLine(senders[j].ProtocolName);
                    FileManager.SendFile(senders[j], files[i]);
                }
            }
            Console.Read();
        }
    }
}
