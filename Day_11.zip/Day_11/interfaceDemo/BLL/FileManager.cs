﻿using System;
using interfaceDemo.Interfaces;

namespace interfaceDemo.BLL
{
    static class FileManager
    {
        public static void SendFile(ISending sender, string file)
        {
            sender.Send(file);
        }
    }
}
