﻿using interfaceDemo.Interfaces;
using System;

namespace interfaceDemo.BLL
{
    internal class SenderHttp : ISending
    {
        public string ProtocolName
        {
            get
            {
                return "Http"; 
            }
        }

        public void Send(string filePath)
        {
            Console.WriteLine("Send File - http");
        }
    }
}
