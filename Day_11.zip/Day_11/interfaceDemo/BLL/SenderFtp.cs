﻿using interfaceDemo.Interfaces;
using System;

namespace interfaceDemo.BLL
{
    class SenderFtp : ISending
    {
        string protocolName;
        public SenderFtp(string _protocolName)
        {
            protocolName = _protocolName;
        }
        public string ProtocolName
        {
            get
            {
                return protocolName;
            }
        }

        public void Send(string filePath)
        {
            Console.WriteLine("Send File - ftp");
        }
    }
}
