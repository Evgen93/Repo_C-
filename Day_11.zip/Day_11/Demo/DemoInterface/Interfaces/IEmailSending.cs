﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoInterface.Interfaces
{
   internal interface IEmailSending
    {
        void Send(string message);
    }
}
