﻿using DemoInterface.BLL;
using DemoInterface.Interfaces;
using System;

namespace DemoInterface
{
    class Program
    {
        static void Main(string[] args)
        {
            // FileManager.SendFile(new SendFileByFtp(), "file.txt");
            //  FileManager.SendFile(new SenderHttp(), "file.txt");
            FileManager.SendFile(new SendByHTTPs(), "file.txt");

            ISending[] senders =
            {   new SendByHTTPs(),
                new SenderHttp("http"),
                new SendFileByFtp()
            };
            senders[0].Send("1111.txt");
            IEmailSending emeilsending = new SenderHttp("");
            emeilsending.Send("sharp@ms.com");
           
            string[] files = new string[500];

            for (int i = 0; i < files.Length; i++)
            {
                for (int j = 0; j < senders.Length ; j++)
                {
                    senders[j].Check();
                    Console.WriteLine(senders[j].ProtocolName);
                    FileManager.SendFile(senders[j], files[i]);
                }
            }
            Console.ReadKey();

        }
    }
}
