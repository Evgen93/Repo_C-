﻿using DemoInterface.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoInterface.BLL
{
    internal class SenderHttp : ISending, IEmailSending
    {
        private string _protocolname;

        public SenderHttp(string protocolname)
        {
            _protocolname = protocolname;
        }
      
        public string ProtocolName
        {
            get
            {
                return _protocolname;
            }
        }
        

        public bool Check()
        {
            return true;
        }
        

        void ISending.Send(string fileName)
        {
            Console.WriteLine("send file");
        }

        void IEmailSending.Send(string fileName)
        {
            Console.WriteLine("send email");
        }
    }
}
