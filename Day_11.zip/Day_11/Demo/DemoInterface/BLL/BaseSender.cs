﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoInterface.BLL
{
    internal abstract class BaseSender
    {
        public abstract int GetFileSize();
        
    }
}
