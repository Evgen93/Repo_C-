﻿using DemoInterface.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoInterface.BLL
{
    static class FileManager
    {
        public static void SendFile(ISending sender, string fileName)
        {
            sender.Send(fileName);
        }
    }
}
