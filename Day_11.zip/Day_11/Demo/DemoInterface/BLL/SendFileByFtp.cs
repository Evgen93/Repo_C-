﻿using DemoInterface.Interfaces;
using System;


namespace DemoInterface.BLL
{
    internal class SendFileByFtp : ISending
    {
        private const string PROTOCOL_NAME = "FTP";
        public string ProtocolName
        {
            get
            {
                return PROTOCOL_NAME;
            }
        }

        public void Send(string filePath)
        {
            Console.WriteLine("Send File  - FTP");
        }

        public bool Check()
        {
            return true;
        }

    }
}
