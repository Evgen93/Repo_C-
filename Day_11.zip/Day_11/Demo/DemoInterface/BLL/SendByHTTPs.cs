﻿using DemoInterface.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoInterface.BLL
{
    internal class SendByHTTPs : BaseSender, ISending
    {
        public string ProtocolName
        {
            get
            {
                return "HTTPs";
            }
        }

       
        public bool Check()
        {
            return true;
        }

        public override int GetFileSize()
        {
            return 100;
        }
    }
}
