﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoStandartInterfaces
{
    internal class CarComparer : IComparer
    {
        public int Compare(object x, object y)
        {
            return ((CarInfo)x).Price.CompareTo(((CarInfo)y).Price);
        }
    }
}
