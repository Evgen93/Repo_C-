﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoStandartInterfaces
{
    class Program
    {
        static void Main(string[] args)
        {
            CarInfo[] cars =
                {   new CarInfo() {Model="BMW", Price = 15000, Year=2005 },
                    new CarInfo() {Model="Ford", Price = 25000, Year=2011 },
                    new CarInfo() {Model="Audi", Price = 10000, Year=2008 },
                    new CarInfo() {Model="Opel", Price = 20000, Year=2017 }};

            Console.WriteLine(String.Join("\n", cars.ToList()));
            Console.WriteLine();
            Array.Sort(cars, new CarComparer());
            Console.WriteLine(String.Join("\n", cars.ToList()));

            CarInfo clone = (CarInfo)cars[0].Clone();

            Console.WriteLine(Object.ReferenceEquals(clone, cars[0]));

            Console.WriteLine(clone.Equals(cars[0]));

            Console.Read();
        }
    }
}
