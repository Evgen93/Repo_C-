﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoStandartInterfaces
{
    internal  class CarInfo : IComparable, ICloneable
    {
        public string Model { get; set; }
        public decimal Price { get; set; }
        public int Year { get; set; }

        public override bool Equals(object obj)
        {
            if (Object.ReferenceEquals(this, obj))
                return true;

            if (obj == null)
                return false;

            if (this.GetType() != obj.GetType())
                return false;

           return  Equals(obj as CarInfo);
        }

        protected bool Equals(CarInfo carInfo)
        {
            if (carInfo ==null)
                return false;

            return this.Model.Equals(carInfo.Model) &&
                    this.Price.Equals(carInfo.Price) &&
                    this.Year.Equals(carInfo.Year);
        }



        public object Clone()
        {
            return new CarInfo()
            {
                Model = this.Model,
                Price = this.Price,
                Year = this.Year
            };
        }

        public int CompareTo(object obj)
        { 
            return this.Price.CompareTo(((CarInfo)obj).Price);
        }

        public override string ToString()
        {
            return $"{Model} {Price:N2} {Year}";
        }
    }
}
