﻿using System;

namespace Matrix
{
    class Matrix
    {
        private int[,] arr;

        private int _column;

        public int LengthColumn
        {
            get { return _column; }
        }

        private int _line;

        public int Lengthline
        {
            get { return _line; }
        }

        private int _maxValue;

        public int MaxValue
        {
            get { return _maxValue; }
        }

        private int _minValue;

        public int MinValue
        {
            get { return _minValue; }
        }



        public Matrix(int column, int line)
        {
            if (column <= 0 || line <= 0)
            {
                throw new ArgumentException("length <= 0");
            }
            _column = column;
            _line = line;

            arr = new int[_column, _line];
            _maxValue = 0;
            _minValue = 0;
        }

        public Matrix(int column, int line, int begin, int end) : this(column, line)
        {
            RandomInit(begin, end);
            GetMaxAndMinValue();
        }

        public Matrix(int[,] userArr)
        {
            if (userArr == null)
            {
                throw new ArgumentException("array is null");
            }

            if (userArr.Length == 0)
            {
                throw new ArgumentException("array length = 0");
            }

            arr = userArr;
            GetMaxAndMinValue();
        }



        //todo: check beg < end
        private void RandomInit(int beg, int end)
        {
            Random rand = new Random();
            for (int i = 0; i < _column; i++)
            {
                for (int j = 0; j < _line; j++)
                {
                    arr[i, j] = rand.Next(beg, end);
                }
            }
        }

        private void GetMaxAndMinValue()
        {
            _maxValue = _minValue = arr[0,0];
            for (int i = 0; i < _column; i++)
            {
                for (int j = 0; j < _line; j++)
                {
                    if (_maxValue < arr[i,j])
                    {
                        _maxValue = arr[i, j];
                    }

                    if (_minValue > arr[i, j])
                    {
                        _minValue = arr[i, j];
                    }
                }
            }
        }
    }
}
