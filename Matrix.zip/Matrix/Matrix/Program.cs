﻿using System;

namespace _Matrix
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] arr = new int[0,1];

            Console.WriteLine(arr.Length);

            Console.Read();
        }
    }
}
