﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example8._2CenericDelegate
{
     
    // Ковариантность и контравариантность делегатов

    // Контравариантность делегатов
    public delegate void DContravariant<in T>(T argument);

    // RКовариантность делегатов
    public delegate T DCovariant<out T>();

    class Program
    {

        static void Main(string[] args)
        {

        }
    }
}
