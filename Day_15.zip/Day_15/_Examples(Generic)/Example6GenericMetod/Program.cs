﻿using System;

namespace Example6GenericMetod
{
	class Program
	{
		public static void Main(string[] args)
		{
			Console.WriteLine("Обобщенные методы!");


            Console.WriteLine("Демонстрация общенного метода взаимной замены...");
			// Обмен  двух значений
            int  a = 10, b = 90;
			Console.WriteLine("Перед: {0}, {1}", a, b); 
			MyClass.Swap<int>(ref a, ref b);
			Console.WriteLine("После: {0}, {1}", a, b); 
			Console.WriteLine();
			
			// Обмен  двух строк.
			string s1 = "Привет", s2 = "Пока"; 
			Console.WriteLine("Перед: {0} {1}!", s1, s2);
			MyClass.Swap<string>(ref s1, ref s2);
            MyClass.Swap(ref s1, ref s2);  
			Console.WriteLine("После: {0} {1}!", s1, s2);


            Console.WriteLine("Демонстрация общенного метода  конвертации...");

            var Result=MyClass.ConvertTo<int, string>(150);
            Console.WriteLine(Result);
            Console.WriteLine(Result.GetType());


			Console.ReadKey(true);
		}
	}
	
	class MyClass
	{
		public static void Swap<T> (ref T a, ref T b)
        {
          Console.WriteLine("Передан в метод Swap() тип {0}", typeof(T)); 
          T temp;
          temp = a;
          a = b;
          b = temp;
        }

        /// <summary>
        /// Обобщенный метод конвертации типов...
        /// </summary>
        /// <typeparam name="TValue">Параметр типа входного значения</typeparam>
        /// <typeparam name="TResult">Параметр типа выходного значения</typeparam>
        /// <param name="value">Входное значение</param>
        /// <returns>Выходное значение</returns>
        public static TResult ConvertTo<TValue, TResult> (TValue value)
        {
            return (TResult)Convert.ChangeType(value, typeof(TResult));
        }
	}
	
	
	
}