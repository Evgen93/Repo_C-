﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example7._2CenericIntreface.Entities
{
    class Truck:Car
    {
    }
}
