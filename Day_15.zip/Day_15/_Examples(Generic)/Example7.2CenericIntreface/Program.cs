﻿using Example7._2CenericIntreface.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example7._2CenericIntreface
{
    // Ковариантность и контравариантность интрефейсов
    class Program
    {
        static void Main(string[] args)
        {
            IContainerGet<Car> listCars = new AutoPark<Car>();         // обычное поведение
            IContainerGet<Truck> listTrucks = new AutoPark<Truck>();   // обычное поведение
            IContainerGet<Car> listCarTrucks = new AutoPark<Truck>();  // невозможно было реализовать без out
          
             IContainerSet<Car> listCars2 = new AutoPark<Car>();
             listCars2.SetItem(new Car());                           // обычное поведение
             listCars2.SetItem(new Truck());                         // невозможно было реализовать без in
        }
    }

    public class AutoPark<T> : IContainerGet<T>, IContainerSet<T>
    {
        private T item;

        public T GetItem()
        {
            return item;
        }
    
        public void SetItem(T value)
        {
 	        item=value;
        }
}


    // В этом обобщенном интерфейсе поддерживается ковариантность
    // ключевое слово out обозначает, что обобщенный тип T является ковариантным. 
    // метод GetItem() может возвращать ссылку на обобщенный тип T или
    // ссылку на любой класс, производный от типа Т,
    // Ограничения:
    //      Ковариантность параметра типа может распространяться только на тип, возвращаемый методом. 
    //      Ковариантность оказывается пригодной только для ссылочных типов. 
    //      Ковариантный тип нельзя использовать в качестве ограничения в интерфейсном методе. 
    public interface IContainerGet<out T>
    {
        T GetItem();
    }

    // В этом обобщенном интерфейсе поддерживается контравариантность 
    // ключевое слово in обозначает, что обобщенный тип T является контравариантным.
    // метод SetItem() может принимать тип аргумента  T или
    // тип аргумента, производный от типа Т,
    // Ограничения:
    //      Контравариантность параметра типа может распространяться только к аргументам методов.
    //      Контравариантность оказывается пригодной только для ссылочных типов. 
    public interface IContainerSet<in T>
    {
        void SetItem(T value);
    }


}
