﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoGenericInterface
{
    public class PingResult
    {
        private string _ip;

        public string Ip
        {
            get { return _ip; }
            set { _ip = value; }
        }

        private TimeSpan _intreval;

        public TimeSpan Intreval
        {
            get { return _intreval; }
            set { _intreval = value; }
        }

        private DateTime _data;

        public DateTime Data
        {
            get { return _data; }
            set { _data = value; }
        }

        public override string ToString()
        {
            return $"{Ip}"; 
        }

    }
}
