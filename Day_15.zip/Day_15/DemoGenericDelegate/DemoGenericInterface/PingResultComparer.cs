﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoGenericInterface
{
    class PingResultComparer : IEqualityComparer<PingResult>
    {
        public bool Equals(PingResult x, PingResult y)
        {
            return x.Ip.Equals(y.Ip);
        }

        public int GetHashCode(PingResult obj)
        {
            return obj.Ip.GetHashCode();
        }
    }
}
