﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoGenericInterface
{
    public class Server
    {
        public PingResult[] Ping()
        {
            return new[]
            {
                new PingResult() { Ip = "192.168.1.111",
                                   Data = new DateTime(2018,02,02),
                                   Intreval = new TimeSpan(0,0,0,550)},
                new PingResult() { Ip = "192.168.1.222",
                                   Data = new DateTime(2018,02,02),
                                   Intreval = new TimeSpan(0,0,0,660)},
                new PingResult() { Ip = "192.168.1.333",
                                   Data = new DateTime(2018,02,02),
                                   Intreval = new TimeSpan(0,0,0,770)},
                new PingResult() { Ip = "192.168.1.222",
                                   Data = new DateTime(2018,02,02),
                                   Intreval = new TimeSpan(0,0,0,888)},
                new PingResult() { Ip = "192.168.1.111",
                                   Data = new DateTime(2018,02,02),
                                   Intreval = new TimeSpan(0,0,0,555)},
            };
        }

           
    }
}
