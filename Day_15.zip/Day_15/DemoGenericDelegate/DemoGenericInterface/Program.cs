﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoGenericInterface
{
    class Program
    {
        static void Main(string[] args)
        {
            Server server = new Server();
            PingResult[] pingResults = server.Ping();
            PingResult[] pingResultsDist = pingResults.Distinct(new PingResultComparer()).ToArray();
            Console.WriteLine(pingResultsDist.Length);

            Console.WriteLine(string.Join("\n", pingResultsDist.ToList()));

            Console.Read();
        }
    }
}
