﻿using System;
using System.IO;

namespace DemoDelegate
{
    class Program
    {
        static void Main(string[] args)
        {

            int[] arr = { 1, 2, 3, 4, 5 };
            Console.WriteLine(string.Join(" ", arr));
            Transformer.Transform(arr, p => p + 10);

            double[] arrD = { 2.5, 3.5, 14.8, 80.2 };
            Console.WriteLine(string.Join(" ", arrD));
            Transformer.Transform(arrD, p => Math.Sin(p));
            Console.WriteLine(string.Join(" ", arrD));

            Console.WriteLine(string.Join(" ", arr));
            
            Console.Read();
        }
    }
}
