﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDelegate
{
    

    public static class Transformer
    {
        public static void Transform<T>(T [] arr, Func<T,T> action) where T: struct
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = action.Invoke(arr[i]);
            }
        }
    }
}
