﻿namespace DemoDelegate
{
    internal class Book
    {
    }
}