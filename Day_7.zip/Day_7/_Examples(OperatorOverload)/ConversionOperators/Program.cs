﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConversionOperators
{
    class Digit1
    {
        public byte value;

        // Конструктор.
        Digit1(byte value)
        {
            this.value = value;
        }

        // Оператор явного преобразования типа byte-to-Digit.
        public static explicit operator Digit1(byte argument)
        {
            Digit1 digit = new Digit1(argument);
            return digit;
        }


        public string GetInfo()
        {
            return this.value.ToString();
        }
    }

    class Digit2
    {
        public byte value;

        // Конструктор.
        Digit2(byte value)
        {
            this.value = value;
        }


        // Оператор неявного преобразования типа byte-to-Digit.
        public static implicit operator Digit2(byte argument)
        {
            Digit2 digit = new Digit2(argument);
            return digit;
        }

        public string GetInfo()
        {
            return this.value.ToString();
        }
    }

    class MainClass
    {
        static void Main()
        {
            byte variable = 1;

            // Явное преобразование byte-to-Digit.
            Digit1 digit1 = (Digit1)variable;

            Console.WriteLine(digit1.GetInfo());

            // Неявное преобразование byte-to-Digit.
            Digit2 digit2 = variable;

            Console.WriteLine(digit2.GetInfo());

            // Delay.
            Console.ReadKey();
        }
    }
}
