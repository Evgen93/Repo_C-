﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Currency cur = new Currency(915, 50);
            Currency cur1 = new Currency(10, 60);
            Currency res = new Currency(0, 0);
            Console.WriteLine(cur.RetAccountFotmatRub() + "," + cur.RetAccountFotmatCoin());

            res = cur + cur1;

            Console.WriteLine(res.RetAccountFotmatRub() + "," + res.RetAccountFotmatCoin());


            Console.Read();
        }
    }
}
