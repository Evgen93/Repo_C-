﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Currency
    {
        #region FIELD
        private int rub;
        public int Rub { get { return rub; } }

        private int coin;
        public int Coin { get { return coin; } }
        #endregion 

        #region CTORS
        public Currency(int _rub, int _coin)
        {
            rub = _rub;
            coin = _coin;
            GetRubFromCoin();
        }
        #endregion

        #region METHODS
        private void GetRubFromCoin()
        {
            int temp = (int)(coin / 100);
            rub += temp;
            coin -= temp * 100;
        }

        public string RetAccountFotmatRub()
        {
            string res = string.Empty;
            {
                if (rub == 1000)
                {
                    return "Тысяча рублей";
                }

                int temp = rub / 100;

                if (temp >= 1)
                {
                    switch (temp)
                    {
                        case 9:
                            res += " Девятьсот";
                            break;
                        case 8:
                            res += " Восемьсот";
                            break;
                        case 7:
                            res += " Семьсот";
                            break;
                        case 6:
                            res += " Шестьсот";
                            break;
                        case 5:
                            res += " Пятььсот";
                            break;
                        case 4:
                            res += " Четыреста";
                            break;
                        case 3:
                            res += " Триста";
                            break;
                        case 2:
                            res += " Двесте";
                            break;
                        case 1:
                            res += " Cто";
                            break;
                        default:
                            break;
                    }
                }

                bool flag = false;
                temp = rub % 100 / 10;
                if (temp >= 2 && temp <= 9)
                {
                    switch (temp)
                    {
                        case 9:
                            res += " Девяноста";
                            break;
                        case 8:
                            res += " Восемьдесят";
                            break;
                        case 7:
                            res += " Семьдесят";
                            break;
                        case 6:
                            res += " Шестьдесят";
                            break;
                        case 5:
                            res += " Пятьдесят";
                            break;
                        case 4:
                            res += " Сорок";
                            break;
                        case 3:
                            res += " Тридцать";
                            break;
                        case 2:
                            res += " Двадцать";
                            break;
                        case 1:
                            res += " Десять";
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    flag = true;
                }

                temp = rub % 10;
                if (temp >= 1)
                {
                    switch (temp)
                    {
                        case 9:
                            res += " Девять";
                            if (flag) { res += "\bнадцать"; }
                            break;
                        case 8:
                            res += " Восемь";
                            if (flag) { res += "\bнадцать"; }
                            break;
                        case 7:
                            res += " Семь";
                            if (flag) { res += "\bнадцать"; }
                            break;
                        case 6:
                            res += " Шесть";
                            if (flag) { res += "\bнадцать"; }
                            break;
                        case 5:
                            res += " Пять";
                            if (flag) { res += "\bнадцать"; }
                            break;
                        case 4:
                            res += " Четыре";
                            if (flag) { res += "\bнадцать"; }
                            break;
                        case 3:
                            res += " Три";
                            if (flag) { res += "надцать"; }
                            break;
                        case 2:
                            res += " Два";
                            if (flag) { res += "\bенадцать"; }
                            break;
                        case 1:
                            res += " Один";
                            if (flag) { res += "\bнадцать"; }
                            break;
                        default:
                            break;
                    }
                }

                if (res == string.Empty)
                {
                    return "Ноль";
                }

                if (temp == 1)
                {
                    res += " рубль";
                    return res;
                }
                else if (temp >= 2 && temp <= 4)
                {
                    res += " рубля";
                    return res;
                }
                else
                {
                    res += " рублей";
                    return res;
                }

            }
        }

        public string RetAccountFotmatCoin()
        {
            string res = string.Empty;

            int temp = coin / 10;
            if (temp >= 1)
            {
                switch (temp)
                {
                    case 9:
                        res += " Девяноста";
                        break;
                    case 8:
                        res += " Восемьдесят";
                        break;
                    case 7:
                        res += " Семьдесят";
                        break;
                    case 6:
                        res += " Шестьдесят";
                        break;
                    case 5:
                        res += " Пятьдесят";
                        break;
                    case 4:
                        res += " Сорок";
                        break;
                    case 3:
                        res += " Тридцать";
                        break;
                    case 2:
                        res += " Двадцать";
                        break;
                    case 1:
                        res += " Десять";
                        break;
                    default:
                        break;
                }
            }

            temp = coin % 10;
            if (temp >= 1)
            {
                switch (temp)
                {
                    case 9:
                        res += " Девять";
                        break;
                    case 8:
                        res += " Восемь";
                        break;
                    case 7:
                        res += " Семь";
                        break;
                    case 6:
                        res += " Шесть";
                        break;
                    case 5:
                        res += " Пять";
                        break;
                    case 4:
                        res += " Четыре";
                        break;
                    case 3:
                        res += " Три";
                        break;
                    case 2:
                        res += " Два";
                        break;
                    case 1:
                        res += " Один";
                        break;
                    default:
                        break;
                }
            }

            if (res == string.Empty)
            {
                return "Ноль";
            }

            if (temp == 1)
            {
                res += " копейка";
                return res;
            }
            else if (temp >= 2 && temp <= 4)
            {
                res += " копейки";
                return res;
            }
            else
            {
                res += " копеек";
                return res;
            }
        }

        public string RetInShortFormat()
        {
            string res = Convert.ToString(rub) + "руб. " + Convert.ToString(coin) + "коп.";
            return res;
        }

        public int AmountOfCoin()
        {
            int temp = coin + (rub * 100);
            return temp;
        }

        #endregion

        #region OPERATORS
        public static Currency operator +(Currency right, Currency left)
        {
            Currency Cur = new Currency((right.rub + left.rub), (right.coin + left.coin));
            return Cur;
        }

        public static Currency operator -(Currency right, Currency left)
        {
            //TODO: отрицательное значение
            Currency Cur = new Currency((right.rub - left.rub), (right.coin - left.coin));
            return Cur;
        }

        public static Currency operator *(Currency right, Currency left)
        {
            Currency Cur = new Currency(0, (right.AmountOfCoin() * left.AmountOfCoin()));
            return Cur;
        }
        #endregion
    }
}
