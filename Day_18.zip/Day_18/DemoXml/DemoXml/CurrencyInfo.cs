﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoXml
{
    public class CurrencyInfo
    {
        public string CharCode { get; internal set; }
        public string Name { get; internal set; }
        public ushort NumCode { get; internal set; }
        public decimal Rate { get; internal set; }
    }
}
