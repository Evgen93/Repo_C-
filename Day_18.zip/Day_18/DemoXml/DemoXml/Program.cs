﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoXml
{
    class Program
    {
        static void Main(string[] args)
        {
            DailyExRatesInfo value = CyrrencyReader.Read();
            Console.WriteLine(value.Date);
            foreach (var item in value.Currencies)
            {
                Console.WriteLine($"{item.CharCode} {item.Name} {item.Rate}");
            }
            Console.Read();
        }
    }
}
