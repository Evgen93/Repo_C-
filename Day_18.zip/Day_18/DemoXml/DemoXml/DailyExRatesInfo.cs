﻿using DemoXml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoXml
{
    public class DailyExRatesInfo
    {
        public string Date { get; set; }
        public List<CurrencyInfo> Currencies { get; set; }
        
        public DailyExRatesInfo()
        {
            Currencies = new List<CurrencyInfo>();
        }
    }
}
