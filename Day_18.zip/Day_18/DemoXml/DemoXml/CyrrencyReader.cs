﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DemoXml
{
    public class CyrrencyReader
    {
        private static string _url = @"http://www.nbrb.by/Services/XmlExRates.aspx";

        public static DailyExRatesInfo Read()
        {
            XDocument doc = XDocument.Load(_url);
            XElement root = doc.Root;

            NumberFormatInfo numberFormat = new NumberFormatInfo { NumberDecimalSeparator = "." };

            DailyExRatesInfo dailyExRatesInfo = new DailyExRatesInfo();
            dailyExRatesInfo.Date = root.Attribute("Date").Value;

            foreach (var item in root.Elements())
            {
                CurrencyInfo currencyInfo = new CurrencyInfo();
                currencyInfo.Name = item.Element("Name").Value;
                currencyInfo.NumCode = Convert.ToUInt16(item.Element("NumCode").Value);
                currencyInfo.CharCode = item.Element("CharCode").Value;
                currencyInfo.Rate = decimal.Parse(item.Element("Rate").Value, numberFormat);
                dailyExRatesInfo.Currencies.Add(currencyInfo);
            }
            return dailyExRatesInfo;
        }
    }
}
