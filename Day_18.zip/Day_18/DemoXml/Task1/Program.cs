﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            XDocument xdoc = XDocument.Load(@"http://informer.gismeteo.by/rss/35188.xml");
            XElement root = xdoc.Root.Element("channel");
            Console.WriteLine(root.Elements("item").Count());
            foreach (var item in root.Elements("item"))
            {
                Console.WriteLine(item.Element("title").Value);
                Console.WriteLine(item.Element("description").Value);
                Console.WriteLine(new string('-', 80));
            }
            Console.Read();
        }
    }
}
