﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Example5DemoDebug
{

    // Демонстрация различных вариантов работы в режиме Debug/Realease
    class Program
    {
        static void Main(string[] args)
        {
            // Создание  объекта  Timer, 
            // вызывающе го  метод  Ti merCallback  2000  миллисекунд 
            Timer  t  =  new  Timer(TimerCallback, null,  0,  2000); 
            // Ждем ,  когда  пользователь  нажмет  Enter 
            Console.ReadLine();
            
             //t=null;
             t.Dispose();
        }
        private static void TimerCallback(Object о)  
        { 
            // Вывод  даты/ времени  вызова  этого  метода 
            Console.WriteLine ( " In  TimerCallback : " +  DateTime.Now) ; 
            //  Принуди тел ьный  вызов  сборщика  мусора  в  этой  программе 
            GC.Collect();
        }
    }
}
