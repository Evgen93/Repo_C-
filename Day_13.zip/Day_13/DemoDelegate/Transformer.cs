﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDelegate
{
    public delegate int Action(int item);

    
    public static class Transformer
    {
        public static void Transform(int[] arr, Action action)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = action.Invoke(arr[i]);
            }
        }
    }
}
