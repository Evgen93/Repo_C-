﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDelegate
{
    public class Operations
    {
        public int ToPow2(int number)
        {
            return number * number;
        }

        public int Add10(int number)
        {
            return number + 10;
        }
    }
}
