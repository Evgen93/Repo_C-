﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoDelegate
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = {1, 2, 3, 4, 5};
            Console.WriteLine(string.Join(" ", arr));

            Operations operations = new Operations();
            //Transformer.Transform(arr, operations.Add10);

            /* Action ToPow2 = delegate(int number)
             {
                 return number + number;
             };*/

            Action add10 = n => n + 10;

            Transformer.Transform(arr, delegate (int number){return number * number;});
            Transformer.Transform(arr, n => n + 10);
            Console.WriteLine(string.Join(" ", arr));

            Console.Read();
        }
    }
}
