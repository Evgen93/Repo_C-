﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DrinkerLib
{
    class Karta
    {
        public Suit suit { get; private set; }

        public Values value { get; private set; }

        public Karta(Suit suit, Values value)
        {
            this.suit = suit;
            this.value = value;
        }

        public override string ToString()
        {
            return $"{suit} {value}";
        }
    }
}
