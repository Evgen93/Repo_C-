﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DrinkerLib
{
    public class Game
    {
        private List<Karta> _cards;

        public Game()
        {
            _cards = new List<Karta>();
            CreateCartDeck();

        }

        private void CreateCartDeck()
        {
            Array arrSuits = Enum.GetValues(typeof(Suit));
            Array arrValues = Enum.GetValues(typeof(Values));

            for (int i = 0; i < arrSuits.Length; i++)
            {
                for (int j = 0; j < arrValues.Length; j++)
                {
                    Karta card = new Karta((Suit)arrSuits.GetValue(i), (Values)arrValues.GetValue(j));
                    _cards.Add(card);
                }
            }
        }
    }
}
