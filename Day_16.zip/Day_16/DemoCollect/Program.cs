﻿using DrinkerLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoCollect
{
    class Program
    {
        static void Main(string[] args)
        {
            Game game = new Game();

            List<Player> players = new List<Player>()
            {
                new Player() {Name = "Ivan", Age = 25, Salary = 7000},
                new Player() {Name = "Alex", Age = 45, Salary = 12000},
                new Player() {Name = "Inna", Age = 21, Salary = 5500},
            };

            players.Add(new Player() { Name = "Igor", Age = 40, Salary = 1300.12m});

            List<string> names = players.ConvertAll(p => p.Name);
            List<PlaerDto> money =  players.ConvertAll(p => new PlaerDto() { LastName = p.Name, Money = p.Salary * p.Age });
            List<Player> plBysalary = players.FindAll(p => p.Salary > 5000);
            Player selectPlayer = players.Find(p => p.Name.Equals("Ivan"));
            players.ForEach(P => P.Salary += 100m);
            bool hasOldPlayer = players.Exists(p=>p.Age>40);
            players.Sort((p1, p2)=> p1.Salary.CompareTo(p2.Salary));

            Console.Read();
        }

        public  class PlaerDto
        {
            public string LastName { get; set; }

            public decimal Money { get; set; }

        }
    }
}
