﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace ExampleListMetods
{
    class Program
    {
        static void Main(string[] args)
        {
            List<CarInfo> cars = new List<CarInfo>()
            {
                new CarInfo{Id=1, Name="BMW", Price=5000, Date=new DateTime(2015,10,15)},
                new CarInfo{Id=2, Name="Ford", Price=7500, Date=new DateTime(2013,04,24)},
                new CarInfo{Id=3, Name="Audi", Price=4500, Date=new DateTime(2016,07,30)},
                new CarInfo{Id=4, Name="Opel", Price=3900, Date=new DateTime(2012,12,07)},
            };

            // Доавление одного элемента в коллекцию
            cars.Add(new CarInfo { Id = 5, Name = "Jeep", Price = 9500, Date = new DateTime(2010, 03, 07) });

            // Добавление списка (тип IEnumerable<> - List, Array) в коллекцию
            cars.AddRange(new List<CarInfo>()
            {
                new CarInfo { Id = 6, Name = "Toyota", Price = 7700, Date = new DateTime(2007, 09, 01)},
                new CarInfo { Id = 7, Name = "KIA", Price = 9600, Date = new DateTime(2009, 02, 19)},
                new CarInfo { Id = 8, Name = "Mercedes", Price = 10100, Date = new DateTime(2017, 03, 30)},
            });
            

            // Получение объекта по индексатору
            CarInfo selCar = cars[0];


            // Конвертирует элементы коллекции cars в
            // коллекцию типа List<T> другого типа 
            List<string> lstNames = cars.ConvertAll(p => p.Name);
            List<CarInfoDTO> lstCarsDTO = cars.ConvertAll<CarInfoDTO>(p => new CarInfoDTO { FullName = p.Name, DateCreate = p.Date });

            // Определяет наличие элемента в коллекции по параметрам,
            // переданным через Predicate, возврашающий bool
            bool IsExistsByName = cars.Exists(p => p.Name.Equals("Ford"));
            bool IsExistsByNameAndPrice = cars.Exists(p => p.Name.Equals("Ford") && p.Price == 5000);

            // Определяет наличие элемента в коллекции по ссылке на объект.
            bool IsExistObject = cars.Contains(selCar);

            // Поиск элемента в коллекции по параметрам,
            // переданным через Predicate, возврашающий bool
            CarInfo findCar = cars.Find(p => p.Name.Equals("Ford"));
            
            // Поиск элемента c конца в коллекции по параметрам,
            // переданным через Predicate, возврашающий bool
            CarInfo findCarLast = cars.FindLast(p => p.Name.Equals("Ford"));

            // Поиск индекса элемента в коллекции по параметрам,
            // переданным через Predicate, возврашающий bool
            int indexCar = cars.FindIndex(p => p.Name.Equals("Ford"));
            int startIndex = 3;  // индекс элемента, с которого начинается поиск
            int count =4;        // количество элементов в блоке поиска
            int indexCarToStart = cars.FindIndex(startIndex,count, p => p.Name.Equals("Ford") && p.Price == 5000);

            // Поиск индекса элемента  c конца в коллекции по параметрам,
            // переданным через Predicate, возврашающий bool
            int indexCarLast = cars.FindLastIndex(p => p.Name.Equals("Ford"));           

            // Поиск элементов в коллекции по параметрам,
            // переданным через Predicate, возврашающий bool
            List<CarInfo> findCars = cars.FindAll(p => p.Name.Equals("Ford") && p.Price == 5000);

            decimal RateNds= 0.20m;
            // Выполняет перебор каждого элемента и выполняет для элемента действие
            cars.ForEach(p => p.Price = p.Price + p.Price * RateNds);
            cars.ForEach(p => p.Name = p.Name.ToUpper());
            cars.ForEach(p =>
            {   if (p.Date > new DateTime(2017, 07, 01))
                    p.Price = p.Price + p.Price * RateNds;  });    
            cars.ForEach(p => Console.Write(p));

            // Получение списка элеметов, начиная с index, в количестве count
            List<CarInfo> carsRange = cars.GetRange(index:2, count:3);

            // Проверяет отвечают ли все объекты условию, 
            // переданному через Predicate
            bool IsTrueForAll = cars.TrueForAll(p => p.Price >= 3900);

            // Преобразование коллекции в массив
            CarInfo[] carsArr = cars.ToArray();

            // Сортировка на основе интерфейса IComparer<T>
            cars.Sort(new CarComparer());
            cars.Sort(index: 2, count: 4, comparer: new CarComparer());
            
            // Сортировка на основе делегата Comparison
            cars.Sort((x, y) => x.Price.CompareTo(y.Price));

            // Вставка элемента в коллекцию
            int indexInsert = 4;
            cars.Insert(indexInsert, new CarInfo() { Id = 9, Name = "Honda", Price = 8400, Date = new DateTime(2013, 07, 13) });
            
            // Вставка диапазона элементов в коллекцию
            cars.InsertRange(indexInsert, new List<CarInfo>() 
            {
                new CarInfo { Id = 10, Name = "Nissan", Price = 5900, Date = new DateTime(2002, 04, 21)},
                new CarInfo { Id = 11, Name = "Mazda", Price = 7700, Date = new DateTime(2008, 10, 06)},
            });

            // Получение копии диапазона элементов 
            List<CarInfo> getCars = cars.GetRange(index: 0, count: 4);
 

            // Удаление объекта по ссылке
            cars.Remove(selCar);

            // Удаление объекта по индексу в коллекции
            cars.RemoveAt(index:0);

            // Удаление всех объектов, отвечающих по параметрам,
            // переданным через Predicate, возврашающий bool
            cars.RemoveAll(p => p.Price > 1000);

            // Удаление диапазона объектов 
            cars.RemoveRange(index: 0, count: 3);

            // Очистка элементов коллекции
            cars.Clear();

        }
    }

    class CarInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public DateTime Date { get; set; }

    }

    class CarInfoDTO
    {
        public string FullName { get; set; }
        public DateTime DateCreate { get; set; }
    }

    class CarComparer : IComparer<CarInfo>
    {
        public int Compare(CarInfo x, CarInfo y)
        {
            return x.Price.CompareTo(y.Price);
        }
    }


}
