﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// подключаем пространство имен
using FriendAssemblies;

namespace Example1._1StandartAttribute
{
    class Program
    {
        static void Main(string[] args)
        {
            // Работа с дружественными сборками! 
            ShopCars shop = new ShopCars();

            Console.WriteLine("В магазине всего авто: " + shop.CountCars);

            // создание объекта internal CarInfo
            CarInfo carInfo = new CarInfo()
            {
                Name="BMW"
            };

            // вызов internal метода класса ShopCars
            shop.AddCar(carInfo);

            Console.WriteLine("В магазине всего авто: " + shop.CountCars);

            Console.ReadKey();

        }
    }
}
