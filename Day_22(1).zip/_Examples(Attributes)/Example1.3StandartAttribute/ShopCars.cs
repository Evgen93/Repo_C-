﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example1._3StandartAttribute
{
    public class ShopCars
    {
        List<CarInfo> lstCars;

        public ShopCars()
        {
            lstCars = new List<CarInfo>();
        }

        public int CountCars
        {
            get { return lstCars.Count; }
        }

        public void AddCar(CarInfo car)  // метод тоже internal т.к. работает с internal CarInfo
        {                                  //  public нельзя т.к. inconsistent accessibility  
            lstCars.Add(car);
            Loger.LogWrite();
        }

        public void DeleteCar(CarInfo car)  // метод тоже internal т.к. работает с internal CarInfo
        {                                  //  public нельзя т.к. inconsistent accessibility  
            lstCars.Remove(car);
            Loger.LogWrite();
        }

    }
}
