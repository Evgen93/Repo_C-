﻿using System;
using System.IO;
using System.Runtime.CompilerServices;

namespace Example1._3StandartAttribute
{
    static class Loger
    {
        // аттрибут CallerMemberName используется только в методах 
        // с необязательными параметрами
        public static void LogWrite([CallerMemberName] string MemberName="")
        {
            File.AppendAllText("log.txt", MemberName);
        }
    }
}


