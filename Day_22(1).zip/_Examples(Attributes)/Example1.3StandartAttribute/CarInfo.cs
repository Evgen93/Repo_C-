﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Example1._3StandartAttribute
{
    public class CarInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
