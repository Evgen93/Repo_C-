﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Example1._3StandartAttribute
{
    class Program
    {
        static void Main(string[] args)
        {
           
            ShopCars shop = new ShopCars();

            Console.WriteLine("В магазине всего авто: " + shop.CountCars);

            CarInfo carInfo1 = new CarInfo() { Name = "BMW"};
            shop.AddCar(carInfo1);
            CarInfo carInfo2 = new CarInfo() { Name = "Ford" };
            shop.AddCar(carInfo2);   
            Console.WriteLine("В магазине всего авто: " + shop.CountCars);
            
            
            shop.DeleteCar(carInfo2);
            Console.WriteLine("В магазине всего авто: " + shop.CountCars);
            Console.ReadKey();

        }
    }

   

}
