﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Example6ISerializaЬle
{
    class Program
    {
        static void Main(string[] args)
        {
            ShoppingCartItem item = new ShoppingCartItem("BMW", 5000, 2);

            BinaryFormatter xml = new BinaryFormatter();
            using (FileStream file = new FileStream("data.dat", FileMode.Create))
            {
                xml.Serialize(file, item);
            }

            Console.WriteLine("Информация (сериализация):");
            Console.WriteLine(item);

            ShoppingCartItem itemNew;
            using (FileStream file = new FileStream("data.dat", FileMode.Open))
            {
                itemNew = (ShoppingCartItem)xml.Deserialize(file);
            }
            Console.WriteLine("Информация (десериализация):");
            Console.WriteLine(itemNew);

            Console.ReadKey();
        }
    }

    [Serializable]
    class ShoppingCartItem : ISerializable
    {
        private string productName;
        private decimal price;
        private Int32 quantity;
        [NonSerialized]
        private decimal total;


        public ShoppingCartItem(string _productName, decimal _price, int _quantity)
        {
            productName = _productName;
            price = _price;
            quantity = _quantity;
        }

       
        private ShoppingCartItem(SerializationInfo info, StreamingContext context)
        {
            productName = info.GetString("Product Name");
            price = info.GetDecimal("Price");
            quantity = info.GetInt32("Quantity");
            total = price * quantity;
        }

        // обеспечивает интрфейс ISerializable
        public virtual void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue("Product Name", productName);
            info.AddValue("Price", price);
            info.AddValue("Quantity", quantity);
        }

        public override string ToString()
        {
            return productName + ": " + price + " x " + quantity + " = " + total;
        }
    }

}
