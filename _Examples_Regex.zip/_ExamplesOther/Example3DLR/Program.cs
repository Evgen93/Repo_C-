﻿using System;


namespace Example3DLR
{
	class Program
	{
		static void Main(string[] args)
		{
			dynamic obj = 50;
			Console.WriteLine(obj);

			obj = "Dynamic Language Runtime";
			Console.WriteLine(obj);

			obj = new Server("localhost", "127.0.0.1");
			obj.Ping();
			Console.WriteLine(obj);
			obj.ViewBag = "локальный сервер";
			

			Server server = new Server("Common", "192.168.1.1")
			{
				Tag = new { OS = "Windows", Port = 8080 }
			};
			

			Console.ReadKey();
		}
	}
}
