﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example3DLR
{
	internal sealed class Server
	{
		private string _serverName;
		private string _ip;

		public dynamic Tag { get; set; }

		public Server(string serverName, string ip)
		{
			_serverName = serverName;
			_ip = ip;
		}

		public void Ping()
		{

		}

		public override string ToString()
		{
			return $"{_serverName} - {_ip} ";
		}
	}
}
