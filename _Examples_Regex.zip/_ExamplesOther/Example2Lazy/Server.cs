﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Example2Lazy
{
	internal sealed class Server
	{
		private readonly Lazy<PingHistory> _history;

		public Server()
		{
			_history=new Lazy<PingHistory>();
		}

		public List<PingResult> GetHistory()
		{
			return _history.Value.GetHistory();
		}

	}
}
