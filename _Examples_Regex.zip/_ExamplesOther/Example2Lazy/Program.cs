﻿using System;

namespace Example2Lazy
{
	class Program
	{
		static void Main()
		{
			Server server = new Server();
			server.GetHistory();
			Console.ReadKey();
		}
	}
}
