﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example2Lazy
{
	internal class PingHistory
	{

		private readonly List<PingResult> _pingResults;

		public PingHistory()
		{
			_pingResults = new List<PingResult>();
		}

		public List<PingResult> GetHistory()
		{
			_pingResults.Add(new PingResult() { Ip = "192.168.1.111", Date = new DateTime(2018, 10, 1) });
			_pingResults.Add(new PingResult() { Ip = "192.168.1.222", Date = new DateTime(2018, 10, 3) });
			_pingResults.Add(new PingResult() { Ip = "192.168.1.333", Date = new DateTime(2018, 10, 4) });
			_pingResults.Add(new PingResult() { Ip = "192.168.1.546", Date = new DateTime(2018, 10, 3) });
			_pingResults.Add(new PingResult() { Ip = "192.168.1.123", Date = new DateTime(2018, 10, 4) });


			return _pingResults;
		}



	}
}
