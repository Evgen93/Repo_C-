﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example2Lazy
{
	public class PingResult
	{
		public string Ip { get; set; }

		public DateTime Date { get; set; }

		public TimeSpan Interval { get; set; }
	}
}
