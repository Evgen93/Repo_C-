﻿using System;
using System.Diagnostics;


namespace Example_Conditional
{

	[DebuggerDisplay("{_serverName}: {_ip}")]
	internal sealed class Server
	{
		private string _serverName;
		private string _ip;

		[DebuggerBrowsable(DebuggerBrowsableState.Collapsed)]
		private Configuration _configuration;

		public Server(string serverName, string ip)
		{
			_serverName = serverName;
			_ip = ip;
			_configuration = new Configuration("Linux", 4);
		}

		internal void Ping()
		{
			Console.WriteLine("Ping...");
		}

		[Conditional("DEBUG")]
		internal void PingDebug()
		{
			Console.WriteLine("PingDebug...");
		}

		[Conditional("TRACE")]
		internal void PingTrace()
		{
			Console.WriteLine("PingTrace...");
		}

	}
}
