﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_Conditional
{
	internal class Configuration
	{
		public string  Version { get; }
		public int CountProcessors { get; }

		public Configuration(string version, int countProcessors)
		{
			Version = version;
			CountProcessors = countProcessors;
		}

		public override string ToString()
		{
			return $"{Version} {CountProcessors}";
		}
	}
}
