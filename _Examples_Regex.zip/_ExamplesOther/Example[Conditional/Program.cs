﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Example_Conditional
{
	class Program
	{
		/*
		 * Демонстрация возможностей по диагностике System.Diagnostics
		 * [Conditional] - вкл/выкл - в зависимости от Debug/Release 
		 * [DebuggerDisplay] - установка полей/свойств для отображения в режиме Debug
		 *  режимы: Debug, Trace
		 * [DebuggerBrowsable]- вкл/выкл. отображения  значения в режиме Debug
		 *  режимы:Never, Collapsed, RootHidden,
		 *
		 */
		static void Main()
		{
			Server server = new Server("mainServer", "192.168.1.77");
			server.Ping();
			server.PingDebug();
			server.PingTrace();

			var fileInfo = FileVersionInfo.GetVersionInfo(Path.Combine(Environment.SystemDirectory, "Notepad.exe"));
			Console.WriteLine(fileInfo.OriginalFilename);	

			try
			{
				EventLogHelper.CreateSource("testEventLog", "testLog");
				EventLogHelper.SetSource("testEventLog");
				EventLogHelper.WriteLog("Test", EventLogEntryType.Error);
			}
			catch(Exception ex)
			{
				Console.WriteLine(ex.Message);
			}


			Console.ReadLine();
		}
	}
}
