﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example_Conditional
{
	public static class EventLogHelper
	{
		private static EventLog _eventLog;

		static EventLogHelper()
		{
			_eventLog = new EventLog();
		}

		public static bool IsExistSource(string sourceName)
		{
			return EventLog.SourceExists(sourceName);
		}

		public static void CreateSource(string sourceName, string logName)
		{
			if (IsExistSource(sourceName))
				throw new Exception("Source is exists");

			if (String.IsNullOrWhiteSpace(logName))
				throw new Exception("Log Name  is empty");

			EventLog.CreateEventSource(sourceName, logName);
		}

		public static void SetSource(string sourceName)
		{
			_eventLog.Source = sourceName;
		}

		public static void WriteLog(string message, EventLogEntryType eventLogEntryType = EventLogEntryType.Information)
		{
			if (String.IsNullOrWhiteSpace(_eventLog.Source))
				throw new Exception("Log Source  is empty");

			_eventLog.WriteEntry(message, eventLogEntryType);
		}

	}
}
