﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example4DLR
{
	class Program
	{
		static void Main(string[] args)
		{
			dynamic server = new System.Dynamic.ExpandoObject();
			server.Name = "Common";
			server.Speed = 100;
			server.IPs = new List<string> { "192.168.1.10", "192.168.1.15", "192.168.1.20" };

			Console.WriteLine("{0} - {1}", server.Name, server.Speed);
			foreach (var lang in server.IPs)
				Console.WriteLine(lang);

			// объявляем метод
			server.SearchIp = (Func<string, bool>)(ip => server.IPs.Contains(ip));
			var isExists = server.SearchIp("192.168.1.15");
			Console.WriteLine($"Ip: 192.168.1.15 exists: {isExists}");



			dynamic serverDynamicObj = new ServerDynamicObject();
			serverDynamicObj.Name = "MainServer";
			serverDynamicObj.Speed = 100;
			serverDynamicObj.SpeedUp = (Func<int, int>)(p=> serverDynamicObj.Speed += p);
			serverDynamicObj.SpeedUp(20);
			Console.WriteLine(serverDynamicObj);

			Console.ReadKey();
		}
	}
}
