﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;

namespace Example4DLR
{
	public sealed class ServerDynamicObject : DynamicObject
	{
		private readonly Dictionary<string, object> _members;

		public ServerDynamicObject()
		{
			_members = new Dictionary<string, object>();
		}

		public override bool TrySetMember(SetMemberBinder binder, object value)
		{
			_members[binder.Name] = value;
			return true;
		}

		public override bool TryGetMember(GetMemberBinder binder, out object result)
		{
			result = null;
			if (_members.ContainsKey(binder.Name))
			{
				result = _members[binder.Name];
				return true;
			}
			return false;
		}

		public override bool TryInvokeMember(InvokeMemberBinder binder, object[] args, out object result)
		{
			dynamic method = _members[binder.Name];
			result = method((int)args[0]);
			return result != null;
		}

		public override string ToString()
		{
			var values=new StringBuilder();
			foreach (var member in _members)
			{
				values.AppendLine($"{member.Key}:{member.Value}");
			}

			return values.ToString();
		}
	}
}
