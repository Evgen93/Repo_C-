﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
using log4net;

namespace Example1Log4Net
{

	//https://logging.apache.org/log4net/release/manual/configuration.html

	/*
	 * Install-Package log4net
	 * Add log4net.config file (Set “Copy to Output Directory” to “Copy Always”)
	 * Add to AssemblyInfo file [assembly: log4net.Config.XmlConfigurator(ConfigFile = "log4net.config")]
	 */
	class Program
	{
		static void Main()
		{
			Console.WriteLine("Demo log4net.");

			Log.Logger.Info("Test INFO message to log4net");
			Log.Logger.Warn("Test WARN message to log4net");
			Log.Logger.Error("Test ERROR message to log4net");
			Log.Logger.Debug("Test Debug message to log4net");

			Console.ReadKey();
		}
	}
}
