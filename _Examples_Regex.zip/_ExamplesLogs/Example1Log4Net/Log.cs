﻿using System;
using System.Reflection;
using log4net;

namespace Example1Log4Net
{
	public static class Log
	{
		public static ILog Logger { get; private set; }

		static Log()
		{
			Type currentType = MethodBase.GetCurrentMethod().DeclaringType;
			Logger = LogManager.GetLogger(currentType);
		}
	}
}
