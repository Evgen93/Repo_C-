﻿using System;
using NLog;


namespace Example3NLog
{
	//https://github.com/NLog/NLog/wiki/Tutorial

	/*
	 * Install-Package NLog
	 * Add config file (Set “Copy to Output Directory” to “Copy Always”)
	 */

	class Program
	{
		static void Main(string[] args)
		{

			Log.ConfigFromConfigFile("nlog.config");
			try
			{
				Log.Logger.Info("Test INFO message to NLog");
				Log.Logger.Warn("Test WARN message to NLog");
				Log.Logger.Error("Test ERROR message to NLog");
				Log.Logger.Debug("Test Debug message to NLog");
				Log.Logger.Log(LogLevel.Info, "Sample informational message");

			}
			catch (Exception ex)
			{
				Log.Logger.Error(ex, "Exception");
			}

			Console.ReadKey();
		}
	}
}
