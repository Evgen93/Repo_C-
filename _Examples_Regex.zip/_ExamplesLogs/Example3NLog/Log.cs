﻿using System;
using NLog;

namespace Example3NLog
{
	public static class Log
	{

		public static Logger Logger => LogManager.GetCurrentClassLogger();

		static Log()
		{
			ConfigDefault();
		}

		private static void ConfigDefault()
		{
			var config = new NLog.Config.LoggingConfiguration();

			var logfile = new NLog.Targets.FileTarget("logfile") { FileName = "logfile.log" };
			var logconsole = new NLog.Targets.ConsoleTarget("logconsole");

			config.AddRule(LogLevel.Info, LogLevel.Fatal, logconsole);
			config.AddRule(LogLevel.Debug, LogLevel.Fatal, logfile);

			LogManager.Configuration = config;
		}

		public static void ConfigFromConfigFile(string configFileName)
		{
			LogManager.LoadConfiguration(configFileName);
		}


	}
}
