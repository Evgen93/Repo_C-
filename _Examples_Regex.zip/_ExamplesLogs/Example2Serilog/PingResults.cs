﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Example2Serilog
{
	public class PingResults
	{
		public string Ip { get; set; }
		public int PingInterval { get; set; }
		public DateTime Date { get; set; }

		public override string ToString()
		{
			return $"{Ip} {PingInterval} {Date:d}";
		}
	}
}
