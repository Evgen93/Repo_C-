﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Serilog;
using Serilog.Events;
using Serilog.Filters;

namespace Example2Serilog
{

	// https://serilog.net/

	/*
	 * Install-Package Serilog
	 * Install-Package Serilog.Sinks.Console
	 * Install-Package Serilog.Sinks.File
	 */
	class Program
	{
		static void Main()
		{
			// Конфигурирование 
			Log.Config(() =>
				new LoggerConfiguration()
				.WriteTo.Console()
				.WriteTo.File("logfile.log")
				.CreateLogger());

			WriteLogInfo();

			Console.WriteLine("MinimumLevel");

			Log.Config(() =>
				new LoggerConfiguration()
					.WriteTo.Console
					(
						outputTemplate: "{Timestamp:dd.MM.yyyy HH:mm:ss.fff} [{Level:u5}] {Message:lj}{NewLine}",
						restrictedToMinimumLevel:LogEventLevel.Warning
						)
					.MinimumLevel.Error()
					.WriteTo.File("logerrors-.txt", rollingInterval: RollingInterval.Day)
					.CreateLogger());

			
			WriteLogInfo();

			Log.Config(() =>
				new LoggerConfiguration()
					.WriteTo.Console()
					.CreateLogger());


			Console.WriteLine("Writing Log");
			int errorCode = 404;
			string siteName = "logoff.net";
			Log.Logger.Error("Ошибка {errorCode} при ображении к сайту {siteName}", errorCode, siteName);
			Log.Logger.Error("Ошибка по времени {Now}", DateTime.Now);


			Dictionary<string, int> pingResults = new Dictionary<string, int>
			{
				{"192.168.2.111", 500},
				{"192.168.2.222", 350}
			};
			Log.Logger.Information("Результаты {pingResults}", pingResults);


			List<PingResults> pingResults2 = new List<PingResults>()
			{
				new PingResults() {Ip = "192.168.1.11.", PingInterval = 500, Date = new DateTime(2018, 10, 25)},
				new PingResults() {Ip = "192.168.1.22.", PingInterval = 750, Date = new DateTime(2018, 10, 27)}
			};
			Log.Logger.Information("Результаты {pingResults2}", pingResults2);

			var serverNames = new {ServerName = "Mainserver", Ip="192.168.1.100" };
			Log.Logger.Debug("Сервер: {serverNames}", serverNames);

			
			Console.ReadKey();
		}

		private static void WriteLogInfo()
		{
			Log.Logger.Information("Test INFO message to serilog");
			Log.Logger.Warning("Test WARN message to serilog");
			Log.Logger.Error("Test ERROR message to serilog");
			Log.Logger.Fatal("Test FATAL message to serilog");
		}
	}
}
