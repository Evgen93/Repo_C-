﻿using System;
using Serilog;
using Serilog.Core;

namespace Example2Serilog
{
	public static class Log
	{

		public static Logger Logger { get; private set; }

		static Log()
		{
			DefaultConfig();
		}

		private static void DefaultConfig()
		{
			Logger = new LoggerConfiguration().CreateLogger();
		}
		
		public static void Config(Func<Logger> func)
		{
			Logger = func.Invoke();
		}
		
	}
}
