﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Example9ViewsAdd
{
    class Program
    {
        static void Main(string[] args)
        {
            string Message = "^CR= два три два один два один^";
            Console.WriteLine("Текст: " + Message);
            MatchCollection rez1 = Regex.Matches(Message, @"(?<=CR\=)(.*?)(?=\^)");
          
            foreach (Match item in rez1)
            { Console.WriteLine(item.Value); }

            Console.ReadKey();
        }
    }
}
