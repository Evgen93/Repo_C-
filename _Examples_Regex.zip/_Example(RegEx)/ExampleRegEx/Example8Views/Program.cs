﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Example8Views
{
    class Program
    {
        static void Main(string[] args)
        {
            string Message = "один два три два один два один";
            Console.WriteLine("Текст: " + Message);
            MatchCollection rez1 = Regex.Matches(Message, @"два(?=\s+три)");
            Console.WriteLine("Слово два справа от которого находится слово три");
            foreach (Match item in rez1)
            {  Console.WriteLine(item.Value +" "+item.Index);  }

            MatchCollection rez2 = Regex.Matches(Message, @"два(?!\s+три)");
            Console.WriteLine("Слово два справа от которого нет слова три");
            foreach (Match item in rez2)
            { Console.WriteLine(item.Value + " " + item.Index); }

            MatchCollection rez3 = Regex.Matches(Message, @"(?<=три\s+)два");
            Console.WriteLine("Слово два слева от которого находится слово три");
            foreach (Match item in rez3)
            { Console.WriteLine(item.Value + " " + item.Index); }

            MatchCollection rez4 = Regex.Matches(Message, @"(?<!три\s+)два");
            Console.WriteLine("Слово два слева от которого находится слово три");
            foreach (Match item in rez4)
            { Console.WriteLine(item.Value + " " + item.Index); }


            Console.ReadKey();
        }
    }
}
