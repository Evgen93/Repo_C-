﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class PC : IPropertyChanged
    {
        public event PropertyEventHandler PropertyChanged;
        
        protected virtual void OnPropertyChanged(string nameOfProp)
        {
            PropertyEventArgs propEvent = new PropertyEventArgs(nameOfProp);
            PropertyChanged?.Invoke(this, propEvent);
        }

        private string _name;

        public string Name
        {
            get { return _name; }
            set
            {
                _name = value;
                OnPropertyChanged();
            }
        }

        private int _ozy;

        public int Ozy
        {
            get { return _ozy; }
            set { _ozy = value; }
        }

        private int _numOfCore;

        public int NumOfCore
        {
            get { return _numOfCore; }
            set { _numOfCore = value; }
        }

    }
}
