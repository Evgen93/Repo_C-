﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoEvent
{
    class Program
    {
        static void Main(string[] args)
        {
            RemontServce service = new RemontServce();
            Server server = new Server(12);
            server.ServerCrash += service.Remont;
            server.Work();

            Console.Read();
        }
    }
}
