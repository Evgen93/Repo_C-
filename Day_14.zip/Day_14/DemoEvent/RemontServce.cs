﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoEvent
{
    public class RemontServce
    {
        public void Remont(object sender, EventArgs args)
        {
            Server server = sender as Server;
            if (server!=null)
            {
                Console.WriteLine(server.WorkTime);
            }
        }
    }
}
