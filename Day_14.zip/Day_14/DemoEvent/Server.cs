﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace DemoEvent
{
    public class Server
    {
        public event EventHandler ServerCrash;

        private int _workTime;

        public int WorkTime
        {   
            get { return _workTime; }
            set { _workTime = value; }
        }

        public Server(int workTime)
        {
            _workTime = workTime;
        }

        public void Work()
        {
            DateTime now = DateTime.Now;
            while (true)
            {
                Thread.Sleep(1000);
                TimeSpan timeWork = DateTime.Now - now;
                if (timeWork.TotalSeconds > _workTime)
                {
                    OnServerCrush();
                    break;
                }
                else
                {
                    Console.WriteLine("time: {0}", timeWork.TotalSeconds);
                }
            }
        }

        protected virtual void OnServerCrush()
        {
            ServerCrash?.Invoke(this, EventArgs.Empty);
        }
    }
}
