﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class EventStopCar : EventArgs
    {
        public int Way { get; set; }

        public string Message { get; set; }
        public EventStopCar(int newWay, string newMessage)
        {
            Way = newWay;
            Message = newMessage;
        }
    }
}
