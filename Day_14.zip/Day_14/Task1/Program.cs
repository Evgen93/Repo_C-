﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            STO sto = new STO();
            sto.log = (n, s) => Console.WriteLine("Поломка, причина: {0}, пройдено: {1}", n, s);
            car.Stop += sto.Remont;
            car.Move();

            Console.Read();
        }
    }
}
