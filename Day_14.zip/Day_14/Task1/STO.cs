﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task1
{
    public class STO
    {
        public delegate void logger(int n, string s);

        public logger log { get; set; }
        public void Remont(object sender, EventArgs args)
        { 
            Car car = sender as Car;
            EventStopCar obj = (EventStopCar)args;
            if (car != null)
            {
                log.Invoke(obj.way, obj.message);
            }
        }
    }
}
