﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Task1
{
    class Car
    {
        public event EventHandler Stop;

        private int _oil;

        public int Oil
        {
            get { return _oil; }
            set { _oil = value; }
        }

        private int _gas;

        public int Gas
        {
            get { return _gas; }
            set { _gas = value; }
        }

        private int _engineTemp;

        public int EngineTemp
        {
            get { return _engineTemp; }
            set { _engineTemp = value; }
        }


        private int _way;

        public int Way
        {
            get { return _way; }
        }

        public Car()
        {
            _oil = 5000;
            _gas = 50;
            _engineTemp = 0;
            _way = 0;
        }

        public void Move()
        {
            while (true)
            {
                Thread.Sleep(1000);
                Depreciation();
                if (_oil <= 500)
                {
                    OnStop("Низкий уровень масла.");
                    break;
                }
                else if (_gas <= 0)
                {
                    OnStop("Закончился бензин.");
                    break;
                }
                else if(_engineTemp >= 120)
                {
                    OnStop("Перегрев двигателя.");
                    break;
                }
                else
                {
                    Console.WriteLine("Сосотояние машины: Еду, проедено {0} км", _way);   
                }

            }
        }

        private void Depreciation()
        {
            Random rand = new Random();
            _way += 100;
            _engineTemp += rand.Next(1, 10);
            _gas -= rand.Next(1, 10);
            _oil -= rand.Next(100, 1000);
            
        }
        protected virtual void OnStop(string message)
        {
            EventStopCar stopCar = new EventStopCar(_way, message);
            Stop?.Invoke(this, stopCar);
        } 
    }
}
