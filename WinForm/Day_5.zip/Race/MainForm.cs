﻿using Race.entities;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace Race
{
    public partial class MainForm : Form
    {
        List<Button> _cars;
        List<Thread> _thread;
        public MainForm()
        {
            InitializeComponent();
            _cars = new List<Button> { btnCar1, btnCar2, btnCar3, btnCar4, btnCar5, btnCar6 };
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            _thread = new List<Thread>(Convert.ToInt32(numCars.Value));
            for (int i = 0; i < numCars.Value; i++)
            {
                _cars[i].Visible = true;
                _thread.Add(new Thread(CarMove));
                _thread[i].IsBackground = true;
                _thread[i].Start(_cars[i]);
            }
        }

        private void CarMove(object carNum)
        {
            for (;;)
            {
                Thread.Sleep(100);
                Action<Button> action = new Action<Button>(ThreadMove);
                Invoke(action, carNum);
            }
        }

        private void ThreadMove(object param)
        {
            Button btn = param as Button;
            if (btn != null)
            {

                btn.Left += (Randomer.GetNum() + tbSpeed.Value);
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (var item in _thread)
            {
                item.Abort();
            }
        }
    }
}
