﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Race.entities
{
    public static class Randomer
    {
        private static Random rand = new Random();

        public static int GetNum()
        {
            return rand.Next(0, 10);
        }
    }
}
