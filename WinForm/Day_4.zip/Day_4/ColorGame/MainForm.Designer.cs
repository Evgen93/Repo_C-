﻿namespace ColorGame
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnStart = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.pbRand = new System.Windows.Forms.PictureBox();
            this.pbUser = new System.Windows.Forms.PictureBox();
            this.gbResults = new System.Windows.Forms.GroupBox();
            this.lbDeltaRed = new System.Windows.Forms.Label();
            this.lbDeltaGreen = new System.Windows.Forms.Label();
            this.lbDeltaBlue = new System.Windows.Forms.Label();
            this.tbDeltaRed = new System.Windows.Forms.TextBox();
            this.tbDeltaGreen = new System.Windows.Forms.TextBox();
            this.tbDeltaBlue = new System.Windows.Forms.TextBox();
            this.lbAccRed = new System.Windows.Forms.Label();
            this.lbAccGreen = new System.Windows.Forms.Label();
            this.lbAccBlue = new System.Windows.Forms.Label();
            this.tbAccBlue = new System.Windows.Forms.TextBox();
            this.tbAccGreen = new System.Windows.Forms.TextBox();
            this.tbAccRed = new System.Windows.Forms.TextBox();
            this.tbAccuracy = new System.Windows.Forms.TextBox();
            this.lbAccuracy = new System.Windows.Forms.Label();
            this.trbRed = new System.Windows.Forms.TrackBar();
            this.trbGreen = new System.Windows.Forms.TrackBar();
            this.trbBlue = new System.Windows.Forms.TrackBar();
            this.lbСurrentColor = new System.Windows.Forms.Label();
            this.lbStartColor = new System.Windows.Forms.Label();
            this.tbСurrentRed = new System.Windows.Forms.TextBox();
            this.tbInitRed = new System.Windows.Forms.TextBox();
            this.tbInitGreen = new System.Windows.Forms.TextBox();
            this.lbСurrentGreen = new System.Windows.Forms.TextBox();
            this.tbInitBlue = new System.Windows.Forms.TextBox();
            this.lbCurrentBlue = new System.Windows.Forms.TextBox();
            this.progBarEnd = new System.Windows.Forms.ProgressBar();
            this.nupTime = new System.Windows.Forms.NumericUpDown();
            this.timer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pbRand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUser)).BeginInit();
            this.gbResults.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trbRed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbBlue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupTime)).BeginInit();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnStart.Location = new System.Drawing.Point(12, 23);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(157, 38);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "ПУСК";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnStop
            // 
            this.btnStop.Enabled = false;
            this.btnStop.Location = new System.Drawing.Point(203, 24);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(154, 38);
            this.btnStop.TabIndex = 1;
            this.btnStop.Text = "СТОП";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // pbRand
            // 
            this.pbRand.BackColor = System.Drawing.Color.White;
            this.pbRand.Location = new System.Drawing.Point(12, 101);
            this.pbRand.Name = "pbRand";
            this.pbRand.Size = new System.Drawing.Size(157, 204);
            this.pbRand.TabIndex = 3;
            this.pbRand.TabStop = false;
            // 
            // pbUser
            // 
            this.pbUser.BackColor = System.Drawing.Color.White;
            this.pbUser.Location = new System.Drawing.Point(203, 101);
            this.pbUser.Name = "pbUser";
            this.pbUser.Size = new System.Drawing.Size(154, 204);
            this.pbUser.TabIndex = 4;
            this.pbUser.TabStop = false;
            // 
            // gbResults
            // 
            this.gbResults.Controls.Add(this.lbAccuracy);
            this.gbResults.Controls.Add(this.tbAccuracy);
            this.gbResults.Controls.Add(this.tbAccRed);
            this.gbResults.Controls.Add(this.tbAccGreen);
            this.gbResults.Controls.Add(this.tbAccBlue);
            this.gbResults.Controls.Add(this.lbAccBlue);
            this.gbResults.Controls.Add(this.lbAccGreen);
            this.gbResults.Controls.Add(this.lbAccRed);
            this.gbResults.Controls.Add(this.tbDeltaBlue);
            this.gbResults.Controls.Add(this.tbDeltaGreen);
            this.gbResults.Controls.Add(this.tbDeltaRed);
            this.gbResults.Controls.Add(this.lbDeltaBlue);
            this.gbResults.Controls.Add(this.lbDeltaGreen);
            this.gbResults.Controls.Add(this.lbDeltaRed);
            this.gbResults.Location = new System.Drawing.Point(376, 101);
            this.gbResults.Name = "gbResults";
            this.gbResults.Size = new System.Drawing.Size(467, 204);
            this.gbResults.TabIndex = 5;
            this.gbResults.TabStop = false;
            this.gbResults.Text = "Results of game";
            // 
            // lbDeltaRed
            // 
            this.lbDeltaRed.AutoSize = true;
            this.lbDeltaRed.Location = new System.Drawing.Point(50, 29);
            this.lbDeltaRed.Name = "lbDeltaRed";
            this.lbDeltaRed.Size = new System.Drawing.Size(18, 13);
            this.lbDeltaRed.TabIndex = 0;
            this.lbDeltaRed.Text = "Dr";
            // 
            // lbDeltaGreen
            // 
            this.lbDeltaGreen.AutoSize = true;
            this.lbDeltaGreen.Location = new System.Drawing.Point(50, 75);
            this.lbDeltaGreen.Name = "lbDeltaGreen";
            this.lbDeltaGreen.Size = new System.Drawing.Size(21, 13);
            this.lbDeltaGreen.TabIndex = 1;
            this.lbDeltaGreen.Text = "Dg";
            // 
            // lbDeltaBlue
            // 
            this.lbDeltaBlue.AutoSize = true;
            this.lbDeltaBlue.Location = new System.Drawing.Point(50, 120);
            this.lbDeltaBlue.Name = "lbDeltaBlue";
            this.lbDeltaBlue.Size = new System.Drawing.Size(21, 13);
            this.lbDeltaBlue.TabIndex = 2;
            this.lbDeltaBlue.Text = "Db";
            // 
            // tbDeltaRed
            // 
            this.tbDeltaRed.Location = new System.Drawing.Point(92, 29);
            this.tbDeltaRed.Name = "tbDeltaRed";
            this.tbDeltaRed.ReadOnly = true;
            this.tbDeltaRed.Size = new System.Drawing.Size(100, 20);
            this.tbDeltaRed.TabIndex = 3;
            this.tbDeltaRed.Tag = "tbСurrentRed";
            // 
            // tbDeltaGreen
            // 
            this.tbDeltaGreen.Location = new System.Drawing.Point(92, 75);
            this.tbDeltaGreen.Name = "tbDeltaGreen";
            this.tbDeltaGreen.ReadOnly = true;
            this.tbDeltaGreen.Size = new System.Drawing.Size(100, 20);
            this.tbDeltaGreen.TabIndex = 4;
            this.tbDeltaGreen.Tag = "lbСurrentGreen";
            // 
            // tbDeltaBlue
            // 
            this.tbDeltaBlue.Location = new System.Drawing.Point(92, 120);
            this.tbDeltaBlue.Name = "tbDeltaBlue";
            this.tbDeltaBlue.ReadOnly = true;
            this.tbDeltaBlue.Size = new System.Drawing.Size(100, 20);
            this.tbDeltaBlue.TabIndex = 5;
            this.tbDeltaBlue.Tag = "lbCurrentBlue";
            // 
            // lbAccRed
            // 
            this.lbAccRed.AutoSize = true;
            this.lbAccRed.Location = new System.Drawing.Point(225, 29);
            this.lbAccRed.Name = "lbAccRed";
            this.lbAccRed.Size = new System.Drawing.Size(54, 13);
            this.lbAccRed.TabIndex = 6;
            this.lbAccRed.Text = "Точность";
            // 
            // lbAccGreen
            // 
            this.lbAccGreen.AutoSize = true;
            this.lbAccGreen.Location = new System.Drawing.Point(225, 75);
            this.lbAccGreen.Name = "lbAccGreen";
            this.lbAccGreen.Size = new System.Drawing.Size(54, 13);
            this.lbAccGreen.TabIndex = 7;
            this.lbAccGreen.Text = "Точность";
            // 
            // lbAccBlue
            // 
            this.lbAccBlue.AutoSize = true;
            this.lbAccBlue.Location = new System.Drawing.Point(225, 120);
            this.lbAccBlue.Name = "lbAccBlue";
            this.lbAccBlue.Size = new System.Drawing.Size(54, 13);
            this.lbAccBlue.TabIndex = 8;
            this.lbAccBlue.Text = "Точность";
            // 
            // tbAccBlue
            // 
            this.tbAccBlue.Location = new System.Drawing.Point(305, 117);
            this.tbAccBlue.Name = "tbAccBlue";
            this.tbAccBlue.ReadOnly = true;
            this.tbAccBlue.Size = new System.Drawing.Size(100, 20);
            this.tbAccBlue.TabIndex = 9;
            // 
            // tbAccGreen
            // 
            this.tbAccGreen.Location = new System.Drawing.Point(305, 72);
            this.tbAccGreen.Name = "tbAccGreen";
            this.tbAccGreen.ReadOnly = true;
            this.tbAccGreen.Size = new System.Drawing.Size(100, 20);
            this.tbAccGreen.TabIndex = 10;
            // 
            // tbAccRed
            // 
            this.tbAccRed.Location = new System.Drawing.Point(305, 26);
            this.tbAccRed.Name = "tbAccRed";
            this.tbAccRed.ReadOnly = true;
            this.tbAccRed.Size = new System.Drawing.Size(100, 20);
            this.tbAccRed.TabIndex = 11;
            // 
            // tbAccuracy
            // 
            this.tbAccuracy.Location = new System.Drawing.Point(218, 165);
            this.tbAccuracy.Name = "tbAccuracy";
            this.tbAccuracy.ReadOnly = true;
            this.tbAccuracy.Size = new System.Drawing.Size(100, 20);
            this.tbAccuracy.TabIndex = 12;
            // 
            // lbAccuracy
            // 
            this.lbAccuracy.AutoSize = true;
            this.lbAccuracy.Location = new System.Drawing.Point(158, 168);
            this.lbAccuracy.Name = "lbAccuracy";
            this.lbAccuracy.Size = new System.Drawing.Size(54, 13);
            this.lbAccuracy.TabIndex = 13;
            this.lbAccuracy.Text = "Точность";
            // 
            // trbRed
            // 
            this.trbRed.Location = new System.Drawing.Point(13, 391);
            this.trbRed.Maximum = 255;
            this.trbRed.Name = "trbRed";
            this.trbRed.Size = new System.Drawing.Size(673, 45);
            this.trbRed.TabIndex = 6;
            this.trbRed.Tag = "tbСurrentRed";
            this.trbRed.Value = 255;
            this.trbRed.ValueChanged += new System.EventHandler(this.trbRed_ValueChanged);
            // 
            // trbGreen
            // 
            this.trbGreen.Location = new System.Drawing.Point(13, 447);
            this.trbGreen.Maximum = 255;
            this.trbGreen.Name = "trbGreen";
            this.trbGreen.Size = new System.Drawing.Size(673, 45);
            this.trbGreen.TabIndex = 7;
            this.trbGreen.Tag = "lbСurrentGreen";
            this.trbGreen.Value = 255;
            this.trbGreen.ValueChanged += new System.EventHandler(this.trbRed_ValueChanged);
            // 
            // trbBlue
            // 
            this.trbBlue.Location = new System.Drawing.Point(13, 498);
            this.trbBlue.Maximum = 255;
            this.trbBlue.Name = "trbBlue";
            this.trbBlue.Size = new System.Drawing.Size(673, 45);
            this.trbBlue.TabIndex = 8;
            this.trbBlue.Tag = "lbCurrentBlue";
            this.trbBlue.Value = 255;
            this.trbBlue.ValueChanged += new System.EventHandler(this.trbRed_ValueChanged);
            // 
            // lbСurrentColor
            // 
            this.lbСurrentColor.AutoSize = true;
            this.lbСurrentColor.Location = new System.Drawing.Point(700, 365);
            this.lbСurrentColor.Name = "lbСurrentColor";
            this.lbСurrentColor.Size = new System.Drawing.Size(52, 13);
            this.lbСurrentColor.TabIndex = 14;
            this.lbСurrentColor.Text = "Текущее";
            // 
            // lbStartColor
            // 
            this.lbStartColor.AutoSize = true;
            this.lbStartColor.Location = new System.Drawing.Point(789, 365);
            this.lbStartColor.Name = "lbStartColor";
            this.lbStartColor.Size = new System.Drawing.Size(56, 13);
            this.lbStartColor.TabIndex = 15;
            this.lbStartColor.Text = "Исходное";
            // 
            // tbСurrentRed
            // 
            this.tbСurrentRed.Location = new System.Drawing.Point(703, 391);
            this.tbСurrentRed.Name = "tbСurrentRed";
            this.tbСurrentRed.ReadOnly = true;
            this.tbСurrentRed.Size = new System.Drawing.Size(51, 20);
            this.tbСurrentRed.TabIndex = 14;
            this.tbСurrentRed.Tag = "tbInitRed";
            // 
            // tbInitRed
            // 
            this.tbInitRed.Location = new System.Drawing.Point(792, 391);
            this.tbInitRed.Name = "tbInitRed";
            this.tbInitRed.ReadOnly = true;
            this.tbInitRed.Size = new System.Drawing.Size(51, 20);
            this.tbInitRed.TabIndex = 16;
            // 
            // tbInitGreen
            // 
            this.tbInitGreen.Location = new System.Drawing.Point(792, 447);
            this.tbInitGreen.Name = "tbInitGreen";
            this.tbInitGreen.ReadOnly = true;
            this.tbInitGreen.Size = new System.Drawing.Size(51, 20);
            this.tbInitGreen.TabIndex = 18;
            // 
            // lbСurrentGreen
            // 
            this.lbСurrentGreen.Location = new System.Drawing.Point(703, 447);
            this.lbСurrentGreen.Name = "lbСurrentGreen";
            this.lbСurrentGreen.ReadOnly = true;
            this.lbСurrentGreen.Size = new System.Drawing.Size(51, 20);
            this.lbСurrentGreen.TabIndex = 17;
            this.lbСurrentGreen.Tag = "tbInitGreen";
            // 
            // tbInitBlue
            // 
            this.tbInitBlue.Location = new System.Drawing.Point(792, 499);
            this.tbInitBlue.Name = "tbInitBlue";
            this.tbInitBlue.ReadOnly = true;
            this.tbInitBlue.Size = new System.Drawing.Size(51, 20);
            this.tbInitBlue.TabIndex = 20;
            // 
            // lbCurrentBlue
            // 
            this.lbCurrentBlue.Location = new System.Drawing.Point(703, 499);
            this.lbCurrentBlue.Name = "lbCurrentBlue";
            this.lbCurrentBlue.ReadOnly = true;
            this.lbCurrentBlue.Size = new System.Drawing.Size(51, 20);
            this.lbCurrentBlue.TabIndex = 19;
            this.lbCurrentBlue.Tag = "tbInitBlue";
            // 
            // progBarEnd
            // 
            this.progBarEnd.Location = new System.Drawing.Point(12, 580);
            this.progBarEnd.Name = "progBarEnd";
            this.progBarEnd.Size = new System.Drawing.Size(848, 23);
            this.progBarEnd.TabIndex = 21;
            // 
            // nupTime
            // 
            this.nupTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.nupTime.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nupTime.Location = new System.Drawing.Point(393, 26);
            this.nupTime.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.nupTime.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.nupTime.Name = "nupTime";
            this.nupTime.ReadOnly = true;
            this.nupTime.Size = new System.Drawing.Size(120, 31);
            this.nupTime.TabIndex = 22;
            this.nupTime.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(872, 615);
            this.Controls.Add(this.nupTime);
            this.Controls.Add(this.progBarEnd);
            this.Controls.Add(this.tbInitBlue);
            this.Controls.Add(this.lbCurrentBlue);
            this.Controls.Add(this.tbInitGreen);
            this.Controls.Add(this.lbСurrentGreen);
            this.Controls.Add(this.tbInitRed);
            this.Controls.Add(this.tbСurrentRed);
            this.Controls.Add(this.lbStartColor);
            this.Controls.Add(this.lbСurrentColor);
            this.Controls.Add(this.trbBlue);
            this.Controls.Add(this.trbGreen);
            this.Controls.Add(this.trbRed);
            this.Controls.Add(this.gbResults);
            this.Controls.Add(this.pbUser);
            this.Controls.Add(this.pbRand);
            this.Controls.Add(this.btnStop);
            this.Controls.Add(this.btnStart);
            this.Name = "MainForm";
            this.Text = "Color game";
            ((System.ComponentModel.ISupportInitialize)(this.pbRand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUser)).EndInit();
            this.gbResults.ResumeLayout(false);
            this.gbResults.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trbRed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trbBlue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nupTime)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.PictureBox pbRand;
        private System.Windows.Forms.PictureBox pbUser;
        private System.Windows.Forms.GroupBox gbResults;
        private System.Windows.Forms.Label lbAccuracy;
        private System.Windows.Forms.TextBox tbAccuracy;
        private System.Windows.Forms.TextBox tbAccRed;
        private System.Windows.Forms.TextBox tbAccGreen;
        private System.Windows.Forms.TextBox tbAccBlue;
        private System.Windows.Forms.Label lbAccBlue;
        private System.Windows.Forms.Label lbAccGreen;
        private System.Windows.Forms.Label lbAccRed;
        private System.Windows.Forms.TextBox tbDeltaBlue;
        private System.Windows.Forms.TextBox tbDeltaGreen;
        private System.Windows.Forms.TextBox tbDeltaRed;
        private System.Windows.Forms.Label lbDeltaBlue;
        private System.Windows.Forms.Label lbDeltaGreen;
        private System.Windows.Forms.Label lbDeltaRed;
        private System.Windows.Forms.TrackBar trbRed;
        private System.Windows.Forms.TrackBar trbGreen;
        private System.Windows.Forms.TrackBar trbBlue;
        private System.Windows.Forms.Label lbСurrentColor;
        private System.Windows.Forms.Label lbStartColor;
        private System.Windows.Forms.TextBox tbСurrentRed;
        private System.Windows.Forms.TextBox tbInitRed;
        private System.Windows.Forms.TextBox tbInitGreen;
        private System.Windows.Forms.TextBox lbСurrentGreen;
        private System.Windows.Forms.TextBox tbInitBlue;
        private System.Windows.Forms.TextBox lbCurrentBlue;
        private System.Windows.Forms.ProgressBar progBarEnd;
        private System.Windows.Forms.NumericUpDown nupTime;
        private System.Windows.Forms.Timer timer;
    }
}

