﻿using ColorGame.entities;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ColorGame
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnStop.Enabled = true;
            pbRand.BackColor = RandomerRgb.GetRandRgb();
            progBarEnd.Maximum = (int)nupTime.Value;
            timer.Start();
            btnStart.Enabled = false;
            Reset();
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (progBarEnd.Value == progBarEnd.Maximum)
            {
                StopGame();
            }
            else
            {
                progBarEnd.Value++;
            }
        }

        private void trbRed_ValueChanged(object sender, EventArgs e)
        {
            pbUser.BackColor = Color.FromArgb(trbRed.Value, trbGreen.Value, trbBlue.Value);
            TrackBar trackBar = (TrackBar)sender;
            var control = this.Controls.Find(trackBar.Tag.ToString(), true).First() as TextBox;
            control.Text = trackBar.Value.ToString();
        }

        private void StopGame()
        {
            btnStop.Enabled = false;
            btnStart.Enabled = true;
            timer.Stop();
            progBarEnd.Value = 0;
            GetColorComponent();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            StopGame();
        }

        private void GetColorComponent()
        {
            tbInitRed.Text = pbRand.BackColor.R.ToString();
            tbInitGreen.Text = pbRand.BackColor.G.ToString();
            tbInitBlue.Text = pbRand.BackColor.B.ToString();
        }

        private void Reset()
        {
            foreach (var item in this.Controls)
            {
                TextBox text = item as TextBox;
                if (text != null)
                {
                    text.Text = string.Empty;
                }

                TrackBar tbar = item as TrackBar;
                if (tbar != null)
                {
                    tbar.Value = 255;
                }
            }

        }

        private void CalculaceRecult()
        {
            foreach (var item in gbResults.Controls)
            {
                TextBox
            }
        }
    }
}
