﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ColorGame.entities
{
    public static class RandomerRgb
    {
        private static Random rand = new Random();
        public static Color GetRandRgb()
        {
            return Color.FromArgb(rand.Next(0, 255), rand.Next(0, 255), rand.Next(0, 255));
        }
    }
}
