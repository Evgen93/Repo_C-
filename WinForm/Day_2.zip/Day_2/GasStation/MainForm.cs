﻿using GasStation.Model.Entites;
using GasStation.Model.Repositories;
using System;
using System.Linq;
using System.Windows.Forms;

namespace GasStation
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, System.EventArgs e)
        {
            IRepository repo = new FuelRopository();
            cbGas.DisplayMember = "Name";
            cbGas.DataSource = repo.Get();
        }

        private void cbGas_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            FuelInfo select = cbGas.SelectedItem as FuelInfo;
            if (select != null)
            {
                tbGasPriceliter.Text = select.Price.ToString("N2");
            }
        }

        private void rbCol_CheckedChanged(object sender, System.EventArgs e)
        {
            tbGasNum.ReadOnly = !rbCol.Checked;
            tbGasPrice.ReadOnly = rbCol.Checked;
        }

        private void cbHotDog_CheckedChanged(object sender, System.EventArgs e)
        {
            CheckBox check = (CheckBox)sender;
            var control = this.Controls.Find(check.Tag.ToString(), true).First() as TextBox;
            control.ReadOnly = !check.Checked;
        }
    }
}
