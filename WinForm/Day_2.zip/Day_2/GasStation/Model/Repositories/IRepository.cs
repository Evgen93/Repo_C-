﻿using GasStation.Model.Entites;
using System.Collections.Generic;

namespace GasStation.Model.Repositories
{
    public interface IRepository
    {
        IEnumerable<FuelInfo> Get();
    }
}