﻿using System;
using System.Windows.Forms;

namespace DemoWinForms
{
    class Program
    {
        static void Main(string[] args)
        {
            LoginForm form = new LoginForm();
            form.Text = "Demo Win Forms";
            form.StartPosition = FormStartPosition.CenterScreen;
            Application.Run(form);
        }
    }
}
