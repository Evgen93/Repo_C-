﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoWinForms
{
   partial class LoginForm
    {
        private void InitializeComponent()
        {
            Label lbLogin = new Label();
            lbLogin.Text = "Login";
            lbLogin.ForeColor = Color.Green;
            lbLogin.Location = new Point(30, 10);
            lbLogin.Font = new Font("Arial", 14);
            this.Controls.Add(lbLogin);

            _tbLogin = new TextBox()
            {
                Location = new Point(30, 40),
                Font = new Font("Arial", 14),
                Text = "Enter Login",
                Size = new Size(150, 30)
            };
            this.Controls.Add(_tbLogin);

            Button btnLogIn = new Button()
            {
                Text = "Log IN",
                ForeColor = Color.Red,
                Location = new Point(30, 80),
                Font = new Font("Arial", 14),
                Size = new Size(150, 30),
                Name = nameof(btnLogIn)
            };
            btnLogIn.Click += BtnLogIn_Click;
            this.Controls.Add(btnLogIn);

            Button btnLogOut = new Button()
            {
                Text = "Log Out",
                ForeColor = Color.Blue,
                Location = new Point(30, 120),
                Font = new Font("Arial", 14),
                Size = new Size(150, 30),
                Name = nameof(btnLogOut)
            };

            EventHandler action = (os, ea) => this.Text += "Super Puper";

            btnLogOut.Click += action;
            btnLogIn.Click += action;

            this.Controls.Add(btnLogOut);
        }

    }
}
