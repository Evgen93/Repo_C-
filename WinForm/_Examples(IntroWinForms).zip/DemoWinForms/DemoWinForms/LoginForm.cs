﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace DemoWinForms
{
   partial  class LoginForm : Form
    {
        private TextBox _tbLogin;

        public LoginForm()
        {
            InitializeComponent();
        }

       
        private void BtnLogIn_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Name.Equals("btnLogIn"))
            {
                this.Text = _tbLogin.Text;
            }
            else 
            {
                this.Text = "Log Out";
            }
           
        }
    }
}
