﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoWinFormApp
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        
        private void btnLogIn_Click(object sender, EventArgs e)
        {
            this.Text = tbLogin.Text;
        }

        private void btnMessageBox_Click(object sender, EventArgs e)
        {
           DialogResult result =  MessageBox.Show(
                "Вы знаете C#?", 
                "Вопрос",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2);

            if (result==DialogResult.Yes)
            {
                MessageBox.Show("Не верю","",  MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
