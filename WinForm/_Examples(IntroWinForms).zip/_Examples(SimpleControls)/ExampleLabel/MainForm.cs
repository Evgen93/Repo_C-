﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExampleLabel
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        // ДЕМОНСТРАЦИЯ СВОЙСТВ LABEL
        private void MainForm_Load(object sender, EventArgs e)
        {
            Label label1 = new Label();
            label1.Text = "Демонстрация свойств Lаbel      ";
            label1.Location = new Point(50, 30);
            label1.Font = new Font(new FontFamily("Arial"), 14, FontStyle.Bold);
            label1.BackColor = Color.Cornsilk;
            label1.ForeColor = Color.Blue;
            label1.AutoSize = true;                             // автоматическое изменение размеров
            label1.BorderStyle = BorderStyle.FixedSingle;       // стиль границ
            //Fixed3D, FixedSingle, None

            label1.FlatStyle = FlatStyle.Standard;             // стиль элемента
            //Standard,  Flat, Popup, None
            label1.Padding = new Padding(5, 5, 5, 5);          // внутренние отступы
            label1.Margin = new Padding(5, 5, 5, 5);           // внешние отступы
            label1.Enabled = true;                             // Доступность пользователю
            label1.Visible = true;                             // Видимость объекта

            label1.Image = new Bitmap("basicwar.png");
            label1.ImageAlign = ContentAlignment.MiddleRight;
            label1.TextAlign = ContentAlignment.MiddleLeft;

            this.Controls.Add(label1);

            
        }

        // события наведения мыши
        private void label4_MouseHover(object sender, EventArgs e)
        {
            label4.ForeColor = Color.Red;
        }
        // события наведения мыши
        private void label4_MouseLeave(object sender, EventArgs e)
        {
            label4.ForeColor = Color.Blue;
        }
        //двойной клик по label4
        private void label4_DoubleClick(object sender, EventArgs e)
        {

        }
    }
}
