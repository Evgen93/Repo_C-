﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExampleForm
{

    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            // Установка свойств в коде
            // (можно настраивать свойства формы через окно "Свойства" (Properties))


            //public virtual string Text { get; set; } -  возвращает или задает заголовок окна
            this.Text = @"Демонстрация свойств, событий и методов формы";
            //---------------------------------------------------------------------------------------------------------------------------------

            // public Size Size { get; set; }  -  возвращает или задает размер формы
            this.Size = new Size(550, 400); // Ширина и высота
            //---------------------------------------------------------------------------------------------------------------------------------

            // public FormStartPosition StartPosition { get; set; } -  возвращает или задает начальное положение формы в режиме выполнения
            this.StartPosition = FormStartPosition.Manual;
            // Manual  - Положение формы определяется свойством Location класса Form. 
            // CenterScreen  - Форма с заданными размерами располагается в центре текущего отображения. 
            // WindowsDefaultLocation - Форма с заданными размерами размещается в расположении, определенном по умолчанию в Windows. 
            // WindowsDefaultBounds - Положение формы и ее границы определены в Windows по умолчанию. 
            // CenterParent - Форма располагается в центре родительской формы.
            //---------------------------------------------------------------------------------------------------------------------------------

            // public Point Location { get; set; }  - возвращает  или  задает  объект  Point,  который 
            //                                        представляет собой верхний левый угол формы в экранных координатах
            this.Location = new Point(150, 150);  // координата X и Y
            // Point – структура, находящаяся в пространстве System.Drawing, 
            // представляет упорядоченную пару целых чисел — координат Х и Y, определяющую точку на двумерной плоскости. 
            //---------------------------------------------------------------------------------------------------------------------------------

            // public virtual Color BackColor { get; set; }  -  возвращает или задает цвет фона для формы
            this.BackColor = Color.LightSkyBlue;
            // Color – структура из пространства System.Drawing, используется
            // для представления цвета в терминах каналов альфа, красного, зеленого и синего (ARGB). 
            //---------------------------------------------------------------------------------------------------------------------------------

            // public virtual Color ForeColor { get; set; }  -  возвращает или задает цвет надписей на форме
            this.ForeColor = Color.Green;
            //---------------------------------------------------------------------------------------------------------------------------------


            //    this.BackgroundImage = new Bitmap("fone.jpeg");

            this.ControlBox = true; // отображение кнопок (закрыть, свернуть/размернуть) на форме

            this.Cursor = Cursors.Cross; // установка курсора для формы

            this.Font = new Font("Arial", 11);

            this.FormBorderStyle = FormBorderStyle.FixedSingle; // стиль границы окна
            // None	- Без рамки.  
            // Fixed3D -	Фиксированная трехмерная граница.
            // FixedDialog -	Толстая фиксированная граница в диалоговом окно-стиля.
            // FixedSingle -	Фиксированная, одностроковая граница.
            // Sizable	- Граница с изменяемыми размерами.
            // SizableToolWindow	- Граница окна инструментов. 
            // FixedToolWindow -	Граница окна инструментов, которое нельзя изменить. 

            this.WindowState = FormWindowState.Normal;
            // Normal   - нормальное состояние
            // Maximized - свернуто
            // Minimized- развернуто
        }


        // Click по форме
        private void Form1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Form1_Click");
        }

        // Закрытие формы
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            MessageBox.Show("Form1_FormClosed");
        }

        // Нажатие любой клавиши на форме
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("Form1_KeyDown - " + e.KeyCode);
        }

        // Кнопка на форме "Закрыть"
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close(); // метод закрыти окна!
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.CenterToScreen(); // метод для перемещения окна в центр!
        }
    }

}
