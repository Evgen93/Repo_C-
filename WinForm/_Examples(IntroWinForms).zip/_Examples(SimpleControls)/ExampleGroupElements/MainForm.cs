﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication9
{
	public partial class MainForm : Form
	{
		private readonly TextBox[] _textBoxes;

		public MainForm()
		{
			InitializeComponent();
			_textBoxes = new TextBox[] { textBox10, textBox11, textBox12, textBox13, textBox14 };
		}
		
		private void checkBox1_Click(object sender, EventArgs e)
		{
			double Summa = 0;
			if (checkBox1.Checked)
				Summa += Convert.ToDouble(textBox4.Text);
			if (checkBox2.Checked)
				Summa += Convert.ToDouble(textBox5.Text);
			if (checkBox3.Checked)
				Summa += Convert.ToDouble(textBox6.Text);
			if (checkBox4.Checked)
				Summa += Convert.ToDouble(textBox7.Text);
			if (checkBox5.Checked)
				Summa += Convert.ToDouble(textBox8.Text);
			textBox9.Text = Summa.ToString();
		}

		private void checkBox6_Click(object sender, EventArgs e)
		{
			double Summa = 0;

			foreach (TextBox tb in _textBoxes)
			{
				CheckBox cb = (CheckBox)this.Controls["checkBox" + tb.Tag.ToString()];
				if (cb.Checked)
				{
					Summa += Convert.ToDouble(tb.Text);
				}
			}
			textBox15.Text = Summa.ToString();
		}
		
		private void btnRun_Click(object sender, EventArgs e)
		{
			IEnumerable<TextBox> tbs = this.Controls.OfType<TextBox>();
			foreach (var item in tbs)
			{
				item.ReadOnly = false;
			}
		}

		private void button1_Click(object sender, EventArgs e)
		{
			IEnumerable<TextBox> tbs = groupBox1.Controls.OfType<TextBox>();
			foreach (var item in tbs)
			{
				item.ReadOnly = false;
			}
		}

	}
}
