﻿namespace ExampleComboBox
{
	public class SubjectInfo
	{
		public int Num { get; set; }

		public string Name { get; set; }
	}
}