﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExampleComboBox
{
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
			var subjects = new List<SubjectInfo>()
						{
						 new SubjectInfo(){Num=1, Name="C#"},
							new SubjectInfo(){Num=2, Name="WinForms"},
							 new SubjectInfo(){Num=3, Name="WPF"},
								new SubjectInfo(){Num=4, Name="ADO.NET"},
								 new SubjectInfo(){Num=5, Name="ASP.NET"},
						};

			comboBox6.DataSource = subjects;
			comboBox6.DisplayMember = "Name";


		}

		private void btnFind_Click(object sender, EventArgs e)
		{
			var rezIndex = comboBox6.FindStringExact(textBox1.Text);
			label6.Text = @"Индекс: " + rezIndex;

		}
	}
}
