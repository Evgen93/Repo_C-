﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExampleButton
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        // Демонстрация свойств Button
        private void MainForm_Load(object sender, EventArgs e)
        {
           Button btnNew=new Button();
           btnNew.Text = "Текст кнопки";
           btnNew.Location = new Point(50,30);
           btnNew.BackColor = System.Drawing.Color.Plum;
           btnNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, FontStyle.Bold);
           btnNew.Size = new System.Drawing.Size(145, 46);
           btnNew.TextAlign = ContentAlignment.MiddleCenter;
          
           this.Controls.Add(btnNew);
        }

     
    }
}
