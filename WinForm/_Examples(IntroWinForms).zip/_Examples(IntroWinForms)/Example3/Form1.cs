﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example3
{
    public partial class Form1 : Form       // partial - частичный тип!!!
    {
        public Form1()  // конструктор формы
        {
            InitializeComponent();  // метод в котором инициализируются все элементы управления
                                    // реализация метода в Forml.Designer.cs. 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button.ForeColor = Color.Green;       // изменение цвета подписи кнопки       
            textBox.Text = "Произошло событие";   // изменение текста в редактируемом поле
            this.Height *= 2;                     // изменение высоты главной формы
        }
    }
}
