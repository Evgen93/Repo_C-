﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example5Timer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // Для таймера необходимо:
            // 1. Установить интервал срабатывания таймера (свойство Interval)
            // 2. Добавить обработчик на событие Tick, которое вызывается 
            // через время заданное свойством Interval
            // 3. Запустить таймер методом Start() r или свойством Enabled=true
            // 4. Остановить таймер методом Stop() r или свойством Enabled=false

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Width += 1;
            this.Height += 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            //timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            //timer1.Enabled = false;
        }

    }
}
