﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example6DateTime
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // запись в строку заголовка формы текущих дат и времени в указанном формате
            this.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // В перегруженный оператор + передаётся два аргумента: 
           // объект, содержащий время и дату, и  объект, содержащий временной промежуток,
            // результат сложения - объект DateTime
            DateTime d1 = new DateTime(2015,12,30, 10,15,20);
            TimeSpan t1 = new TimeSpan(2,5,30,30);
            DateTime d3 = d1 + t1;
            label1.Text = d3.ToString();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
           // В перегруженный оператор - передаётся два аргумента: 
           // объект, содержащий время и дату,  второй объект, содержащий время и дату.
           // Из оператора возвращается объект TimeSpan, содержащий 
           // временной промежуток - результат вычитания двух дат.
            DateTime d2 = new DateTime(2015, 12, 30, 10, 15, 20);
            DateTime d1 = new DateTime(2016, 01, 01, 00, 00, 00);
            TimeSpan t1 = d1 - d2;
            label1.Text = t1.ToString();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            label1.Text = monthCalendar1.SelectionStart.ToShortDateString();
        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            label1.Text = dateTimePicker2.Value.ToLongDateString();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            label1.Text = dateTimePicker1.Value.ToLongDateString();
        }
    }
}
