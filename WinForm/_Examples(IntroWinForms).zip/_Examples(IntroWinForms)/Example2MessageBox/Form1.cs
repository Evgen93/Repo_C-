﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example2MessageBox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        // Отображение сообщения по нажатию на кнопку
        private void btnShow_Click(object sender, EventArgs e)
        {
            // Вызов сообщения MessageBox с сохранением результата в DialogResult
            DialogResult result = MessageBox.Show("Произошла ошибка при доступе к диску!","Ошибка", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Error); 
            
            // Проверка того, что выбрал пользователь!
            if (result == DialogResult.Abort)
            {
                MessageBox.Show("Вы нажали кнопку Прервать");
            }
            else
            {
                if (result == DialogResult.Retry)
                {
                    MessageBox.Show("Вы нажали кнопку Повтор");
                }
                else
                {
                    if (result == DialogResult.Ignore)
                    {
                        MessageBox.Show("Вы нажали кнопку Пропустить");
                    }
                }
            }
        }

        //   Отображение сообщения при закрытии окна!
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Вы уверены, что хотите выйти?", "Внимание!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                e.Cancel = false;
            else 
                e.Cancel = true;
        }

              

    }
}
