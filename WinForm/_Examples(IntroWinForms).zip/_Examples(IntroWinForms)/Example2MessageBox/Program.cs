﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example2MessageBox
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Отображение сообщения, если пользователь нажимает Cancel программа закрывается!
            if(DialogResult.OK == MessageBox.Show("Демонстрация работы Message Box!", "Внимание", MessageBoxButtons.OKCancel))
            Application.Run(new Form1());
        }
    }
}
