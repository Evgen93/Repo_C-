﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace ctlClockLib
{
	public partial class ClockControl : UserControl
	{
		private Color colFColor;
		private Color colBColor;


		[Category("Цвета"), Description("Цвет фона")]
		public Color ClockBackColor
		{
			get
			{
				return colBColor;
			}
			set
			{
				colBColor = value;
				lblDisplay.BackColor = colBColor;
			}
		}


		[Category("Цвета"), Description("Цвет текста")]
		public Color ClockForeColor
		{
			get
			{
				return colFColor;
			}
			set
			{
				colFColor = value;
				lblDisplay.ForeColor = colFColor;
			}
		}


		public ClockControl()
		{
			InitializeComponent();
		}

		protected virtual void timer_Tick(object sender, EventArgs e)
		{
			lblDisplay.Text = DateTime.Now.ToLongTimeString();
		}
	}

	

}
