﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ctlClockLib;

namespace ctlAlarmLib
{

	// Построение на основе составного элемента управления  других элементов управления

	public partial class AlarmClockControl : ClockControl
	{
		// AlarmTime, хранящее значение даты и времени срабатывания будильника
		private DateTime _alarmTime;

		[Category("Будильник"), Description("Время срабатывания будильника")]
		public DateTime AlarmTime
		{
			get { return _alarmTime; }
			set { _alarmTime = value; }
		}

		// AlarmSet, показывающее, установлен ли будильник.
		private bool _isAlarmSet;
		[Category("Будильник"), Description("Признак установки будильника")]
		public bool AlarmSet
		{
			get { return _isAlarmSet; }
			set { _isAlarmSet = value; }
		}


		// поле для создания мерцания (красный/синий)цвет
		private bool _isColorTicker;


		public AlarmClockControl()
		{
			InitializeComponent();
		}

		// переопределение метода timer1_Tick класса ClockControl
		protected override void timer_Tick(object sender, System.EventArgs e)
		{

			// вызов метода timer_Tick, определенного  в базовом классе
			base.timer_Tick(sender, e);

			if (AlarmSet) // если будильник не установлен, то выход
			{
				// проверка на совпадение времени текущего и установленного в будильнике
				if (AlarmTime.Date == DateTime.Now.Date &&
						AlarmTime.Hour == DateTime.Now.Hour &&
						AlarmTime.Minute == DateTime.Now.Minute)
				{

					lblAlarm.Visible = true;  // отображение надписи "ПОДЪЕМ!"

					if (!_isColorTicker)
					{
						lblAlarm.BackColor = Color.Red;
						_isColorTicker = true;
					}
					else
					{
						lblAlarm.BackColor = Color.Blue;
						_isColorTicker = false;
					}
				}
				else
				{
					lblAlarm.Visible = false;
				}
			}
		}

		//
		private void btnAlarmOff_Click(object sender, EventArgs e)
		{
			if (AlarmSet)
			{
				AlarmSet = false;
				btnAlarmOff.Text = "Включить будильник";
				lblAlarm.Visible = false;
			}
			else
			{
				AlarmSet = true;
				btnAlarmOff.Text = "Выключить будильник";
			}
		}
	}
}
