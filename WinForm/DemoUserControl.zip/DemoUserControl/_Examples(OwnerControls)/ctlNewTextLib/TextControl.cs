﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ctlNewTextLib
{
    public partial class TextControl : Control
    {
        private ContentAlignment alignmentValue = ContentAlignment.MiddleLeft;

        public TextControl()
        {
            InitializeComponent();
        }

        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);
            StringFormat style = new StringFormat();
            style.Alignment = StringAlignment.Near;
            switch (alignmentValue)
            {
                case ContentAlignment.MiddleLeft:
                    style.Alignment = StringAlignment.Near;
                    break;
                case ContentAlignment.MiddleRight:
                    style.Alignment = StringAlignment.Far;
                    break;
                case ContentAlignment.MiddleCenter:
                    style.Alignment = StringAlignment.Center;
                    break;
            }

            pe.Graphics.DrawString(Text, Font,
                                  new SolidBrush(ForeColor),
                                  ClientRectangle, style); 
        }

        [Category("Alignment"),Description("Определяет выравнивание текста)))")]
        public ContentAlignment TextAlignment
        {
            get
            {
                return alignmentValue;
            }
            set
            {
                alignmentValue = value;
                Invalidate();
            }
        }
    }
}
