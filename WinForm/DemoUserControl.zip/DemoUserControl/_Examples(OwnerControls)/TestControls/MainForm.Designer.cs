﻿namespace TestControls
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.lblTest = new System.Windows.Forms.Label();
            this.cuteButton1 = new ctlCuteButton.CuteButton();
            this.textControl1 = new ctlNewTextLib.TextControl();
            this._alarmClock1 = new ctlAlarmLib.AlarmClockControl();
            this._clock1 = new ctlClockLib.ClockControl();
            this.SuspendLayout();
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.dateTimePicker1.Location = new System.Drawing.Point(305, 188);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 29);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // lblTest
            // 
            this.lblTest.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTest.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTest.Location = new System.Drawing.Point(305, 228);
            this.lblTest.Name = "lblTest";
            this.lblTest.Size = new System.Drawing.Size(200, 23);
            this.lblTest.TabIndex = 3;
            // 
            // cuteButton1
            // 
            this.cuteButton1.cuteColor1 = System.Drawing.Color.LightGreen;
            this.cuteButton1.cuteColor2 = System.Drawing.Color.DarkBlue;
            this.cuteButton1.cuteTransparent1 = 64;
            this.cuteButton1.cuteTransparent2 = 64;
            this.cuteButton1.Location = new System.Drawing.Point(14, 149);
            this.cuteButton1.Name = "cuteButton1";
            this.cuteButton1.Size = new System.Drawing.Size(148, 102);
            this.cuteButton1.TabIndex = 5;
            this.cuteButton1.Text = "cuteButton1";
            this.cuteButton1.Click += new System.EventHandler(this.cuteButton1_Click);
            // 
            // textControl1
            // 
            this.textControl1.Location = new System.Drawing.Point(21, 314);
            this.textControl1.Name = "textControl1";
            this.textControl1.Size = new System.Drawing.Size(177, 23);
            this.textControl1.TabIndex = 4;
            this.textControl1.Text = "textControl1";
            this.textControl1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _alarmClock1
            // 
            this._alarmClock1.AlarmSet = false;
            this._alarmClock1.AlarmTime = new System.DateTime(((long)(0)));
            this._alarmClock1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._alarmClock1.ClockBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this._alarmClock1.ClockForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this._alarmClock1.Location = new System.Drawing.Point(353, 12);
            this._alarmClock1.Name = "_alarmClock1";
            this._alarmClock1.Size = new System.Drawing.Size(152, 160);
            this._alarmClock1.TabIndex = 1;
            // 
            // _clock1
            // 
            this._clock1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this._clock1.ClockBackColor = System.Drawing.Color.PowderBlue;
            this._clock1.ClockForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this._clock1.Location = new System.Drawing.Point(12, 12);
            this._clock1.Name = "_clock1";
            this._clock1.Size = new System.Drawing.Size(150, 63);
            this._clock1.TabIndex = 0;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 362);
            this.Controls.Add(this.cuteButton1);
            this.Controls.Add(this.textControl1);
            this.Controls.Add(this.lblTest);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this._alarmClock1);
            this.Controls.Add(this._clock1);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private ctlClockLib.ClockControl _clock1;
        private ctlAlarmLib.AlarmClockControl _alarmClock1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label lblTest;
        private ctlNewTextLib.TextControl textControl1;
        private ctlCuteButton.CuteButton cuteButton1;
    }
}

