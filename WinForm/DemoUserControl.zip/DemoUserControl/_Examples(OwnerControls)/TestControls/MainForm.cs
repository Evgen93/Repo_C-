﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestControls
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            _alarmClock1.AlarmTime = dateTimePicker1.Value;
            _alarmClock1.AlarmSet = true;
            lblTest.Text = "Alarm Time is " + _alarmClock1.AlarmTime.ToShortTimeString();
        }

        private void cuteButton1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Вы нажали на кнопку!");
        }

       

    }
}
