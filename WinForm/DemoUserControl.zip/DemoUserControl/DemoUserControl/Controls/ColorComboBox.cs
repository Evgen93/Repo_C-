﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace DemoUserControl.Controls
{
    public partial class ColorComboBox : UserControl
    {
        public ColorComboBox()
        {
            InitializeComponent();
        }

        private void ColorComboBox_Load(object sender, EventArgs e)
        {
            Type type = typeof(Color);
            var colors = type.GetProperties(System.Reflection.BindingFlags.Public | BindingFlags.Static);
            cbColors.DataSource = DrawMode.OwnerDrawFixed;
        }
    }
}
