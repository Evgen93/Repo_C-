﻿namespace DemoUserControl
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.alarmControl1 = new ClocksLibrary.AlarmControl();
            this.clockControl2 = new ClocksLibrary.ClockControl();
            this.clockControl1 = new ClocksLibrary.ClockControl();
            this.roundButton1 = new DemoUserControl.RoundButton();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(589, 26);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // alarmControl1
            // 
            this.alarmControl1.AlarmTime = new System.DateTime(2018, 11, 6, 19, 49, 0, 0);
            this.alarmControl1.AutoSize = true;
            this.alarmControl1.ClockFormat = ClocksLibrary.ClockFormat.FullTime;
            this.alarmControl1.DisplayForeColor = System.Drawing.SystemColors.WindowText;
            this.alarmControl1.IsAlarmOn = false;
            this.alarmControl1.Location = new System.Drawing.Point(52, 126);
            this.alarmControl1.Name = "alarmControl1";
            this.alarmControl1.Size = new System.Drawing.Size(189, 114);
            this.alarmControl1.TabIndex = 3;
            // 
            // clockControl2
            // 
            this.clockControl2.AutoSize = true;
            this.clockControl2.ClockFormat = ClocksLibrary.ClockFormat.FullTime;
            this.clockControl2.DisplayForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.clockControl2.ForeColor = System.Drawing.Color.Red;
            this.clockControl2.Location = new System.Drawing.Point(41, 68);
            this.clockControl2.Name = "clockControl2";
            this.clockControl2.Size = new System.Drawing.Size(189, 36);
            this.clockControl2.TabIndex = 1;
            // 
            // clockControl1
            // 
            this.clockControl1.AutoSize = true;
            this.clockControl1.ClockFormat = ClocksLibrary.ClockFormat.ShortTime;
            this.clockControl1.DisplayForeColor = System.Drawing.Color.Maroon;
            this.clockControl1.ForeColor = System.Drawing.Color.Red;
            this.clockControl1.Location = new System.Drawing.Point(41, 26);
            this.clockControl1.Name = "clockControl1";
            this.clockControl1.Size = new System.Drawing.Size(189, 36);
            this.clockControl1.TabIndex = 0;
            this.clockControl1.ClockFormatChanged += new System.EventHandler(this.clockControl1_ClockFormatChanged);
            // 
            // roundButton1
            // 
            this.roundButton1.BrushColor = System.Drawing.Color.Fuchsia;
            this.roundButton1.Location = new System.Drawing.Point(381, 173);
            this.roundButton1.Name = "roundButton1";
            this.roundButton1.PenColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.roundButton1.Size = new System.Drawing.Size(131, 79);
            this.roundButton1.TabIndex = 4;
            this.roundButton1.Text = "roundButton1";
            this.roundButton1.Click += new System.EventHandler(this.roundButton1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(697, 400);
            this.Controls.Add(this.roundButton1);
            this.Controls.Add(this.alarmControl1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.clockControl2);
            this.Controls.Add(this.clockControl1);
            this.Name = "MainForm";
            this.Text = "Demo User Controls";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ClocksLibrary.ClockControl clockControl1;
        private ClocksLibrary.ClockControl clockControl2;
        private System.Windows.Forms.Button button1;
        private ClocksLibrary.AlarmControl alarmControl1;
        private RoundButton roundButton1;
    }
}

