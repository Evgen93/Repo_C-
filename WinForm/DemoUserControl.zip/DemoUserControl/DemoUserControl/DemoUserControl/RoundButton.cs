﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoUserControl
{
    public partial class RoundButton : Control
    {
        public RoundButton()
        {
            InitializeComponent();
            _penColor = Color.Red;
            _brushColor = Color.Green;
        }

        private Color _penColor;
        public Color PenColor
        {
            get { return _penColor; }
            set {
                _penColor = value;
                this.Invalidate();
            }
        }
        
        private Color _brushColor;
        public Color BrushColor
        {
            get { return _brushColor; }
            set {
                _brushColor = value;
                this.Invalidate();
            }
        }
        
        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);

            Graphics grh = pe.Graphics;

            Pen pen = new Pen(PenColor, 3);
            grh.DrawEllipse(pen, ClientRectangle);

            SolidBrush solidBrush = new SolidBrush(BrushColor);
            grh.FillEllipse(solidBrush, ClientRectangle);

        }
    }
}
