﻿namespace ClocksLibrary
{
    partial class AlarmControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAlarmOn = new System.Windows.Forms.CheckBox();
            this.lbAlarmInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAlarmOn
            // 
            this.btnAlarmOn.Appearance = System.Windows.Forms.Appearance.Button;
            this.btnAlarmOn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnAlarmOn.Location = new System.Drawing.Point(3, 66);
            this.btnAlarmOn.Name = "btnAlarmOn";
            this.btnAlarmOn.Size = new System.Drawing.Size(183, 45);
            this.btnAlarmOn.TabIndex = 1;
            this.btnAlarmOn.Text = "Alarm Off";
            this.btnAlarmOn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAlarmOn.UseVisualStyleBackColor = true;
            this.btnAlarmOn.Click += new System.EventHandler(this.btnAlarmOn_Click);
            // 
            // lbAlarmInfo
            // 
            this.lbAlarmInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbAlarmInfo.Location = new System.Drawing.Point(4, 39);
            this.lbAlarmInfo.Name = "lbAlarmInfo";
            this.lbAlarmInfo.Size = new System.Drawing.Size(182, 23);
            this.lbAlarmInfo.TabIndex = 2;
            this.lbAlarmInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AlarmControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lbAlarmInfo);
            this.Controls.Add(this.btnAlarmOn);
            this.Name = "AlarmControl";
            this.Size = new System.Drawing.Size(189, 116);
            this.Controls.SetChildIndex(this.btnAlarmOn, 0);
            this.Controls.SetChildIndex(this.lbAlarmInfo, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox btnAlarmOn;
        private System.Windows.Forms.Label lbAlarmInfo;
    }
}
