﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClocksLibrary
{
    public partial class ClockControl : UserControl
    {
        public event EventHandler ClockFormatChanged;

        protected virtual void OnClockFormatChanged()
        {
            if (ClockFormatChanged != null)
                ClockFormatChanged(this, EventArgs.Empty);
               // ClockFormatChanged.Invoke(this, EventArgs.Empty);
        }

        private ClockFormat _clockFormat;

        [Category("Clock")]
        [Description("ClockFormat")]
        public ClockFormat ClockFormat
        {
            get { return _clockFormat; }
            set
            {
                if (_clockFormat == value)
                    return;

                _clockFormat = value;
                OnClockFormatChanged();
            }
        }

        [Category("Clock")]
        [Description("DisplayForeColor")]
        public Color DisplayForeColor
        {
            get { return tbDisplay.ForeColor; }
            set { tbDisplay.ForeColor = value; }
        }

        public ClockControl()
        {
            InitializeComponent();
        }

        protected virtual void timer_Tick(object sender, EventArgs e)
        {
            if (_clockFormat == ClockFormat.FullTime)
                tbDisplay.Text = DateTime.Now.ToString("HH:mm:ss");
            else
                tbDisplay.Text = DateTime.Now.ToString("hh:mm:ss");
        }

        private void ClockControl_Load(object sender, EventArgs e)
        {
            timer.Start();
        }
    }

    public enum ClockFormat
    {
        FullTime, // 24
        ShortTime // 12
    }
}
