﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClocksLibrary
{
    public partial class AlarmControl : ClockControl
    {

        public DateTime AlarmTime { get; set; }

        public bool IsAlarmOn
        {
            get { return btnAlarmOn.Checked; }
            set { btnAlarmOn.Checked = value; }
        }
        
        public AlarmControl()
        {
            InitializeComponent();
           
        }
             

        private void btnAlarmOn_Click(object sender, EventArgs e)
        {
            if (IsAlarmOn)
            {
                btnAlarmOn.Text = "Alarm On";
            }
            else
            {
                btnAlarmOn.Text = "Alarm Off";
            }
        }

        protected override void timer_Tick(object sender, EventArgs e)
        {
            base.timer_Tick(sender, e);

            if (IsAlarmOn)
            {
                var dateNow = DateTime.Now;
                if (AlarmTime.Hour == dateNow.Hour &&
                    AlarmTime.Minute == dateNow.Minute &&
                    AlarmTime.Second == dateNow.Second)
                {
                    lbAlarmInfo.Text = "AAAAAAAAA!!!";
                }
            }
            else
            {
                lbAlarmInfo.Text = String.Empty;
            }
        }

    }
}
