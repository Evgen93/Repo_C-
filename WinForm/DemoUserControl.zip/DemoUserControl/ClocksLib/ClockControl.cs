﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClocksLib
{
    public partial class ClockControl : UserControl
    {
        public event EventHandler ClockFormatChanged;

        protected virtual void OnClockFormatChanged()
        {
            ClockFormatChanged?.Invoke(this, EventArgs.Empty);
        }

        private ClockFormat _timeFormat;

        [Category("Clock")]
        [Description("ClockFormat")]
        public ClockFormat TimeFormat
        {
            get { return _timeFormat; }
            set
            {
                if (_timeFormat == value)
                {
                    return;
                }
                _timeFormat = value; OnClockFormatChanged();
            }
        }

        public ClockControl()
        {
            InitializeComponent();
        }

        [Category("Clock")]
        [Description("ClockFormat")]
        public Color DisplayForeColor
        {
            get { return tbDisplay.ForeColor; }
            set { tbDisplay.ForeColor = value; }
        }

        protected virtual void timer_Tick(object sender, EventArgs e)
        {
            if (_timeFormat == ClockFormat.Fulltime)
            {
                tbDisplay.Text = DateTime.Now.ToString("HH:mm:ss");
            }
            else
            {
                tbDisplay.Text = DateTime.Now.ToString("hh:mm:ss");
            }
        }

        private void ClockControl_Load(object sender, EventArgs e)
        {
            timer.Start();
        }
    }

    public enum ClockFormat
    {
        Fulltime,
        ShortTime
    }
}
