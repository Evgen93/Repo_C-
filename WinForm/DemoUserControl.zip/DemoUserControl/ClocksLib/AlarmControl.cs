﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClocksLib
{
    public partial class AlarmControl : ClockControl
    {
        public bool IsAlarmOn
        {
          get { return btnAlarmOn.Checked; }
          set { btnAlarmOn.Checked = value; }
        }

        public DateTime AlarmTime { get; set; }

        public AlarmControl()
        {
            InitializeComponent();
        }

        private void btnAlarmOn_Click(object sender, EventArgs e)
        {
            if (IsAlarmOn)
            {
                LbAlarmInfo.Text = "Wake up!";
            }
            else
            {
                LbAlarmInfo.Text = string.Empty;
            }
        }

        protected override void timer_Tick(object sender, EventArgs e)
        {
            base.timer_Tick(sender, e);

            if (IsAlarmOn)
            {
                var dateNow = DateTime.Now;
                if (AlarmTime.Hour == dateNow.Hour &&
                    AlarmTime.Minute == dateNow.Minute &&
                    AlarmTime.Second == dateNow.Second)
                {
                    LbAlarmInfo.Text = "AAAAAAAAAA!!";
                }
            }
            else
            {
                LbAlarmInfo.Text = string.Empty;
            }
        }
    }
}
