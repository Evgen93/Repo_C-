﻿namespace ClocksLib
{
    partial class AlarmControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAlarmOn = new System.Windows.Forms.CheckBox();
            this.LbAlarmInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnAlarmOn
            // 
            this.btnAlarmOn.Appearance = System.Windows.Forms.Appearance.Button;
            this.btnAlarmOn.Location = new System.Drawing.Point(7, 74);
            this.btnAlarmOn.Name = "btnAlarmOn";
            this.btnAlarmOn.Size = new System.Drawing.Size(234, 36);
            this.btnAlarmOn.TabIndex = 1;
            this.btnAlarmOn.Text = "Alarm On";
            this.btnAlarmOn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnAlarmOn.UseVisualStyleBackColor = true;
            this.btnAlarmOn.Click += new System.EventHandler(this.btnAlarmOn_Click);
            // 
            // LbAlarmInfo
            // 
            this.LbAlarmInfo.Location = new System.Drawing.Point(3, 36);
            this.LbAlarmInfo.Name = "LbAlarmInfo";
            this.LbAlarmInfo.Size = new System.Drawing.Size(237, 35);
            this.LbAlarmInfo.TabIndex = 2;
            this.LbAlarmInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // AlarmControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.LbAlarmInfo);
            this.Controls.Add(this.btnAlarmOn);
            this.Name = "AlarmControl";
            this.Size = new System.Drawing.Size(247, 113);
            this.Controls.SetChildIndex(this.btnAlarmOn, 0);
            this.Controls.SetChildIndex(this.LbAlarmInfo, 0);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox btnAlarmOn;
        private System.Windows.Forms.Label LbAlarmInfo;
    }
}
