﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;

namespace Example2
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        // Общий анализ методов и свойств класса Graphics
        // DrawXXX
        /*       Методы применяются для рисования графических объектов, почти все методы 
                 перегружены и могут принимать различное количество параметров.
            DrawArc()           // рисование дуги
            DrawBezier()        // рисование кривой Безье
            DrawBeziers()       // рисование последовательности кривых Безье
            DrawCurve()         // рисование кривой через точки
            DrawClosedCurve()   // рисование кривой через точки (замкнутой)
            DrawIcon()          // рисование иконки
            DrawEllipse()       // рисование окружности
            DrawLine()          // рисование линии
            DrawLines()         // рисование линий
            DrawPie()           // рисование сетора
            DrawPath()          // рисование объекта GraphicsPath
            DrawRectangle()     // рисование прямоугольника
            DrawString()        // рисование строки текста
            DrawImage()         // рисование картинки
         */
        private void MainForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics grf = e.Graphics;
           

   // установка цвета ширины 1-ой линии
            float widthMain = 5;
            Pen penMain = new Pen(Color.Blue, widthMain);
            
           

   // прорисовка линий
            // x1=20, y1=20  x2=120, y2=120
            grf.DrawLine(penMain, 20,20, 120,120 );
            
            Point p1=new Point(20,120); // создание точки р1
            Point p2=new Point(120,20); // создание точки р2
            grf.DrawLine(penMain, p1, p2);

   // прорисовка прямоугольника
            grf.DrawRectangle(penMain, 20, 20, 100, 100);

   // прорисовка окружности (элипса)
            grf.DrawEllipse(penMain, 20, 20, 100, 100);

   // прорисовка полигона
            Point[]points=new Point[] // создание массива точек
            {
                new Point{X=160, Y=20}, // создание точки (инициализация через инициализаторы)
                new Point(210, 40),     // создание точки (инициализация через конструктор)
                new Point(190, 50),
                new Point(260, 80),
                new Point(160, 60),
            };
            grf.DrawPolygon(penMain, points);

   // прорисовка пирог
                                               //  x   y    w    h   startU  sweepU
            grf.DrawPie(penMain, 450, 20, 150, 150, 180, 180);

   // прорисовка дуги
                              //  x   y    w    h   startU  sweepU
            grf.DrawArc(penMain, 450, 100, 150, 150, 180, 180);
   
  // прорисовка кривой Безье
            grf.DrawBezier(penMain, 10, 260, 50, 150, 70, 130, 130, 300);

  // прорисовка кривой
            Point[]points2=new Point[] // создание массива точек
            {
                new Point(200, 200), 
                new Point(260, 200),    
                new Point(280, 280),
                new Point(200, 280),
            };
            grf.DrawCurve(penMain, points2);
   
  // прорисовка кривой (замкнутой)
            Point[] points3 = new Point[] // создание массива точек
            {
                new Point(300, 200), 
                new Point(360, 200),    
                new Point(390, 280),
                new Point(300, 280),
            };
            grf.DrawClosedCurve(penMain, points3);

   // прорисовка строки текста
            Brush brush = new SolidBrush(Color.Green);  //Создание кисти
            Font font = new System.Drawing.Font("Times New Roman", 25); // создание шрифта
            grf.DrawString("Текст 1", font, brush, 300, 20);        
  
  // прорисовка иконки
            grf.DrawIcon(SystemIcons.Warning, 300, 90); //стандратная иконка

            Icon newIcon = new Icon("Win.ico");
            grf.DrawIcon(newIcon, 350, 90);
  
  // прорисовка картинки
            Image newImage = Image.FromFile("Logo.jpg");
            grf.DrawImage(newImage, 430, 200, 100, 100);

            // Рисует заданное изображение в заданном месте, 
            // используя его исходный фактический размер.
            grf.DrawImageUnscaled(newImage, 430, 310, 100, 100);

            // Рисует заданное изображение без масштабирования и при 
            // необходимости обрезает его, чтобы оно вмещалось в 
            // указываемом прямоугольнике.
            Rectangle rect=new Rectangle(350, 310, 60, 60);
            grf.DrawImageUnscaledAndClipped(newImage, rect);

   // прорисовка GraphicsPath
            GraphicsPath graphPath = new GraphicsPath();
            graphPath.AddEllipse(50, 310, 200, 100);
            grf.DrawPath(penMain, graphPath);
        }
    }
}
