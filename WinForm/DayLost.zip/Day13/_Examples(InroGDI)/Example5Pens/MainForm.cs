﻿using System.Drawing;

using System.Drawing.Drawing2D;

using System.Windows.Forms;

namespace Example1
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen pen1 = new Pen(Color.Red);       // цвет линии
            Pen pen2 = new Pen(Color.Blue, 5);  // цвет и ширина лини

            g.DrawLine(pen1, 20, 50, 270, 50);

            // Устанавливаем стиль для концов и тела линии
            pen2.StartCap = LineCap.SquareAnchor; // квадрат на начале линии
            g.DrawLine(pen2, 20, 100, 270, 100);
            pen2.EndCap = LineCap.ArrowAnchor;    // стрелка на конце линии
            g.DrawLine(pen2, 20, 150, 270, 150);
            pen2.DashStyle = DashStyle.Dash;      // пунктирная линия
            g.DrawLine(pen2, 20, 200, 270, 200);
            pen2.DashCap = DashCap.Triangle;      // тип пунктиров линии
            g.DrawLine(pen2, 20, 250, 270, 250);
          

            Point p1 = new Point(0, 0);
            Point p2 = new Point(20, 20);
            LinearGradientBrush lgBrush1 = new LinearGradientBrush(p1, p2, Color.Violet, Color.LightSteelBlue);
            Pen pen3 = new Pen(lgBrush1, 10);  
            g.DrawLine(pen3, 20, 300, 270, 300);

        }
    }
}
