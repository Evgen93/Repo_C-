﻿namespace Example1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mnuOperations = new System.Windows.Forms.MenuStrip();
            this.mnuItemSelOperation = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuComplement = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuUnion = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuIntersect = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExclude = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuXor = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOperations.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuOperations
            // 
            this.mnuOperations.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuItemSelOperation});
            this.mnuOperations.Location = new System.Drawing.Point(0, 0);
            this.mnuOperations.Name = "mnuOperations";
            this.mnuOperations.Size = new System.Drawing.Size(675, 24);
            this.mnuOperations.TabIndex = 0;
            this.mnuOperations.Text = "menuStrip1";
            // 
            // mnuItemSelOperation
            // 
            this.mnuItemSelOperation.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuComplement,
            this.mnuUnion,
            this.mnuIntersect,
            this.mnuExclude,
            this.mnuXor});
            this.mnuItemSelOperation.Name = "mnuItemSelOperation";
            this.mnuItemSelOperation.Size = new System.Drawing.Size(206, 20);
            this.mnuItemSelOperation.Text = "Выберите операцию с регионами";
            // 
            // mnuComplement
            // 
            this.mnuComplement.Name = "mnuComplement";
            this.mnuComplement.Size = new System.Drawing.Size(265, 22);
            this.mnuComplement.Text = "Complement (операция ИЛИ)";
            this.mnuComplement.Click += new System.EventHandler(this.mnuComplement_Click);
            // 
            // mnuUnion
            // 
            this.mnuUnion.Name = "mnuUnion";
            this.mnuUnion.Size = new System.Drawing.Size(265, 22);
            this.mnuUnion.Text = "Union (операция объединения.)";
            this.mnuUnion.Click += new System.EventHandler(this.mnuUnion_Click);
            // 
            // mnuIntersect
            // 
            this.mnuIntersect.Name = "mnuIntersect";
            this.mnuIntersect.Size = new System.Drawing.Size(265, 22);
            this.mnuIntersect.Text = "Intersect (операция пересечения)";
            this.mnuIntersect.Click += new System.EventHandler(this.mnuIntersect_Click);
            // 
            // mnuExclude
            // 
            this.mnuExclude.Name = "mnuExclude";
            this.mnuExclude.Size = new System.Drawing.Size(265, 22);
            this.mnuExclude.Text = "Exclude (операция исключения)";
            this.mnuExclude.Click += new System.EventHandler(this.mnuExlude_Click);
            // 
            // mnuXor
            // 
            this.mnuXor.Name = "mnuXor";
            this.mnuXor.Size = new System.Drawing.Size(265, 22);
            this.mnuXor.Text = "Xor (операция исключающая или)";
            this.mnuXor.Click += new System.EventHandler(this.mnuXor_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 502);
            this.Controls.Add(this.mnuOperations);
            this.MainMenuStrip = this.mnuOperations;
            this.Name = "Form1";
            this.Text = "Демонстрация работы с регионами";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.mnuOperations.ResumeLayout(false);
            this.mnuOperations.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuOperations;
        private System.Windows.Forms.ToolStripMenuItem mnuItemSelOperation;
        private System.Windows.Forms.ToolStripMenuItem mnuComplement;
        private System.Windows.Forms.ToolStripMenuItem mnuUnion;
        private System.Windows.Forms.ToolStripMenuItem mnuIntersect;
        private System.Windows.Forms.ToolStripMenuItem mnuExclude;
        private System.Windows.Forms.ToolStripMenuItem mnuXor;
    }
}

