﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example4AddFigures
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            this.MinimumSize = new Size(300, 300);
            this.Size = new Size(600, 600);
            this.Resize += Form1_Resize;
        }

        void Form1_Resize(object sender, EventArgs e)
        {
            this.Refresh();              
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            //  размеры первого эллипса 
            Size size1 = new Size(200, 200);

            // координаты центра формы
            Point xyCentr = new Point(this.Width / 2, this.Height / 2);
           
            // координаты отображения 1-го эллипса
            Point xyCentr1 = new Point(this.Width / 2 - size1.Width / 2, this.Height / 2 - size1.Height / 2);

            // Создаем траеторию
            GraphicsPath myPath = new GraphicsPath();

            // добавление 1-го эллипса в траекторию (эллипс вписан в Rectandle)
            myPath.AddEllipse(new Rectangle(xyCentr1, size1));

            //  размеры второго эллипса 
            Size size2 = new Size(150, 150);
            // координаты отображения  2-го элипса
            Point xyCentr2 = new Point(this.Width / 2 - size2.Width / 2, this.Height / 2 - size2.Height / 2);
            // добавление 2-го эллипса в траекторию (эллипс вписан в Rectandle)
            myPath.AddEllipse(new Rectangle(xyCentr2, size2));

                      
            // размеры внутренних фигур (дуг)
            Size size3 = new Size(110, 110);
            //  координаты отображения  внутренних фигур (дуг)
            Point xyCentr3 = new Point(this.Width / 2 - size3.Width / 2, this.Height / 2 - size3.Height / 2);

            // добавление 1-ой дуги в траекторию 
            myPath.StartFigure();
            myPath.AddArc(new Rectangle(xyCentr3, size3), 10, 80);
           
            // добавление 2-ой дуги в траекторию 
            myPath.StartFigure();
            myPath.AddArc(new Rectangle(xyCentr3, size3), 100, 70);
           
            // добавление 2-ой дуги в траекторию 
            myPath.StartFigure();
            myPath.AddArc(new Rectangle(xyCentr3, size3), 190, 70);
          
            // добавление 2-ой дуги в траекторию 
            myPath.StartFigure();
            myPath.AddArc(new Rectangle(xyCentr3, size3), 280, 70);

            //  (РАСКОММЕНТИРУЙТЕ СЛЕД. СТРОКУ!!!!)
            //myPath.CloseFigure();
            //  (РАСКОММЕНТИРУЙТЕ СЛЕД. СТРОКУ!!!!)
            //myPath.CloseAllFigures();
           
            myPath.StartFigure();
            myPath.AddLine(new Point(xyCentr.X - 10, xyCentr.Y), new Point(xyCentr.X - 50, xyCentr.Y));
            myPath.StartFigure();
            myPath.AddLine(new Point(xyCentr.X + 10, xyCentr.Y), new Point(xyCentr.X + 50, xyCentr.Y));
            myPath.StartFigure();
            myPath.AddLine(new Point(xyCentr.X, xyCentr.Y - 10), new Point(xyCentr.X, xyCentr.Y - 50));
            myPath.StartFigure();
            myPath.AddLine(new Point(xyCentr.X, xyCentr.Y + 10), new Point(xyCentr.X, xyCentr.Y + 50));

            myPath.AddEllipse(xyCentr.X,xyCentr.Y, 1,1);

            Pen myPen3 = new Pen(Color.Red, 5);
            g.DrawPath(myPen3, myPath);
        }
    }
}
