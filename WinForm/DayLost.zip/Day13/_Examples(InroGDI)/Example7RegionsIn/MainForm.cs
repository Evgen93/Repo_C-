﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example2
{
    public partial class MainForm : Form
    {
        Timer timer;  //создание таймера 

        int Count = 0;               // счетчик количества попаданий
        Random rnd = new Random();   // датчик случайных чисел


        public MainForm()
        {
            InitializeComponent();
            timer = new Timer();  // инициализация таймера
            timer.Interval = 10;  // установка иньервала
            timer.Tick += timer_Tick;
         
        }

        void timer_Tick(object sender, EventArgs e)
        {
            Draw();     // вызов метода рисовать при срабатывании таймера
        }

        void Draw()
        {
            Graphics g = this.CreateGraphics();
           
            // формирование области для эллипса (размещение по центру экрана)
            Rectangle rect = new Rectangle(this.Width / 2 - 100, this.Height / 2 - 100, 200, 200);
            // прорисовка эллипса 
            g.DrawEllipse(new Pen(Color.Red, 10), rect);
            
            // формирование области для точки (рисуется на базе эллипса диаметром 3 пикселя)
            Rectangle rectPoint = new Rectangle(rnd.Next(0, this.Width), rnd.Next(0, this.Height), 3, 3);
            // прорисовка эллипса 
            g.DrawEllipse(new Pen(Color.Black, 3), rectPoint);

          

            if (!miFigura.Checked)
            {
                Region region = new Region(rect);
                if (region.IsVisible(rectPoint))
                {
                    Count++;
                    region.Intersect(rectPoint);
                    g.FillRegion(new SolidBrush(Color.Red), region);

                    this.Text = Count.ToString();
                }
            }
            else
            {
               
                GraphicsPath path=new GraphicsPath();
                path.AddArc(rect, 0,360);  // добавление дуги!
                Region region = new Region(path);

                if (region.IsVisible(rectPoint))
                {
                    Count++;
                    region.Intersect(rectPoint);
                    g.FillRegion(new SolidBrush(Color.Red), region);

                    this.Text = Count.ToString();
                }
            
            }


        }

      
        private void пускToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timer.Start();
        }

        private void стопToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timer.Stop();
            Count = 0;
        }

        private void очиститьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();
            g.Clear(Color.White);
        }

       
       

    }
}
