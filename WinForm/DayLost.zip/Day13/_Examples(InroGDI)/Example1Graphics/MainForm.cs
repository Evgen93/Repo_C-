﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Example1
{
    public partial class MainForm : Form
    {
        int paintCount = 0;  // счетчик количества перерисовок формы
        public MainForm()
        {
            
            InitializeComponent();
           
        }
        // обработчик события перерисовки формы 
        // событие генерируется всегда, когда необходима прорисовка формы !!!
        // Данное событие вызывает Windows
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            // Класс Graphics - основа GDI+
            // Он обеспечивает основную функциональность визуализации
            // для этого содержит методы и свойства для рисования графических объектов
            
            //     1-ый способ получения объекта Graphics
            Graphics grf1 = e.Graphics;

            //     2-ой способ получения объекта Graphics

            Graphics grf2 = this.CreateGraphics();

            //     3-ий способ получения объекта Graphics
            try
            {
                Bitmap myBitmap = new Bitmap(@"Background.bmp");  
                Graphics grf3 = Graphics.FromImage(myBitmap);
            }
            catch (FileNotFoundException ex)
            {
                MessageBox.Show("Файл не найден");
            }

           this.Text = String.Format("paintCount: {0}", ++paintCount);
        }
    }
}
