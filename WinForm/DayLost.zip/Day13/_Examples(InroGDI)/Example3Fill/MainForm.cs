﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example3
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        // Общий анализ методов и свойств класса Graphics
        // FillXXX()
        /*       Методы применяются для заполнения внутренних областей графических форм, 
                 почти все методы перегружены и могут принимать различное количество параметров.
          
           FillEllipse()
           FillPath()
           FillPie()
           FillPoligon()
           FillRectangle()
           FillRegion()
           FillRectangles()
           FillClosedCurve()
         */
        private void MainForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics grf = e.Graphics;


      //создание кисти
           
            // класс Brush (Кисть) - абстрактный класс
            // является базовым для всех классов - разновидностей кистей
            Brush brushMain=new SolidBrush(Color.CadetBlue);

     // заливка окружности
            grf.FillEllipse(brushMain, 20, 20, 100, 80);
         

     // заливка объекта GraphicsPath
            GraphicsPath graphPath = new GraphicsPath();
            graphPath.AddEllipse(180, 20, 100, 100);
            grf.FillPath(brushMain, graphPath);
          

     // заливка сектора
            grf.FillPie(brushMain, 320, 20, 100, 100, 45, 90);
            
     // заливка полигона
            Point[] points = new Point[] // создание массива точек
            {
                new Point{X=30, Y=160}, // создание точки (инициализация через инициализаторы)
                new Point(130, 160),     // создание точки (инициализация через конструктор)
                new Point(130, 200),
                new Point(150, 200),
                new Point(150, 250),
            };
            grf.FillPolygon(brushMain, points);

     // заливка прямоугольника
            grf.FillRectangle(brushMain, 200, 150, 100, 100);
            
    // заливка прямоугольников
            Rectangle [] rects=new Rectangle[]
            {
              new Rectangle(30, 300, 60, 60),
              new Rectangle(90, 360, 60, 60),
            };
            grf.FillRectangles(brushMain, rects);

     // заливка объекта Region
            Region region = new Region(new Rectangle(350, 150, 60, 60));
            grf.FillRegion(brushMain, region);

    // заливка замкнутой кривой 
            Point[] points2 = new Point[] // создание массива точек
            {
                new Point(250, 300), 
                new Point(350, 400),    
                new Point(350, 430),
                new Point(400, 350)
            };
            grf.FillClosedCurve(brushMain, points2);
        }
    }
}
