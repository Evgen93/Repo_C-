﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExampleRoundForm
{
    public partial class MainForm : Form
    {

        private Point mouseOffset;         // координаты
        private bool isMouseDown = false;  // принак нажатия мыши

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            DoEllipseForm();
        }

        private void DoEllipseForm()
        {
            GraphicsPath path = new GraphicsPath();
            path.AddEllipse(50, 50, 300, 300);              // размер эллипса, описывающего окно
            this.Region = new System.Drawing.Region(path);
        }

        private void DoTriangleForm()
        {
            GraphicsPath path = new GraphicsPath();
            path.AddPolygon(new Point[] { new Point(50, 150), new Point(300, 300), new Point(300, 50) });  
            this.Region = new System.Drawing.Region(path);
        }

        private void MainForm_MouseDown(object sender, MouseEventArgs e)
        {
            int xOffset;
            int yOffset;

            if (e.Button == MouseButtons.Left)
            {
                xOffset = -e.X - SystemInformation.FrameBorderSize.Width;
                yOffset = -e.Y - SystemInformation.CaptionHeight -  SystemInformation.FrameBorderSize.Height;
                mouseOffset = new Point(xOffset, yOffset);
                isMouseDown = true;
            }   
        }

        private void MainForm_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown)
            {
                Point mousePos = Control.MousePosition;
                mousePos.Offset(mouseOffset.X, mouseOffset.Y);
                Location = mousePos;
            }
        }

        private void MainForm_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isMouseDown = false;
            }
        }

        private void miClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rbEllipse_Click(object sender, EventArgs e)
        {
            if (rbEllipse.Checked)
            {
                DoEllipseForm();
            }
            else
            {
                DoTriangleForm();
            }
        }
    }
}
