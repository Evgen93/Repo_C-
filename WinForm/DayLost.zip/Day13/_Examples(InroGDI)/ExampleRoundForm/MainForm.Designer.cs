﻿namespace ExampleRoundForm
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.miClose = new System.Windows.Forms.ToolStripMenuItem();
            this.rbEllipse = new System.Windows.Forms.RadioButton();
            this.rbtriangle = new System.Windows.Forms.RadioButton();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.miClose});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(104, 26);
            // 
            // miClose
            // 
            this.miClose.Name = "miClose";
            this.miClose.Size = new System.Drawing.Size(103, 22);
            this.miClose.Text = "Close";
            this.miClose.Click += new System.EventHandler(this.miClose_Click);
            // 
            // rbEllipse
            // 
            this.rbEllipse.AutoSize = true;
            this.rbEllipse.Checked = true;
            this.rbEllipse.Location = new System.Drawing.Point(158, 125);
            this.rbEllipse.Name = "rbEllipse";
            this.rbEllipse.Size = new System.Drawing.Size(81, 17);
            this.rbEllipse.TabIndex = 1;
            this.rbEllipse.TabStop = true;
            this.rbEllipse.Text = "Оружность";
            this.rbEllipse.UseVisualStyleBackColor = true;
            this.rbEllipse.Click += new System.EventHandler(this.rbEllipse_Click);
            // 
            // rbtriangle
            // 
            this.rbtriangle.AutoSize = true;
            this.rbtriangle.Location = new System.Drawing.Point(158, 149);
            this.rbtriangle.Name = "rbtriangle";
            this.rbtriangle.Size = new System.Drawing.Size(90, 17);
            this.rbtriangle.TabIndex = 2;
            this.rbtriangle.Text = "Треугольник";
            this.rbtriangle.UseVisualStyleBackColor = true;
            this.rbtriangle.Click += new System.EventHandler(this.rbEllipse_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 379);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.rbtriangle);
            this.Controls.Add(this.rbEllipse);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseUp);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem miClose;
        private System.Windows.Forms.RadioButton rbEllipse;
        private System.Windows.Forms.RadioButton rbtriangle;
    }
}

