﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example5Text
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            GraphicsPath myPath = new GraphicsPath();  // создание траектории

            string stringText = "C#/.NET";            //  строка для вывода


            FontFamily family = new FontFamily("Arial");    // выбор шрифта через класс FontFamily
            int fontStyle = (int)FontStyle.Italic;          // выбор стиля шрифта - курсив
            int emSize = 96;                                // установка размера шрифта
            Point origin = new Point(20, 20);                  // точка вывода текста
            StringFormat format = StringFormat.GenericDefault; // установка формата строки
            
            // добавление текста в траекторию
            myPath.AddString(stringText,
                family,
                fontStyle,
                emSize,
                origin,
                format);

            // установка качества отображения 
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality;
            // заливка текста 
            e.Graphics.FillPath(Brushes.Bisque, myPath);
            // обводка текста!
            e.Graphics.DrawPath(new Pen(Brushes.Aqua, 2), myPath);
                      
        }
    }
}
