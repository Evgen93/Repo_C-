﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exampe3AddFigures
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            GraphicsPath path = new GraphicsPath();
            path.AddLine(20, 20, 170, 20);  // добавление линии
            path.AddLine(20, 20, 20, 100);  // добавление линии

            // добавление  новую фигуру
            //  (ЗАКОМЕНТИРУЙТЕ СЛЕД. СТРОКУ!!!!)
            path.StartFigure(); // для того чтобы не было сплошного рисования 
            // (перехода от одной фигуры к другой)
            path.AddLine(240, 140, 240, 50); // добавление линии
            path.AddLine(240, 140, 80, 140); // добавление линии
           
            path.StartFigure();
            path.AddRectangle(new Rectangle(30, 30, 200, 100));// добавление прямоугольника

            // рисуем  path
            Pen redPen = new Pen(Color.Red, 2);
            g.FillPath(new SolidBrush(Color.Bisque), path);
            g.DrawPath(redPen, path);
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            this.Refresh();
        }
    }
}
