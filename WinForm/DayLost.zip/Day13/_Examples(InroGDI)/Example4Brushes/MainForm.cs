﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // SolidBrush заполняет фигуру сплошным цветом
            SolidBrush solidBrush = new SolidBrush(Color.Blue);
            g.FillRectangle(solidBrush, 20, 20, 150, 50);
           
            //TextureBrush позволяет заполнить фигуру рисунком
            Image image=Image.FromFile("fon.jpg");
            TextureBrush textureBrush = new TextureBrush(image);
            g.FillRectangle(textureBrush, 20, 100, 150, 50);

            // HatchBrush позволяет закрасить внутреннюю областью объекта
            // при помощи большого количества штриховки, определенных в перечислении
            // HatchStyle (имеется 54 уникальных стиля штриховки)
            HatchBrush hatchBrush = new HatchBrush(HatchStyle.BackwardDiagonal, Color.Red, Color.White);
            g.FillRectangle(hatchBrush, 20, 180, 150, 50);
        

           // LinearGradientBrush содержит кисть, которая позволяет рисовать плавный 
           // переход от одного цвета к другому, причем первый цвет переходит во второй 
           // под определенным углом. Углы при этом задаются в градусах. Угол, равный 0
           // означает, что переход от одного цвета к другому осуществляется слева 
           // направо. Угол, равный 90 , означает, что переход от одного цвета к другому
           // осуществляется сверху вниз.

            Point p1 = new Point(0,0);      // точки указывающие на направление 
            Point p2 = new Point(200, 0);

            LinearGradientBrush lgBrush1 = new LinearGradientBrush(p1, p2, Color.Violet, Color.LightSteelBlue);
            g.FillRectangle(lgBrush1, 250, 20, 150, 50);

            // заполнение повторяется три раза
            // т.к. ширина и высота rect (50*50) три раза в Rectangle(150*50)
            Rectangle rect = new Rectangle(0,0,50,50);
            LinearGradientBrush lgBrush2 = new LinearGradientBrush(rect, Color.Violet, Color.LightSteelBlue, LinearGradientMode.Horizontal);
            g.FillRectangle(lgBrush2, 250, 100, 150, 50);

            LinearGradientBrush lgBrush3 = new LinearGradientBrush(rect, Color.Violet, Color.LightSteelBlue, LinearGradientMode.Vertical);
            g.FillRectangle(lgBrush3, 250, 180, 150, 50);

           // PathGradientBrush позволяет создавать сложный эффект затенения, при котором
           // используется изменение цвета от середины рисуемого пути к его краям.
            
            GraphicsPath path = new GraphicsPath();
            Rectangle rect2 = new Rectangle(450, 20, 150, 50);
            path.AddRectangle(rect2);
            PathGradientBrush pthGrBrush = new PathGradientBrush(path);
            pthGrBrush.CenterColor = Color.Blue;
            e.Graphics.FillEllipse(pthGrBrush, 450, 20, 150, 50);
            
           
           

            
        }
    }
}
