﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExampleMainMenu
{
    public partial class MainForm : Form
    {

        // Основные свойства
        // ShortcutKeys - горячие клавиши
        // Для пунктов главного меню устанавливаем перед первой буквой &
        // и при нажатии Alt можно выбрать пункт меню



        public MainForm()
        {
            InitializeComponent();
        }

        private void miOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            if (opf.ShowDialog() == DialogResult.OK)
            { 
             
            }
        }
    }
}
