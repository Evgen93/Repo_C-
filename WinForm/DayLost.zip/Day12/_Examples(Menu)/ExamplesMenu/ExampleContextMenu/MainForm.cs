﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExampleContextMenu
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            // Создание контектсного меню в коде

            ContextMenuStrip contextMenu=new ContextMenuStrip();

            ToolStripMenuItem miCopy = new ToolStripMenuItem();
            miCopy.Text = "Копировать";
            miCopy.Image = Properties.Resources.copy;
            //связываем меню с акселератором Alt+C
            miCopy.ShortcutKeys = Keys.Control | Keys.C;
            miCopy.ShowShortcutKeys = true; //отображать акселераторы
            miCopy.Click += (oo,ee) =>
                {
                    MessageBox.Show("Копировать");
                };
            contextMenu.Items.Add(miCopy);
            textBox2.ContextMenuStrip = contextMenu;

        }
    }
}
