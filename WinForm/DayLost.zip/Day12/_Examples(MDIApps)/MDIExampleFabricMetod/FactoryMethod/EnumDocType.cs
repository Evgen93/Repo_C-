﻿
namespace FactoryMethod
{
    enum DocType
    {
        TextDoc,
        PngDoc
    }
}
