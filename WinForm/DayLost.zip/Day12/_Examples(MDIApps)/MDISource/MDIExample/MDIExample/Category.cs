﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDIExample
{
    partial class Category : Form
    {
        public Category()
        {
            InitializeComponent();
            
           
        }

      

        private void button1_Click(object sender, EventArgs e)
        {
          Form mainForm= (MainForm)this.MdiParent;
          mainForm.Text = "1212121212";
          
        }
    }
}
