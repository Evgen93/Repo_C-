﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace DemoCrypt
{
	class Program
	{
		static void Main()
		{
			string[] lines = {"Windows Forms", "Standart Dialogs", "Text line"};
			File.WriteAllLines("file_sourse.txt", lines);
			CryptHelper.CryptDataInFile();
			CryptHelper.DeCryptDataInFile();

			Console.WriteLine(String.Join(" ", File.ReadAllLines("file_new.txt")));
			Console.ReadKey();
		}
	}

	internal static class CryptHelper
	{
		public static void CryptDataInFile()
		{
			var cryptAlgorithm = new TripleDESCryptoServiceProvider();
			using (var file = new FileStream("file_crypted.txt", FileMode.Create))
			{
				using (var cryptoStream = new CryptoStream(file, cryptAlgorithm.CreateEncryptor(), CryptoStreamMode.Write))
				{

					var lines = File.ReadAllLines("file_sourse.txt", Encoding.Default);

					using (var streamWriter = new StreamWriter(cryptoStream, Encoding.Default))
					{
						foreach (var line in lines)
						{
							streamWriter.WriteLine(line);
						}
					}
				}
			}

			using (var fileKey = new FileStream("file_key.key", FileMode.Create))
			{
				using (var binaryWriter = new BinaryWriter(fileKey))
				{
					binaryWriter.Write(cryptAlgorithm.IV);
					binaryWriter.Write(cryptAlgorithm.Key);
				}
			}
		}

		public static void DeCryptDataInFile()
		{
			var cryptAlgorithm = new TripleDESCryptoServiceProvider();

			using (FileStream fileKey = new FileStream("file_key.key", FileMode.Open))
			{
				using (BinaryReader binaryReader = new BinaryReader(fileKey))
				{
					cryptAlgorithm.IV = binaryReader.ReadBytes(8);
					cryptAlgorithm.Key = binaryReader.ReadBytes(24);
				}
			}

			using (var file = new FileStream("file_crypted.txt", FileMode.Open))
			{
				using (var cryptoStream = new CryptoStream(file, cryptAlgorithm.CreateDecryptor(), CryptoStreamMode.Read))
				{

					using (var streamReader = new StreamReader(cryptoStream, Encoding.Default))
					{
						var text= streamReader.ReadToEnd();

						File.WriteAllText("file_new.txt", text, Encoding.Default);
					}
				}
			}

		}
	}

}
