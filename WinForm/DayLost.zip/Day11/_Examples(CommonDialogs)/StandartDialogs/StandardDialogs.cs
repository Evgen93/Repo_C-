﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace FormsApp
{
    public partial class StandardDialogs : Form
    {
       
        public StandardDialogs()
        {
            InitializeComponent();

        }

        #region Вкладка "Обзор"

        private void standardDialogs_Click(object sender, System.EventArgs e)
        {
            RadioButton radio = (RadioButton)sender;
            // Для контроля при отладке
            System.Diagnostics.Debug.WriteLine("Нажата радиокнопка " + radio.Text);

            switch (radio.Text.Trim())// Чтобы убрать возможные пробелы
            {
                case "MessageBox":
                    MessageBox.Show( // Статический метод - модальный вызов
                        "Это удобная форма выдачи сообщений!", // Сообщение
                        "Стандартный диалог MessageBox", // Заголовок окна
                        MessageBoxButtons.OK, // Кнопка OK
                        MessageBoxIcon.Stop);// Критическая иконка
                    break;
                case "OpenFileDialog":
                    OpenFileDialog openFileDialog = new OpenFileDialog();
                    openFileDialog.Title = "OpenFileDialog";
                    openFileDialog.ShowDialog();// Модальный вызов
                    openFileDialog.Dispose();// Вызов сборщика мусора
                    break;
                case "SaveFileDialog":
                    SaveFileDialog saveFileDialog = new SaveFileDialog();
                    saveFileDialog.Title = "SaveFileDialog";
                    saveFileDialog.ShowDialog();// Модальный вызов
                    saveFileDialog.Dispose();// Вызов сборщика мусора
                    break;
                case "ColorDialog":
                    ColorDialog colorDialog = new ColorDialog();
                    colorDialog.ShowDialog();// Модальный вызов
                    colorDialog.Dispose();// Вызов сборщика мусора
                    break;
                case "FontDialog":
                    FontDialog fontDialog = new FontDialog();
                    fontDialog.ShowDialog();// Модальный вызов
                    fontDialog.Dispose();// Вызов сборщика мусора
                    break;
                case "PrintDialog":
                    PrintDialog printDialog = new PrintDialog();
                    printDialog.AllowSomePages = true;// Настраиваем доступ к выбору страниц
                    printDialog.ShowHelp = true; // Отображать кнопку помощи
                    printDialog.Document =
                        new System.Drawing.Printing.PrintDocument();
                    DialogResult result = printDialog.ShowDialog();// Модальный вызов
                    if (result == DialogResult.OK)
                        MessageBox.Show("Пользователь хотел печатать");
                    printDialog.Dispose();// Вызов сборщика мусора
                    break;
                case "PrintPreviewDialog":
                    PrintPreviewDialog printPreviewDialog =
                        new PrintPreviewDialog();
                    printPreviewDialog.Document =
                        new System.Drawing.Printing.PrintDocument();
                    printPreviewDialog.ShowDialog();// Модальный вызов
                    printPreviewDialog.Dispose();// Вызов сборщика мусора
                    break;
                case "PageSetupDialog":
                    PageSetupDialog pageSetupDialog = new PageSetupDialog();
                    pageSetupDialog.PageSettings =
                        new System.Drawing.Printing.PageSettings();
                    pageSetupDialog.PrinterSettings =
                        new System.Drawing.Printing.PrinterSettings();
                    //Не показывать сеть в диалоге принтера
                    pageSetupDialog.ShowNetwork = false;
                    pageSetupDialog.ShowDialog();// Модальный вызов
                    pageSetupDialog.Dispose();// Вызов сборщика мусора
                    break;
                case "FolderBrowserDialog":
                    FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog();
                    folderBrowserDialog.Description = "Установите нужный каталог текущим";
                    // Каталог по умолчанию - "Мои документы" 
                    folderBrowserDialog.RootFolder = Environment.SpecialFolder.Personal;
                    folderBrowserDialog.ShowDialog();// Модальный вызов
                    folderBrowserDialog.Dispose();// Вызов сборщика мусора
                    break;
                default:
                    MessageBox.Show("Пока нет - создадим позднее",
                        "Самодельный диалог",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Stop);
                    break;
            }
        }
        #endregion

       


    }
}
