﻿namespace FormsApp
{
    partial class StandardDialogs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btnResetColorDialog = new System.Windows.Forms.Button();
            this.btnShowColorDialog = new System.Windows.Forms.Button();
            this.lblColorName = new System.Windows.Forms.Label();
            this.lblColorTitle = new System.Windows.Forms.Label();
            this.ShowHelp = new System.Windows.Forms.CheckBox();
            this.SolidColorOnly = new System.Windows.Forms.CheckBox();
            this.FullOpen = new System.Windows.Forms.CheckBox();
            this.AnyColor = new System.Windows.Forms.CheckBox();
            this.AllowFullOpen = new System.Windows.Forms.CheckBox();
            this.lblColorDialog = new System.Windows.Forms.Label();
            this.panelColorDialog = new System.Windows.Forms.Panel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnBrowseFileName = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.txtTitle = new System.Windows.Forms.TextBox();
            this.txtInitialDirectory = new System.Windows.Forms.TextBox();
            this.txtFilter = new System.Windows.Forms.TextBox();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.txtDefaultExt = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.filterIndex = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnShowDialog = new System.Windows.Forms.Button();
            this.checkedListBox = new System.Windows.Forms.CheckedListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.btnSaveFile = new System.Windows.Forms.Button();
            this.btnOpenFile = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtSimpleEdit = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnShow = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage0 = new System.Windows.Forms.TabPage();
            this.groupReview = new System.Windows.Forms.GroupBox();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage4.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.filterIndex)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage0.SuspendLayout();
            this.groupReview.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            this.openFileDialog.Filter = "Текстовые файлы (*.txt)|*.txt|Все файлы (*.*)|*.*";
            this.openFileDialog.Title = "Открыть текстовый файл";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.Control;
            this.tabPage4.Controls.Add(this.btnResetColorDialog);
            this.tabPage4.Controls.Add(this.btnShowColorDialog);
            this.tabPage4.Controls.Add(this.lblColorName);
            this.tabPage4.Controls.Add(this.lblColorTitle);
            this.tabPage4.Controls.Add(this.ShowHelp);
            this.tabPage4.Controls.Add(this.SolidColorOnly);
            this.tabPage4.Controls.Add(this.FullOpen);
            this.tabPage4.Controls.Add(this.AnyColor);
            this.tabPage4.Controls.Add(this.AllowFullOpen);
            this.tabPage4.Controls.Add(this.lblColorDialog);
            this.tabPage4.Controls.Add(this.panelColorDialog);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(590, 354);
            this.tabPage4.TabIndex = 4;
            this.tabPage4.Text = "ColorDialog";
            // 
            // btnResetColorDialog
            // 
            this.btnResetColorDialog.AutoSize = true;
            this.btnResetColorDialog.Location = new System.Drawing.Point(248, 291);
            this.btnResetColorDialog.Margin = new System.Windows.Forms.Padding(2);
            this.btnResetColorDialog.Name = "btnResetColorDialog";
            this.btnResetColorDialog.Size = new System.Drawing.Size(56, 23);
            this.btnResetColorDialog.TabIndex = 10;
            this.btnResetColorDialog.Text = "Reset";
            this.btnResetColorDialog.UseVisualStyleBackColor = true;
            this.btnResetColorDialog.Click += new System.EventHandler(this.btnResetColorDialog_Click);
            // 
            // btnShowColorDialog
            // 
            this.btnShowColorDialog.AutoSize = true;
            this.btnShowColorDialog.Location = new System.Drawing.Point(326, 291);
            this.btnShowColorDialog.Margin = new System.Windows.Forms.Padding(2);
            this.btnShowColorDialog.Name = "btnShowColorDialog";
            this.btnShowColorDialog.Size = new System.Drawing.Size(56, 23);
            this.btnShowColorDialog.TabIndex = 9;
            this.btnShowColorDialog.Text = "Show";
            this.btnShowColorDialog.UseVisualStyleBackColor = true;
            this.btnShowColorDialog.Click += new System.EventHandler(this.btnShowColorDialog_Click);
            // 
            // lblColorName
            // 
            this.lblColorName.AutoSize = true;
            this.lblColorName.Location = new System.Drawing.Point(334, 258);
            this.lblColorName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblColorName.Name = "lblColorName";
            this.lblColorName.Size = new System.Drawing.Size(65, 13);
            this.lblColorName.TabIndex = 8;
            this.lblColorName.Text = "DefaultColor";
            this.lblColorName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblColorTitle
            // 
            this.lblColorTitle.AutoSize = true;
            this.lblColorTitle.Location = new System.Drawing.Point(224, 231);
            this.lblColorTitle.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblColorTitle.Name = "lblColorTitle";
            this.lblColorTitle.Size = new System.Drawing.Size(182, 13);
            this.lblColorTitle.TabIndex = 7;
            this.lblColorTitle.Text = "Наименование выбранного цвета:";
            // 
            // ShowHelp
            // 
            this.ShowHelp.AutoSize = true;
            this.ShowHelp.Location = new System.Drawing.Point(226, 188);
            this.ShowHelp.Margin = new System.Windows.Forms.Padding(2);
            this.ShowHelp.Name = "ShowHelp";
            this.ShowHelp.Size = new System.Drawing.Size(75, 17);
            this.ShowHelp.TabIndex = 6;
            this.ShowHelp.Text = "ShowHelp";
            this.ShowHelp.UseVisualStyleBackColor = true;
            // 
            // SolidColorOnly
            // 
            this.SolidColorOnly.AutoSize = true;
            this.SolidColorOnly.Location = new System.Drawing.Point(226, 154);
            this.SolidColorOnly.Margin = new System.Windows.Forms.Padding(2);
            this.SolidColorOnly.Name = "SolidColorOnly";
            this.SolidColorOnly.Size = new System.Drawing.Size(94, 17);
            this.SolidColorOnly.TabIndex = 5;
            this.SolidColorOnly.Text = "SolidColorOnly";
            this.SolidColorOnly.UseVisualStyleBackColor = true;
            // 
            // FullOpen
            // 
            this.FullOpen.AutoSize = true;
            this.FullOpen.Location = new System.Drawing.Point(226, 119);
            this.FullOpen.Margin = new System.Windows.Forms.Padding(2);
            this.FullOpen.Name = "FullOpen";
            this.FullOpen.Size = new System.Drawing.Size(68, 17);
            this.FullOpen.TabIndex = 4;
            this.FullOpen.Text = "FullOpen";
            this.FullOpen.UseVisualStyleBackColor = true;
            // 
            // AnyColor
            // 
            this.AnyColor.AutoSize = true;
            this.AnyColor.Location = new System.Drawing.Point(226, 85);
            this.AnyColor.Margin = new System.Windows.Forms.Padding(2);
            this.AnyColor.Name = "AnyColor";
            this.AnyColor.Size = new System.Drawing.Size(68, 17);
            this.AnyColor.TabIndex = 3;
            this.AnyColor.Text = "AnyColor";
            this.AnyColor.UseVisualStyleBackColor = true;
            // 
            // AllowFullOpen
            // 
            this.AllowFullOpen.AutoSize = true;
            this.AllowFullOpen.Checked = true;
            this.AllowFullOpen.CheckState = System.Windows.Forms.CheckState.Checked;
            this.AllowFullOpen.Location = new System.Drawing.Point(226, 51);
            this.AllowFullOpen.Margin = new System.Windows.Forms.Padding(2);
            this.AllowFullOpen.Name = "AllowFullOpen";
            this.AllowFullOpen.Size = new System.Drawing.Size(93, 17);
            this.AllowFullOpen.TabIndex = 2;
            this.AllowFullOpen.Text = "AllowFullOpen";
            this.AllowFullOpen.UseVisualStyleBackColor = true;
            // 
            // lblColorDialog
            // 
            this.lblColorDialog.AutoSize = true;
            this.lblColorDialog.Location = new System.Drawing.Point(224, 15);
            this.lblColorDialog.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblColorDialog.Name = "lblColorDialog";
            this.lblColorDialog.Size = new System.Drawing.Size(199, 13);
            this.lblColorDialog.TabIndex = 1;
            this.lblColorDialog.Text = "Булевы свойства диалога ColorDialog:";
            this.lblColorDialog.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelColorDialog
            // 
            this.panelColorDialog.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelColorDialog.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelColorDialog.Location = new System.Drawing.Point(0, 0);
            this.panelColorDialog.Margin = new System.Windows.Forms.Padding(2);
            this.panelColorDialog.Name = "panelColorDialog";
            this.panelColorDialog.Size = new System.Drawing.Size(212, 354);
            this.panelColorDialog.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.btnReset);
            this.tabPage3.Controls.Add(this.btnBrowseFileName);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.txtTitle);
            this.tabPage3.Controls.Add(this.txtInitialDirectory);
            this.tabPage3.Controls.Add(this.txtFilter);
            this.tabPage3.Controls.Add(this.txtFileName);
            this.tabPage3.Controls.Add(this.txtDefaultExt);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Controls.Add(this.filterIndex);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.btnShowDialog);
            this.tabPage3.Controls.Add(this.checkedListBox);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(590, 354);
            this.tabPage3.TabIndex = 3;
            this.tabPage3.Text = "SaveFileDialog";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // btnReset
            // 
            this.btnReset.AutoSize = true;
            this.btnReset.Location = new System.Drawing.Point(148, 301);
            this.btnReset.Margin = new System.Windows.Forms.Padding(2);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(56, 23);
            this.btnReset.TabIndex = 16;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnBrowseFileName
            // 
            this.btnBrowseFileName.AutoSize = true;
            this.btnBrowseFileName.Location = new System.Drawing.Point(356, 82);
            this.btnBrowseFileName.Margin = new System.Windows.Forms.Padding(2);
            this.btnBrowseFileName.Name = "btnBrowseFileName";
            this.btnBrowseFileName.Size = new System.Drawing.Size(61, 23);
            this.btnBrowseFileName.TabIndex = 15;
            this.btnBrowseFileName.Text = "Browse...";
            this.btnBrowseFileName.UseVisualStyleBackColor = true;
            this.btnBrowseFileName.Click += new System.EventHandler(this.btnBrowseFileName_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(157, 223);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(257, 13);
            this.label16.TabIndex = 14;
            this.label16.Text = "Title - заголовок диалогового окна SaveFileDialog";
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(142, 245);
            this.txtTitle.Margin = new System.Windows.Forms.Padding(2);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(271, 20);
            this.txtTitle.TabIndex = 13;
            // 
            // txtInitialDirectory
            // 
            this.txtInitialDirectory.Location = new System.Drawing.Point(142, 189);
            this.txtInitialDirectory.Margin = new System.Windows.Forms.Padding(2);
            this.txtInitialDirectory.Name = "txtInitialDirectory";
            this.txtInitialDirectory.Size = new System.Drawing.Size(271, 20);
            this.txtInitialDirectory.TabIndex = 10;
            // 
            // txtFilter
            // 
            this.txtFilter.Location = new System.Drawing.Point(142, 136);
            this.txtFilter.Margin = new System.Windows.Forms.Padding(2);
            this.txtFilter.Name = "txtFilter";
            this.txtFilter.Size = new System.Drawing.Size(234, 20);
            this.txtFilter.TabIndex = 6;
            // 
            // txtFileName
            // 
            this.txtFileName.Location = new System.Drawing.Point(142, 84);
            this.txtFileName.Margin = new System.Windows.Forms.Padding(2);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(206, 20);
            this.txtFileName.TabIndex = 4;
            // 
            // txtDefaultExt
            // 
            this.txtDefaultExt.Location = new System.Drawing.Point(142, 31);
            this.txtDefaultExt.Margin = new System.Windows.Forms.Padding(2);
            this.txtDefaultExt.Name = "txtDefaultExt";
            this.txtDefaultExt.Size = new System.Drawing.Size(271, 20);
            this.txtDefaultExt.TabIndex = 2;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(159, 170);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(180, 13);
            this.label15.TabIndex = 11;
            this.label15.Text = "InitialDirectory - начальный каталог";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(364, 117);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "FilterIndex";
            // 
            // filterIndex
            // 
            this.filterIndex.Location = new System.Drawing.Point(380, 137);
            this.filterIndex.Margin = new System.Windows.Forms.Padding(2);
            this.filterIndex.Name = "filterIndex";
            this.filterIndex.Size = new System.Drawing.Size(32, 20);
            this.filterIndex.TabIndex = 8;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(200, 117);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 13);
            this.label13.TabIndex = 7;
            this.label13.Text = "Filter - фильтр";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(157, 64);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(251, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "FileName - начальное или выбранное имя файла";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(162, 11);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(236, 13);
            this.label11.TabIndex = 3;
            this.label11.Text = "DefaultExt - расширение файла по умолчанию";
            // 
            // btnShowDialog
            // 
            this.btnShowDialog.Location = new System.Drawing.Point(216, 301);
            this.btnShowDialog.Margin = new System.Windows.Forms.Padding(2);
            this.btnShowDialog.Name = "btnShowDialog";
            this.btnShowDialog.Size = new System.Drawing.Size(56, 22);
            this.btnShowDialog.TabIndex = 1;
            this.btnShowDialog.Text = "Show";
            this.btnShowDialog.UseVisualStyleBackColor = true;
            this.btnShowDialog.Click += new System.EventHandler(this.btnShowDialog_Click);
            // 
            // checkedListBox
            // 
            this.checkedListBox.CheckOnClick = true;
            this.checkedListBox.FormattingEnabled = true;
            this.checkedListBox.Items.AddRange(new object[] {
            "AddExtension",
            "CheckFileExists",
            "CheckPathExists",
            "DereferenceLinks",
            "RestoreDirectory",
            "ShowHelp",
            "ValidateNames",
            "",
            "CreatePrompt",
            "OverwritePrompt"});
            this.checkedListBox.Location = new System.Drawing.Point(6, 11);
            this.checkedListBox.Margin = new System.Windows.Forms.Padding(2);
            this.checkedListBox.Name = "checkedListBox";
            this.checkedListBox.Size = new System.Drawing.Size(128, 244);
            this.checkedListBox.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.btnSaveFile);
            this.tabPage2.Controls.Add(this.btnOpenFile);
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(590, 354);
            this.tabPage2.TabIndex = 2;
            this.tabPage2.Text = "OpenFileDialog";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // btnSaveFile
            // 
            this.btnSaveFile.AutoSize = true;
            this.btnSaveFile.Location = new System.Drawing.Point(345, 50);
            this.btnSaveFile.Margin = new System.Windows.Forms.Padding(2);
            this.btnSaveFile.Name = "btnSaveFile";
            this.btnSaveFile.Size = new System.Drawing.Size(56, 23);
            this.btnSaveFile.TabIndex = 2;
            this.btnSaveFile.Text = "Save";
            this.btnSaveFile.UseVisualStyleBackColor = true;
            this.btnSaveFile.Click += new System.EventHandler(this.btnSaveFile_Click);
            // 
            // btnOpenFile
            // 
            this.btnOpenFile.AutoSize = true;
            this.btnOpenFile.Location = new System.Drawing.Point(345, 13);
            this.btnOpenFile.Margin = new System.Windows.Forms.Padding(2);
            this.btnOpenFile.Name = "btnOpenFile";
            this.btnOpenFile.Size = new System.Drawing.Size(56, 23);
            this.btnOpenFile.TabIndex = 1;
            this.btnOpenFile.Text = "Open";
            this.btnOpenFile.UseVisualStyleBackColor = true;
            this.btnOpenFile.Click += new System.EventHandler(this.btnOpenFile_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtSimpleEdit);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(323, 354);
            this.panel1.TabIndex = 0;
            // 
            // txtSimpleEdit
            // 
            this.txtSimpleEdit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSimpleEdit.Location = new System.Drawing.Point(0, 0);
            this.txtSimpleEdit.Margin = new System.Windows.Forms.Padding(2);
            this.txtSimpleEdit.MaxLength = 60000;
            this.txtSimpleEdit.Multiline = true;
            this.txtSimpleEdit.Name = "txtSimpleEdit";
            this.txtSimpleEdit.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtSimpleEdit.Size = new System.Drawing.Size(323, 354);
            this.txtSimpleEdit.TabIndex = 0;
            this.txtSimpleEdit.WordWrap = false;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnShow);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.comboBox1);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(590, 354);
            this.tabPage1.TabIndex = 1;
            this.tabPage1.Text = "MessageBox";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnShow
            // 
            this.btnShow.AutoSize = true;
            this.btnShow.Location = new System.Drawing.Point(182, 299);
            this.btnShow.Margin = new System.Windows.Forms.Padding(2);
            this.btnShow.Name = "btnShow";
            this.btnShow.Size = new System.Drawing.Size(56, 23);
            this.btnShow.TabIndex = 4;
            this.btnShow.Text = "Show";
            this.btnShow.UseVisualStyleBackColor = true;
            this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox5);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.comboBox4);
            this.groupBox1.Controls.Add(this.comboBox3);
            this.groupBox1.Controls.Add(this.comboBox2);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(14, 95);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(396, 195);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " Параметры перегрузки метода Show() ";
            // 
            // comboBox5
            // 
            this.comboBox5.Enabled = false;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "DefaultDesktopOnly",
            "RightAlign",
            "RtlReading",
            "ServiceNotification"});
            this.comboBox5.Location = new System.Drawing.Point(268, 162);
            this.comboBox5.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(118, 21);
            this.comboBox5.TabIndex = 13;
            this.comboBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.lockBox_KeyPress);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 164);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(259, 13);
            this.label10.TabIndex = 12;
            this.label10.Text = "System.Windows.Forms.MessageBoxOptions options:";
            // 
            // comboBox4
            // 
            this.comboBox4.Enabled = false;
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Button1",
            "Button2",
            "Button3"});
            this.comboBox4.Location = new System.Drawing.Point(324, 133);
            this.comboBox4.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(62, 21);
            this.comboBox4.TabIndex = 11;
            this.comboBox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.lockBox_KeyPress);
            // 
            // comboBox3
            // 
            this.comboBox3.Enabled = false;
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Asterisk",
            "Error",
            "Exclamation",
            "Hand",
            "Information",
            "None",
            "Question",
            "Stop",
            "Warning"});
            this.comboBox3.Location = new System.Drawing.Point(268, 104);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(118, 21);
            this.comboBox3.TabIndex = 10;
            this.comboBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.lockBox_KeyPress);
            // 
            // comboBox2
            // 
            this.comboBox2.Enabled = false;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "AbortRetryIgnore",
            "OK",
            "OKCancel",
            "RetryCancel",
            "YesNo",
            "YesNoCancel"});
            this.comboBox2.Location = new System.Drawing.Point(268, 75);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(118, 21);
            this.comboBox2.TabIndex = 9;
            this.comboBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.lockBox_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 136);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(317, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "System.Windows.Forms.MessageBoxDefaultButton defaultButton:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 107);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(230, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "System.Windows.Forms.MessageBoxIcon icon:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 79);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(260, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "System.Windows.Forms.MessageBoxButtons buttons:";
            // 
            // textBox2
            // 
            this.textBox2.Enabled = false;
            this.textBox2.Location = new System.Drawing.Point(121, 47);
            this.textBox2.Margin = new System.Windows.Forms.Padding(2);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(265, 20);
            this.textBox2.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 50);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(112, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "System.String caption:";
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Location = new System.Drawing.Point(121, 20);
            this.textBox1.Margin = new System.Windows.Forms.Padding(2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(265, 20);
            this.textBox1.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 22);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "System.String text:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1) MessageBox.Show(text);",
            "2) MessageBox.Show(text, caption);",
            "3) MessageBox.Show(text, caption, buttons);",
            "4) MessageBox.Show(text, caption, buttons, icon);",
            "5) MessageBox.Show(text, caption, buttons, icon, defaultButton);",
            "6) MessageBox.Show(text, caption, buttons, icon, defaultButton, options);"});
            this.comboBox1.Location = new System.Drawing.Point(14, 67);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(397, 21);
            this.comboBox1.TabIndex = 2;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 47);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(210, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Перегрузки метода MessageBox.Show():";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Blue;
            this.label3.Location = new System.Drawing.Point(10, 14);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(399, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Испытание простого диалогового окна сообщений";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage0
            // 
            this.tabPage0.Controls.Add(this.groupReview);
            this.tabPage0.Location = new System.Drawing.Point(4, 22);
            this.tabPage0.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage0.Name = "tabPage0";
            this.tabPage0.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage0.Size = new System.Drawing.Size(590, 354);
            this.tabPage0.TabIndex = 0;
            this.tabPage0.Text = "Обзор";
            this.tabPage0.UseVisualStyleBackColor = true;
            // 
            // groupReview
            // 
            this.groupReview.Controls.Add(this.radioButton10);
            this.groupReview.Controls.Add(this.radioButton9);
            this.groupReview.Controls.Add(this.radioButton8);
            this.groupReview.Controls.Add(this.radioButton7);
            this.groupReview.Controls.Add(this.radioButton6);
            this.groupReview.Controls.Add(this.radioButton5);
            this.groupReview.Controls.Add(this.radioButton4);
            this.groupReview.Controls.Add(this.radioButton3);
            this.groupReview.Controls.Add(this.radioButton2);
            this.groupReview.Controls.Add(this.radioButton1);
            this.groupReview.Controls.Add(this.label2);
            this.groupReview.Controls.Add(this.label1);
            this.groupReview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupReview.Location = new System.Drawing.Point(2, 2);
            this.groupReview.Margin = new System.Windows.Forms.Padding(2);
            this.groupReview.Name = "groupReview";
            this.groupReview.Padding = new System.Windows.Forms.Padding(2);
            this.groupReview.Size = new System.Drawing.Size(586, 350);
            this.groupReview.TabIndex = 0;
            this.groupReview.TabStop = false;
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButton10.Location = new System.Drawing.Point(232, 257);
            this.radioButton10.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(100, 24);
            this.radioButton10.TabIndex = 11;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "MyDialog";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.Visible = false;
            this.radioButton10.Click += new System.EventHandler(this.standardDialogs_Click);
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButton9.Location = new System.Drawing.Point(232, 231);
            this.radioButton9.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(194, 24);
            this.radioButton9.TabIndex = 10;
            this.radioButton9.TabStop = true;
            this.radioButton9.Text = "FolderBrowserDialog";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.Click += new System.EventHandler(this.standardDialogs_Click);
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButton8.Location = new System.Drawing.Point(232, 205);
            this.radioButton8.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(167, 24);
            this.radioButton8.TabIndex = 9;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "PageSetupDialog";
            this.radioButton8.UseVisualStyleBackColor = true;
            this.radioButton8.Click += new System.EventHandler(this.standardDialogs_Click);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButton7.Location = new System.Drawing.Point(232, 179);
            this.radioButton7.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(176, 24);
            this.radioButton7.TabIndex = 8;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "PrintPreviewDialog";
            this.radioButton7.UseVisualStyleBackColor = true;
            this.radioButton7.Click += new System.EventHandler(this.standardDialogs_Click);
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButton6.Location = new System.Drawing.Point(232, 153);
            this.radioButton6.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(115, 24);
            this.radioButton6.TabIndex = 7;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "PrintDialog";
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.Click += new System.EventHandler(this.standardDialogs_Click);
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButton5.Location = new System.Drawing.Point(19, 257);
            this.radioButton5.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(115, 24);
            this.radioButton5.TabIndex = 6;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "FontDialog";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.Click += new System.EventHandler(this.standardDialogs_Click);
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButton4.Location = new System.Drawing.Point(19, 231);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(120, 24);
            this.radioButton4.TabIndex = 5;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "ColorDialog";
            this.radioButton4.UseVisualStyleBackColor = true;
            this.radioButton4.Click += new System.EventHandler(this.standardDialogs_Click);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButton3.Location = new System.Drawing.Point(19, 205);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(147, 24);
            this.radioButton3.TabIndex = 4;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "SaveFileDialog";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.Click += new System.EventHandler(this.standardDialogs_Click);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButton2.Location = new System.Drawing.Point(19, 179);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(150, 24);
            this.radioButton2.TabIndex = 3;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "OpenFileDialog";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.Click += new System.EventHandler(this.standardDialogs_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.radioButton1.Location = new System.Drawing.Point(19, 153);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(129, 24);
            this.radioButton1.TabIndex = 2;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "MessageBox";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.Click += new System.EventHandler(this.standardDialogs_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(58, 113);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(498, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Щелкайте на радиокнопках, чтобы увидеть окно диалога";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(59, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(431, 102);
            this.label1.TabIndex = 0;
            this.label1.Text = "Визуальный обзор окон стандартных диалогов";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage0);
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl.Multiline = true;
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(598, 380);
            this.tabControl.TabIndex = 0;
            // 
            // StandardDialogs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(598, 380);
            this.Controls.Add(this.tabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "StandardDialogs";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Обзор стандартных диалогов";
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.filterIndex)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage0.ResumeLayout(false);
            this.groupReview.ResumeLayout(false);
            this.groupReview.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button btnResetColorDialog;
        private System.Windows.Forms.Button btnShowColorDialog;
        private System.Windows.Forms.Label lblColorName;
        private System.Windows.Forms.Label lblColorTitle;
        private System.Windows.Forms.CheckBox ShowHelp;
        private System.Windows.Forms.CheckBox SolidColorOnly;
        private System.Windows.Forms.CheckBox FullOpen;
        private System.Windows.Forms.CheckBox AnyColor;
        private System.Windows.Forms.CheckBox AllowFullOpen;
        private System.Windows.Forms.Label lblColorDialog;
        private System.Windows.Forms.Panel panelColorDialog;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnBrowseFileName;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtTitle;
        private System.Windows.Forms.TextBox txtInitialDirectory;
        private System.Windows.Forms.TextBox txtFilter;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.TextBox txtDefaultExt;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.NumericUpDown filterIndex;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnShowDialog;
        private System.Windows.Forms.CheckedListBox checkedListBox;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnSaveFile;
        private System.Windows.Forms.Button btnOpenFile;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtSimpleEdit;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnShow;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TabPage tabPage0;
        private System.Windows.Forms.GroupBox groupReview;
        private System.Windows.Forms.RadioButton radioButton10;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl;
    }
}