﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExampleFolderDialog
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
         // Настройкиэлемента FolderBrowserDialog
            // отображать кнопку "Создать папку"
            folderBrowserDialog1.ShowNewFolderButton = true;
            // установка корневого каталога (установлен рабочий стол)
            folderBrowserDialog1.RootFolder=Environment.SpecialFolder.Desktop;
          
            // открытие диалога 
            if (folderBrowserDialog1.ShowDialog()==DialogResult.OK)
            {
                // получение информации о выбранном каталоге через свойство SelectedPath
               listBox1.DataSource=Directory.GetFiles(folderBrowserDialog1.SelectedPath, "*.txt", SearchOption.AllDirectories);
            }


        }
    }
}
