﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Examples2FileDialogs
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // добавление расширение к файлу
            saveFileDialog1.AddExtension = true;
            // расширение по умолчанию
             saveFileDialog1.DefaultExt = ".jpg";
            // имя п умолчанию
            saveFileDialog1.FileName = "картинка";
            
            // заголовок окна 
            saveFileDialog1.Title = "Сохранение файла для демонстрации";

            // установка каталога 
            //saveFileDialog1.InitialDirectory = @"C:\";

            // установка запоминанию последнего каталога 
            saveFileDialog1.RestoreDirectory = true;


            //установим фильтр для файлов
            saveFileDialog1.Filter = "All Files(*.*)|*.*|Images(*.jpg)|*.jpg";
            saveFileDialog1.FilterIndex = 1;//по умолчанию фильтруются текстовые файлы

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                FileStream file = new FileStream(saveFileDialog1.FileName, FileMode.Create);
                file.Close();
            }
        }

       
    }
}
