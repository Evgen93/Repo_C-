﻿namespace ExampleColorDialog
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.panelColor = new System.Windows.Forms.Panel();
            this.lbText = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panelColor
            // 
            this.panelColor.BackColor = System.Drawing.Color.Black;
            this.panelColor.Location = new System.Drawing.Point(294, 26);
            this.panelColor.Name = "panelColor";
            this.panelColor.Size = new System.Drawing.Size(50, 38);
            this.panelColor.TabIndex = 2;
            this.panelColor.Click += new System.EventHandler(this.panelColor_Click);
            // 
            // lbText
            // 
            this.lbText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbText.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbText.Location = new System.Drawing.Point(12, 26);
            this.lbText.Name = "lbText";
            this.lbText.Size = new System.Drawing.Size(265, 38);
            this.lbText.TabIndex = 3;
            this.lbText.Text = "Установить шрифт";
            this.lbText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbText.Click += new System.EventHandler(this.lbText_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 87);
            this.Controls.Add(this.lbText);
            this.Controls.Add(this.panelColor);
            this.Name = "MainForm";
            this.Text = "Демонстрация ColorDialog и FontDialog";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.Panel panelColor;
        private System.Windows.Forms.Label lbText;
    }
}

