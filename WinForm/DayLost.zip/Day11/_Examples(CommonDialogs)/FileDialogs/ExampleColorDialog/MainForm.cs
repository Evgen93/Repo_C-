﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExampleColorDialog
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

        // Настройка элемента ColorDialog
            // разрешать открывать дополнительное окно для установки пользовательского цвета (кнопка "Определить цвет")
            colorDialog1.AllowFullOpen = true;
            // всегда открывать дополнительное окно для установки пользовательского цвета
            colorDialog1.FullOpen = false;

        // Настройка элемента FontDialog   
            fontDialog1.ShowEffects = false;  // отображать начертания
            fontDialog1.ShowColor= false;     // отображать настройки цвета
        

        }

        private void lbText_Click(object sender, EventArgs e)
        {

            if(DialogResult.OK== fontDialog1.ShowDialog())
            {
                // Получение выбранного шрифта с применением свойства Font
               lbText.Font = fontDialog1.Font;
            }
        }

        private void panelColor_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == colorDialog1.ShowDialog())
            {
                // Получение выбранного цвета с применением свойства Color
                panelColor.BackColor = colorDialog1.Color;
                lbText.ForeColor = colorDialog1.Color;
            }

        }
    }
}
