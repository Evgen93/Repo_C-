﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace FileDialogs
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void Load_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog(); //создали экземпляр
            //установим фильтр для файлов
            open.Filter = "All Files(*.*)|*.*|Text Files(*.txt)|*.txt|Doc Files(*.docx;*.doc)|*.docx;*.doc";
                   

            open.FilterIndex = 2;//по умолчанию фильтруются текстовые файлы
            
            if (open.ShowDialog() == DialogResult.OK)
            {
               StreamReader reader = File.OpenText(open.FileName);
               textBox1.Text = reader.ReadToEnd(); //считываем файл до конца
               reader.Close(); //закрываем reader
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();//создали экземпляр
            save.FilterIndex = 2;//по умолчанию фильтруются текстовые файлы

            save.Filter = "All Files(*.*)|*.*|Text Files(*.txt)|*.txt|Doc Files(*.docx;*.doc)|*.docx;*.doc";
            if (save.ShowDialog() == DialogResult.OK)
            {

                if (save.FilterIndex==3)
                    MessageBox.Show("Создаем Word!");

                StreamWriter writer = new StreamWriter(save.FileName);
                writer.Write(textBox1.Text); //записываем в файл содержимое поля
                writer.Close();//закрываем writer
            }
        }
    }
}
