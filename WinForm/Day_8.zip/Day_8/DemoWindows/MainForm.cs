﻿using DemoWindows.Entities;
using DemoWindows.Forms;
using System;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;

namespace DemoWindows
{
    public partial class MainForm : Form
    {
        SearchForm searchForm;
        BindingList<UserInfo> _users;

        private string _findText;
        public string FindText
        { get { return _findText; }
          set {
                _findText = value;
                SearchUser();
              }
        }

        private void SearchUser()
        {
            if (!String.IsNullOrWhiteSpace(_findText))
            {
                var searcgUser = _users.Where(p => p.FirstName.Contains(_findText) || p.LastName.Contains(_findText));
                gridFilters.DataSource = null;
                gridFilters.DataSource = searcgUser.ToList();
            }
        }

        public MainForm()
        {
            InitializeComponent();
            _users = new BindingList<UserInfo>();
            gridUsers.DataSource = _users;
            searchForm = new SearchForm();
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
            UserForm userForm = new UserForm();
            if(userForm.ShowDialog() == DialogResult.OK)
            {
                _users.Add(userForm.User);
            }
        }

        private void gridUsers_DoubleClick(object sender, EventArgs e)
        {
            if (gridUsers.SelectedRows.Count != 0)
            {
                var userInfo = (UserInfo)gridUsers.SelectedRows[0].DataBoundItem;
                UserForm userForm = new UserForm(userInfo);
                if (userForm.ShowDialog() == DialogResult.OK)
                {
                    _users.ResetBindings();
                }
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (!searchForm.Visible)
            {
                searchForm.Show(this);
            }
        }
    }
}
