﻿using DemoWindows.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoWindows.Forms
{
    public partial class UserForm : Form
    {
        public ActionType actionType { get; protected set; }

        public UserInfo User { get; protected set; }

        public UserForm()
        {
            actionType = ActionType.Create;
            InitializeComponent();
        }

        public UserForm(UserInfo userInfo) : this()
        {
            actionType = ActionType.Update;
            this.User = userInfo;
            tbFirstName.Text = User.FirstName;
            tbLastNAme.Text = User.LastName;
            dtpDate.Value = User.BrithDate;
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (actionType == ActionType.Create)
            User = new UserInfo();

            User.LastName = tbLastNAme.Text;
            User.FirstName = tbFirstName.Text;
            User.BrithDate = dtpDate.Value;

            DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }

    public enum ActionType
    {
        Create,
        Update
    }
}
