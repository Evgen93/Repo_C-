﻿using System;
using System.Windows.Forms;

namespace DemoWindows.Forms
{
    public partial class SearchForm : Form
    {
        public SearchForm()
        {
            InitializeComponent();
        }

        private void tbSearchText_TextChanged(object sender, EventArgs e)
        {
            MainForm mainForm = this.Owner as MainForm;
            mainForm.FindText = tbSearchText.Text;
        }

        private void SearchForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.UserClosing)
            {
                e.Cancel = true;
                Hide();
            }
        }
    }
}
