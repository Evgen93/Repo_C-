﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Windows.Forms;

namespace DemoImages
{
    public partial class MainForm : Form
    {

        private PictureBox[,] _boxes;

        Bitmap bitmap;
        public MainForm()
        {
            InitializeComponent();

            _boxes = new PictureBox[3, 3]
                {
                    { pictureBox1, pictureBox2, pictureBox3 },
                    { pictureBox4, pictureBox5, pictureBox6 },
                    { pictureBox7, pictureBox8, pictureBox9 }
                };
        }

        // todo: Filter
        private void miOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                bitmap = new Bitmap(openFileDialog.FileName);
                this.Invalidate();
            }
        }

        private void MainForm_Paint(object sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
            if (bitmap != null)
                graphics.DrawImage(bitmap, new Rectangle(50, 50, 450, 450));
        }

        private void miShuffleStart_Click(object sender, EventArgs e)
        {

            if (bitmap == null)
            {
                MessageBox.Show("Load Image");
                return; 
            }

            int widthPart = bitmap.Width / 3;
            int heigthPart = bitmap.Height / 3;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (i == 2 && j == 2)
                    {
                        continue;
                    }
                    var bitmapPart = bitmap.Clone(new Rectangle(widthPart * i, heigthPart * j, widthPart, heigthPart), PixelFormat.DontCare);
                    _boxes[j, i].Image = bitmapPart;
                }
            }

            ShufflePicture();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            var picture = (PictureBox)sender;
            int indexI = 0;
            int indexJ = 0;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (picture == _boxes[j,i])
                    {
                        indexI = i;
                        indexJ = j;
                    }
                }
            }

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (_boxes[j,i].Image == null)
                    {
                        if ((indexI == i && ((indexJ - j == -1) || (indexJ - j == 1))) || (indexJ == j && ((indexI - i == -1) || (indexI - i == 1))))
                        {
                            _boxes[j, i].Image = picture.Image;
                            picture.Image = null;
                        }
                    }
                }
            }
        }

        private void ShufflePicture()
        {
            Random rand = new Random();
            for (int a = 0; a < rand.Next(500, 1000); a++)
            {
                pictureBox1_Click(_boxes[rand.Next(0, 3), rand.Next(0, 3)], EventArgs.Empty);
            }
        }
    }
}
