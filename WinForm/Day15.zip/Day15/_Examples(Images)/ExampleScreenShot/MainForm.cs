﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExampleScreenShot
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnScreenShot_Click(object sender, EventArgs e)
        {

            //получение размеро экрана
            Rectangle screenSize = System.Windows.Forms.Screen.PrimaryScreen.Bounds;
            Size s = new Size(screenSize.Width, screenSize.Height);
 
            //создание пустого изображения.
            Bitmap screen = new Bitmap(s.Width, s.Height);
            Graphics grf = Graphics.FromImage(screen);
 
            //создание screenShot
            grf.CopyFromScreen(0, 0, 0, 0, s);
 
            //Сохранение screenshot в файл
            screen.Save("filename.jpg",System.Drawing.Imaging.ImageFormat.Jpeg);

        }
    }
}
