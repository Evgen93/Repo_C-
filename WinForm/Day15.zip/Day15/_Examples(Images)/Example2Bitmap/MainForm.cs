﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Example1Images
{
    public partial class MainForm : Form
    {
         Bitmap bmp; //объявление объекта типа Bitmap
         Rectangle rect = new Rectangle(20,20,250,200);
         Rectangle rect2 = new Rectangle(300, 20, 250, 200);
         Rectangle rect22 = new Rectangle(600, 20, 250, 200);
         Rectangle rect3 = new Rectangle(20, 300, 250, 200);
         Rectangle rect4 = new Rectangle(300, 300, 250, 200);


        Color colorMain;  // основной цвет программы
        public MainForm()
        {
            InitializeComponent();

            bmp =new Bitmap(@"Images\metrobits.jpg");

            // получение цвета из файла settings (настройки)
            colorMain = Properties.Settings.Default.ColorApp;
      
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
            graphics.DrawImage(bmp, rect);  // прорисовка картинки

            Bitmap newPicRed=(Bitmap)bmp.Clone();     // создание копии картинки

            Color pixelColor = newPicRed.GetPixel(150, 150);       // 150, 150 координаты пикселя на картинке    

            // циклами переберам все пиксели изображения (установка белой линии)
            
            for (int x = 0; x < newPicRed.Width; x++)
            {
                newPicRed.SetPixel(x, 150, colorMain);     // установка нового цвета пикселя!
            }
            graphics.DrawImage(newPicRed, rect2);             // прорисовка картинки
            newPicRed.Save("newPicRed.png");                  // сохранение картинки



            Bitmap newPicRGB = (Bitmap)bmp.Clone();          // создание копии картинки 
            for (int x = 0; x < newPicRGB.Width; x++)
            {
                for (int y = 0; y < newPicRGB.Height; y++)
                {
                    newPicRGB.SetPixel(x, y, Color.FromArgb(Color.Red.ToArgb() & newPicRGB.GetPixel(x, y).ToArgb()));     // установка 
                }
            }
            graphics.DrawImage(newPicRGB, rect22);                     // прорисовка картинки


            Bitmap newPicAdd = (Bitmap)bmp.Clone();                    // создание копии картинки
            Graphics newGraf = Graphics.FromImage(newPicAdd);          // получение Graphics из картинки
            newGraf.DrawEllipse(new Pen(Color.Red,10), 50,50,150,150); // прорисовка элипса на картинке
            newPicAdd.Save("newPicAdd.png");                           // сохранение картинки с нарисованных элипсом
            graphics.DrawImage(newPicAdd, rect3);                      // прорисовка картинки



            // получение части (по прямойгольнику) из основной картинки с учетом  PixelFormat
            Bitmap newPicPart = (Bitmap)bmp.Clone(new Rectangle(0,0,100,100), PixelFormat.DontCare);
            newPicPart.Save("newPicPart.png");                  // сохранение части картинки 
            graphics.DrawImage(newPicPart, rect4);              // прорисовка картинки



        }

      
        
    }
}
