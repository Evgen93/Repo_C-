﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Examples
{
    public partial class MainForm : Form
    {
        private Image picture;

        Rectangle rect = new Rectangle(20,20,250,200);
        Rectangle rectNew = new Rectangle(300, 20, 250, 200);

        public MainForm()
        {
            InitializeComponent();

            // Загрузка изображения
            picture = Image.FromFile(@"Images\metrobits.jpg");
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
           
            // прорисовка картинки
            graphics.DrawImage(picture, rect);

                     
            
            // Получение разрешения картинки и ее размеров
            this.Text=String.Format("W={0} H={1} rH={2} rV={3}",
                           picture.Width, 
                           picture.Height, 
                           picture.HorizontalResolution, 
                           picture.VerticalResolution);

            //Копирование изображения
            Image newPicture = (Image)picture.Clone();

            // Вращение картинки (RotateFlipType - перечесление)
            // вращение на 270 градусов относительно X
            newPicture.RotateFlip(RotateFlipType.Rotate180FlipX);  
            graphics.DrawImage(newPicture, rectNew);

            
            //Сохраняет объект Image в  указанный файл или поток.
            picture.Save("NewPic.tiff");
            picture.Save("NewPic.png", ImageFormat.Png);
        }
    }
}
