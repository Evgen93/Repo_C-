﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DemoBackGroundWorker
{
    public partial class MainForm : Form
    {
        BackgroundWorker backWorker;

        public MainForm()
        {
            InitializeComponent();
            backWorker = new BackgroundWorker();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            backWorker.DoWork += BackWorker_DoWork;
            backWorker.RunWorkerCompleted += BackWorker_RunWorkerCompleted;
            backWorker.ProgressChanged += BackWorker_ProgressChanged;
            backWorker.WorkerReportsProgress = true;
            backWorker.WorkerSupportsCancellation = true;
            backWorker.RunWorkerAsync(argument:6);
        }

        private void BackWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            lbInfo.Text = string.Format("{0} second",e.ProgressPercentage.ToString());
            pbProgres.Value = (int)(e.ProgressPercentage / 5.0 * 100.0);
        }

        private void BackWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                lbInfo.Text = "Canceled =(";
            }
            else
            {
                lbInfo.Text = $"Sucsses! - {e.Result.ToString()}";
            }
        }

        private void BackWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            int sum = 0;
            int count = (int)e.Argument;
            var backWorker = (BackgroundWorker)sender;
            for (int i = 1; i < count; i++)
            {
                if (backWorker.CancellationPending)
                {
                    backWorker.ReportProgress(0);
                    e.Cancel = true;
                    break;
                }

                backWorker.ReportProgress(i);
                Thread.Sleep(1000);
                sum += i;
            }
            e.Result = sum;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            backWorker.CancelAsync();
        }
    }
}
