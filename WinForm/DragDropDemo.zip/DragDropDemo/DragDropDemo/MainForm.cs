﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DragDropDemo
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            pbPhoto.AllowDrop = true;
            lstDestination.AllowDrop = true;
        }

        private void pbPhoto_DragDrop(object sender, DragEventArgs e)
        {
            var filesPath = (string[])e.Data.GetData(DataFormats.FileDrop);
            pbPhoto.ImageLocation = filesPath.Length != 0 ? filesPath[0] : string.Empty;
        }

        private void pbPhoto_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void pbPhoto_DragLeave(object sender, EventArgs e)
        {
            pbPhoto.Image = Properties.Resources.images;
        }

        private void lstDestination_DragDrop(object sender, DragEventArgs e)
        {
            var text = (string)e.Data.GetData(DataFormats.Text);
            lstDestination.Items.Add(text);
        }

        private void lstDestination_DragOver(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void lstSource_MouseDown(object sender, MouseEventArgs e)
        {
            if (lstSource.SelectedItem != null)
            {
                var text = lstSource.SelectedItem.ToString();
                lstSource.DoDragDrop(text, DragDropEffects.Copy);
            }
        }
    }
}
