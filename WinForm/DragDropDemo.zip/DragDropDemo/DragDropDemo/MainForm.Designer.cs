﻿namespace DragDropDemo
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbPhoto = new System.Windows.Forms.PictureBox();
            this.lstSource = new System.Windows.Forms.ListBox();
            this.lstDestination = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbPhoto)).BeginInit();
            this.SuspendLayout();
            // 
            // pbPhoto
            // 
            this.pbPhoto.Image = global::DragDropDemo.Properties.Resources.images;
            this.pbPhoto.Location = new System.Drawing.Point(12, 13);
            this.pbPhoto.Name = "pbPhoto";
            this.pbPhoto.Size = new System.Drawing.Size(374, 453);
            this.pbPhoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPhoto.TabIndex = 0;
            this.pbPhoto.TabStop = false;
            this.pbPhoto.DragDrop += new System.Windows.Forms.DragEventHandler(this.pbPhoto_DragDrop);
            this.pbPhoto.DragEnter += new System.Windows.Forms.DragEventHandler(this.pbPhoto_DragDrop);
            this.pbPhoto.DragOver += new System.Windows.Forms.DragEventHandler(this.pbPhoto_DragOver);
            this.pbPhoto.DragLeave += new System.EventHandler(this.pbPhoto_DragLeave);
            // 
            // lstSource
            // 
            this.lstSource.FormattingEnabled = true;
            this.lstSource.Items.AddRange(new object[] {
            "C#",
            "WinForm",
            "WPF",
            "WCF",
            "ASP.NET",
            "ADO.NET"});
            this.lstSource.Location = new System.Drawing.Point(420, 13);
            this.lstSource.Name = "lstSource";
            this.lstSource.Size = new System.Drawing.Size(360, 212);
            this.lstSource.TabIndex = 1;
            this.lstSource.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lstSource_MouseDown);
            // 
            // lstDestination
            // 
            this.lstDestination.FormattingEnabled = true;
            this.lstDestination.Location = new System.Drawing.Point(420, 241);
            this.lstDestination.Name = "lstDestination";
            this.lstDestination.Size = new System.Drawing.Size(360, 225);
            this.lstDestination.TabIndex = 2;
            this.lstDestination.DragDrop += new System.Windows.Forms.DragEventHandler(this.lstDestination_DragDrop);
            this.lstDestination.DragOver += new System.Windows.Forms.DragEventHandler(this.lstDestination_DragOver);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 487);
            this.Controls.Add(this.lstDestination);
            this.Controls.Add(this.lstSource);
            this.Controls.Add(this.pbPhoto);
            this.Name = "MainForm";
            this.Text = "Drag&Drop";
            ((System.ComponentModel.ISupportInitialize)(this.pbPhoto)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbPhoto;
        private System.Windows.Forms.ListBox lstSource;
        private System.Windows.Forms.ListBox lstDestination;
    }
}

