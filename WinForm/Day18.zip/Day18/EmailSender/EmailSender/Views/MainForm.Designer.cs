﻿namespace EmailSender
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Близкие родственники");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Остальные родственники");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Родственники", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2});
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Коллеги по отделу");
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Остальные коллеги");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Коллеги", new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Лучшие друзья");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Просто друзья");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Друзья", new System.Windows.Forms.TreeNode[] {
            treeNode7,
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Получатели", new System.Windows.Forms.TreeNode[] {
            treeNode3,
            treeNode6,
            treeNode9});
            this.mnuAdd = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmAdd = new System.Windows.Forms.ToolStripMenuItem();
            this.trwRecipients = new System.Windows.Forms.TreeView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.mnuAdd.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuAdd
            // 
            this.mnuAdd.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmAdd});
            this.mnuAdd.Name = "mnuAdd";
            this.mnuAdd.Size = new System.Drawing.Size(153, 48);
            // 
            // tsmAdd
            // 
            this.tsmAdd.Name = "tsmAdd";
            this.tsmAdd.Size = new System.Drawing.Size(152, 22);
            this.tsmAdd.Text = "добавить";
            this.tsmAdd.Click += new System.EventHandler(this.tsmAdd_Click);
            // 
            // trwRecipients
            // 
            this.trwRecipients.Location = new System.Drawing.Point(12, 25);
            this.trwRecipients.Name = "trwRecipients";
            treeNode1.ContextMenuStrip = this.mnuAdd;
            treeNode1.Name = "nodeCloseRelatives";
            treeNode1.Text = "Близкие родственники";
            treeNode2.ContextMenuStrip = this.mnuAdd;
            treeNode2.Name = "nodeOtherRelatives";
            treeNode2.Text = "Остальные родственники";
            treeNode3.Name = "nodeRelatives";
            treeNode3.Text = "Родственники";
            treeNode4.ContextMenuStrip = this.mnuAdd;
            treeNode4.Name = "Node6";
            treeNode4.Text = "Коллеги по отделу";
            treeNode5.ContextMenuStrip = this.mnuAdd;
            treeNode5.Name = "nodeOtherColleagues";
            treeNode5.Text = "Остальные коллеги";
            treeNode6.Name = "nodeColleagues";
            treeNode6.Text = "Коллеги";
            treeNode7.ContextMenuStrip = this.mnuAdd;
            treeNode7.Name = "nodeBestFriends";
            treeNode7.Text = "Лучшие друзья";
            treeNode8.ContextMenuStrip = this.mnuAdd;
            treeNode8.Name = "nodeOtherFriends";
            treeNode8.Text = "Просто друзья";
            treeNode9.Name = "nodeFriends";
            treeNode9.Text = "Друзья";
            treeNode10.Name = "nodeRecipients";
            treeNode10.Text = "Получатели";
            this.trwRecipients.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode10});
            this.trwRecipients.Size = new System.Drawing.Size(310, 638);
            this.trwRecipients.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(329, 25);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(598, 638);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(590, 612);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(590, 612);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(929, 675);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.trwRecipients);
            this.Name = "MainForm";
            this.Text = "Рассылка Сообщений";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.mnuAdd.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView trwRecipients;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ContextMenuStrip mnuAdd;
        private System.Windows.Forms.ToolStripMenuItem tsmAdd;
    }
}

