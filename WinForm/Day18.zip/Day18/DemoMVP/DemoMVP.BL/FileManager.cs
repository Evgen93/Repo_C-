﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoMVP.BL
{
	public class FileManager : IFileManager
	{
		public string GetFileContent(string filePath, Encoding encoding)
		{
			if (String.IsNullOrWhiteSpace(filePath))
				throw new ArgumentNullException($"filePath path is null");

			string content = File.ReadAllText(filePath, encoding);
			return content;
		}

		public string GetFileContent(string filePath)
		{
			return GetFileContent(filePath, Encoding.Default);
		}

		public void SaveFileContent(string filePath, string content, Encoding encoding)
		{
			if (String.IsNullOrWhiteSpace(filePath))
				throw new ArgumentNullException($"filePath path is null");

			if (String.IsNullOrWhiteSpace(content))
				throw new ArgumentNullException($"filePath path is null");

			File.WriteAllText(filePath, content, encoding);
		}

		public void SaveFileContent(string filePath, string content)
		{
			SaveFileContent(filePath, content, Encoding.Default);
		}

		public bool IsFileExist(string filePath)
		{
			return File.Exists(filePath);
		}

		public int GetSymbolCount(string content)
		{
			return content.Length;
		}
	}
}
