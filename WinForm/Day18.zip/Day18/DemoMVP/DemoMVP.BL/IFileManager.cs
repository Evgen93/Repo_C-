﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoMVP.BL
{
	public interface IFileManager
	{
		string GetFileContent(string filePath, Encoding encoding);
		string GetFileContent(string filePath);
		void SaveFileContent(string filePath, string content, Encoding encoding);
		void SaveFileContent(string filePath, string content);
		bool IsFileExist(string filePath);
		int GetSymbolCount(string content);
	}
}
