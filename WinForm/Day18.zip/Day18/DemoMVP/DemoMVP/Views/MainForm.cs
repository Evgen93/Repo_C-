﻿using System;
using System.Windows.Forms;

namespace DemoMVP.Views
{
	public partial class MainForm : Form, IMainForm
	{
		public event EventHandler FileOpenClick;
		public event EventHandler FileSaveClick;
		public event EventHandler ContentChanged;

		public string FilePath
		{
			get
			{
				return tbFilePath.Text;
			}
		}

		public string Content
		{
			get { return tbContent.Text; }
			set { tbContent.Text = value; }
		}
		
		public MainForm()
		{
			InitializeComponent();
			btnOpen.Click += BtnOpen_Click;
			btnSave.Click += BtnSave_Click;
			tbContent.TextChanged += TbContent_TextChanged;
		}

		public void SetSymbolCount(int count)
		{
			lbCountSymbols.Text = count.ToString();
		}

		#region Events

		private void TbContent_TextChanged(object sender, EventArgs e)
		{
			ContentChanged?.Invoke(this, EventArgs.Empty);
		}

		private void BtnSave_Click(object sender, EventArgs e)
		{
			FileOpenClick?.Invoke(this, EventArgs.Empty);
		}

		private void BtnOpen_Click(object sender, EventArgs e)
		{
			FileSaveClick?.Invoke(this, EventArgs.Empty);
		}
		
		#endregion

		private void btnSelect_Click(object sender, EventArgs e)
		{
			var openFileDialog = new OpenFileDialog();
			if (openFileDialog.ShowDialog() == DialogResult.OK)
			{
				tbFilePath.Text = openFileDialog.FileName;
				FileOpenClick?.Invoke(this, EventArgs.Empty);
			}
		}
	}
}
