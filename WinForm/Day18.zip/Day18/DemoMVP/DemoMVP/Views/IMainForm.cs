﻿using System;

namespace DemoMVP.Views
{
	public interface IMainForm
	{
		string FilePath { get; }
		string Content { get; set; }
		void SetSymbolCount(int count);
		event EventHandler FileOpenClick;
		event EventHandler FileSaveClick;
		event EventHandler ContentChanged;
	}
}