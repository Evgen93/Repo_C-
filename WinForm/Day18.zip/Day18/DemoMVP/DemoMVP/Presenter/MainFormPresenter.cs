﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoMVP.BL;
using DemoMVP.Services;
using DemoMVP.Views;

namespace DemoMVP.Presenter
{
	public class MainFormPresenter
	{
		private readonly IMainForm _view;
		private readonly IMessageService _messageService;
		private readonly IFileManager _fileManager;

		public MainFormPresenter(IMainForm view, IFileManager fileManager, IMessageService messageService)
		{
			_view = view;
			_fileManager = fileManager;
			_messageService = messageService;

			_view.SetSymbolCount(0);

			_view.ContentChanged += _view_ContentChanged;
			_view.FileOpenClick += _view_FileOpenClick;
			_view.FileSaveClick += _view_FileSaveClick;
		}

		private void _view_FileSaveClick(object sender, EventArgs e)
		{
			try
			{
				string content = _view.Content;
				string filePath = _view.FilePath;
				if (_fileManager.IsFileExist(filePath))
				{
					_fileManager.SaveFileContent(filePath, content);
				}
				else
				{
					_messageService.ShowMessage("File not exist");
				}

			}
			catch (Exception ex)
			{
				_messageService.ShowMessage(ex.Message);
			}

		}

		private void _view_FileOpenClick(object sender, EventArgs e)
		{
			try
			{
				string filePath = _view.FilePath;

				if (_fileManager.IsFileExist(filePath))
				{
					string content = _fileManager.GetFileContent(filePath);
					int count = _fileManager.GetSymbolCount(content);

					_view.Content = content;
					_view.SetSymbolCount(count);
				}
				else
				{
					_messageService.ShowMessage("File not exist");
				}
			}
			catch (Exception ex)
			{
				_messageService.ShowMessage(ex.Message);
			}



		}

		private void _view_ContentChanged(object sender, EventArgs e)
		{
			string content = _view.Content;
			int count = _fileManager.GetSymbolCount(content);
			_view.SetSymbolCount(count);
		}
	}
}
