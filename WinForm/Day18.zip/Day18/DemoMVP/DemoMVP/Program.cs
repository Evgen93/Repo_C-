﻿using System;
using System.Windows.Forms;
using DemoMVP.BL;
using DemoMVP.Presenter;
using DemoMVP.Services;
using DemoMVP.Views;

namespace DemoMVP
{
	static class Program
	{

		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			MainForm mainForm =new MainForm();
			IFileManager fileManager = new FileManager();
			IMessageService messageService = new MessageService();

			MainFormPresenter mainFormPresenter = new MainFormPresenter(mainForm, fileManager, messageService);

			Application.Run(mainForm);
		}
	}
}
