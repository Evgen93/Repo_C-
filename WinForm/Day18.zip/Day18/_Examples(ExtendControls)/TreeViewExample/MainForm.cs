﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TreeViewExample
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            trvMain.CollapseAll();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            trvMain.ExpandAll();
        }

        private void AddNode_Click(object sender, EventArgs e)
        {
            trvMain.SelectedNode.Nodes.Add("Новый узел");
        }

        private void DelNode_Click(object sender, EventArgs e)
        {
            if (trvMain.SelectedNode!=null)
                trvMain.Nodes.Remove(trvMain.SelectedNode);
        }


        string selNames;
        private void trvMain_AfterSelect(object sender, TreeViewEventArgs e)
        {
            tbContent.Text = selNames = String.Empty;
            GetAllNames(trvMain.SelectedNode);
            tbContent.Text = selNames;

        }


        string GetAllNames(TreeNode selTN)
        {
            
            for (int i = 0; i < selTN.Nodes.Count; i++)
            {
                GetAllNames(selTN.Nodes[i]);
                if (selTN.Nodes[i].Level >= 0)
                {
                    selNames += selTN.Nodes[i].Text + ";"+Environment.NewLine;
                }
            }
            return selNames;
        }

    }
}
