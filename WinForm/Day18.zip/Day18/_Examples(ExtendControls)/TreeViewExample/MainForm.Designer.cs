﻿namespace TreeViewExample
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("С++");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("С#");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Java");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Разработка ПО", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3});
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Cisco");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Администрирование сетей", new System.Windows.Forms.TreeNode[] {
            treeNode5});
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("PhotoShop");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("CorelDraw");
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Дизайн", new System.Windows.Forms.TreeNode[] {
            treeNode7,
            treeNode8});
            System.Windows.Forms.TreeNode treeNode10 = new System.Windows.Forms.TreeNode("Направления", 4, 4, new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode6,
            treeNode9});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.trvMain = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.AddNode = new System.Windows.Forms.Button();
            this.DelNode = new System.Windows.Forms.Button();
            this.tbContent = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // trvMain
            // 
            this.trvMain.BackColor = System.Drawing.Color.White;
            this.trvMain.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.trvMain.HotTracking = true;
            this.trvMain.ImageIndex = 0;
            this.trvMain.ImageList = this.imageList1;
            this.trvMain.Location = new System.Drawing.Point(12, 42);
            this.trvMain.Name = "trvMain";
            treeNode1.ImageIndex = 2;
            treeNode1.Name = "Cplus";
            treeNode1.Text = "С++";
            treeNode2.ImageIndex = 2;
            treeNode2.Name = "CSharp";
            treeNode2.Text = "С#";
            treeNode3.ImageIndex = 2;
            treeNode3.Name = "Java";
            treeNode3.Text = "Java";
            treeNode4.ImageIndex = 2;
            treeNode4.Name = "Programming";
            treeNode4.Text = "Разработка ПО";
            treeNode5.Name = "Cisco";
            treeNode5.Text = "Cisco";
            treeNode6.Name = "Administation";
            treeNode6.Text = "Администрирование сетей";
            treeNode7.ImageIndex = 1;
            treeNode7.Name = "PhotoShop";
            treeNode7.Text = "PhotoShop";
            treeNode8.ImageIndex = 1;
            treeNode8.Name = "CorelDraw";
            treeNode8.Text = "CorelDraw";
            treeNode9.ImageIndex = 1;
            treeNode9.Name = "Design";
            treeNode9.Text = "Дизайн";
            treeNode10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            treeNode10.ImageIndex = 4;
            treeNode10.Name = "Root";
            treeNode10.NodeFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            treeNode10.SelectedImageIndex = 4;
            treeNode10.Text = "Направления";
            this.trvMain.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode10});
            this.trvMain.SelectedImageIndex = 3;
            this.trvMain.ShowRootLines = false;
            this.trvMain.Size = new System.Drawing.Size(361, 359);
            this.trvMain.TabIndex = 0;
            this.trvMain.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.trvMain_AfterSelect);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "admin.png");
            this.imageList1.Images.SetKeyName(1, "des.png");
            this.imageList1.Images.SetKeyName(2, "dev.png");
            this.imageList1.Images.SetKeyName(3, "nouser.png");
            this.imageList1.Images.SetKeyName(4, "ubuntu-logo.png");
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.linkLabel1.Location = new System.Drawing.Point(187, 12);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(79, 16);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Свернуть";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.linkLabel2.Location = new System.Drawing.Point(276, 12);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(97, 16);
            this.linkLabel2.TabIndex = 1;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "Развернуть";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // AddNode
            // 
            this.AddNode.Location = new System.Drawing.Point(379, 42);
            this.AddNode.Name = "AddNode";
            this.AddNode.Size = new System.Drawing.Size(106, 33);
            this.AddNode.TabIndex = 2;
            this.AddNode.Text = "Добавить узел";
            this.AddNode.UseVisualStyleBackColor = true;
            this.AddNode.Click += new System.EventHandler(this.AddNode_Click);
            // 
            // DelNode
            // 
            this.DelNode.Location = new System.Drawing.Point(379, 81);
            this.DelNode.Name = "DelNode";
            this.DelNode.Size = new System.Drawing.Size(106, 33);
            this.DelNode.TabIndex = 2;
            this.DelNode.Text = "Удалить узел";
            this.DelNode.UseVisualStyleBackColor = true;
            this.DelNode.Click += new System.EventHandler(this.DelNode_Click);
            // 
            // tbContent
            // 
            this.tbContent.Location = new System.Drawing.Point(379, 210);
            this.tbContent.Multiline = true;
            this.tbContent.Name = "tbContent";
            this.tbContent.Size = new System.Drawing.Size(289, 191);
            this.tbContent.TabIndex = 3;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 413);
            this.Controls.Add(this.tbContent);
            this.Controls.Add(this.DelNode);
            this.Controls.Add(this.AddNode);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.trvMain);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView trvMain;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Button AddNode;
        private System.Windows.Forms.Button DelNode;
        private System.Windows.Forms.TextBox tbContent;
    }
}

