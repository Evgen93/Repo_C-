﻿namespace onDay10
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.contextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.CopyText = new System.Windows.Forms.ToolStripMenuItem();
            this.CutText = new System.Windows.Forms.ToolStripMenuItem();
            this.PasteText = new System.Windows.Forms.ToolStripMenuItem();
            this.opFile = new System.Windows.Forms.OpenFileDialog();
            this.sFile = new System.Windows.Forms.SaveFileDialog();
            this.fontDialog = new System.Windows.Forms.FontDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.открытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сохранитьКакToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.закрытьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.правкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отменаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.настройкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выборЦветаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.текстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.фонаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выборШрифтаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.внешнийВидToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.плавающийToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.руководствоПользователяToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnClear = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.Redo = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.tsFind = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.Left = new System.Windows.Forms.ToolStripButton();
            this.Center = new System.Windows.Forms.ToolStripButton();
            this.Right = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.tsList = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.btnCopy = new System.Windows.Forms.ToolStripButton();
            this.btnCut = new System.Windows.Forms.ToolStripButton();
            this.btnPaste = new System.Windows.Forms.ToolStripButton();
            this.sepEdit = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSplitButton1 = new System.Windows.Forms.ToolStripSplitButton();
            this.текстаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.фонаТекстаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.фонаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripSplitButton();
            this.плавающийToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.contextMenuCommon = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.оПрограммеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tbMain = new System.Windows.Forms.RichTextBox();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.stText = new System.Windows.Forms.ToolStripStatusLabel();
            this.contextMenu.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.contextMenuCommon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // contextMenu
            // 
            this.contextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CopyText,
            this.CutText,
            this.PasteText});
            this.contextMenu.Name = "contextMenu";
            this.contextMenu.Size = new System.Drawing.Size(140, 70);
            // 
            // CopyText
            // 
            this.CopyText.Image = global::onDay10.Properties.Resources._16_Copy_24x24;
            this.CopyText.Name = "CopyText";
            this.CopyText.Size = new System.Drawing.Size(152, 22);
            this.CopyText.Text = "Копировать";
            this.CopyText.Click += new System.EventHandler(this.CopyText_Click);
            // 
            // CutText
            // 
            this.CutText.Image = global::onDay10.Properties.Resources.Scissors;
            this.CutText.Name = "CutText";
            this.CutText.Size = new System.Drawing.Size(152, 22);
            this.CutText.Text = "Вырезать";
            this.CutText.Click += new System.EventHandler(this.CutText_Click);
            // 
            // PasteText
            // 
            this.PasteText.Image = global::onDay10.Properties.Resources.edit_paste;
            this.PasteText.Name = "PasteText";
            this.PasteText.Size = new System.Drawing.Size(152, 22);
            this.PasteText.Text = "Вставить";
            this.PasteText.Click += new System.EventHandler(this.PasteText_Click);
            // 
            // opFile
            // 
            this.opFile.Filter = "Rtf(*.rtf)|*.rtf|Txt(*.txt)|*.txt";
            // 
            // sFile
            // 
            this.sFile.FileName = "newText";
            this.sFile.Filter = "Rtf(*.rtf)|*.rtf|Txt(*.txt)|*.txt";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.правкаToolStripMenuItem,
            this.настройкаToolStripMenuItem,
            this.справкаToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(641, 24);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.открытьToolStripMenuItem,
            this.сохранитьКакToolStripMenuItem1,
            this.toolStripSeparator1,
            this.закрытьToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(48, 20);
            this.файлToolStripMenuItem.Text = "&Файл";
            // 
            // открытьToolStripMenuItem
            // 
            this.открытьToolStripMenuItem.AutoToolTip = true;
            this.открытьToolStripMenuItem.ForeColor = System.Drawing.Color.Black;
            this.открытьToolStripMenuItem.Image = global::onDay10.Properties.Resources.open_file;
            this.открытьToolStripMenuItem.Name = "открытьToolStripMenuItem";
            this.открытьToolStripMenuItem.Overflow = System.Windows.Forms.ToolStripItemOverflow.Always;
            this.открытьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.открытьToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.открытьToolStripMenuItem.Text = "Открыть";
            this.открытьToolStripMenuItem.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            this.открытьToolStripMenuItem.Click += new System.EventHandler(this.Open_Click);
            // 
            // сохранитьКакToolStripMenuItem1
            // 
            this.сохранитьКакToolStripMenuItem1.AutoToolTip = true;
            this.сохранитьКакToolStripMenuItem1.Image = global::onDay10.Properties.Resources.Save32;
            this.сохранитьКакToolStripMenuItem1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.сохранитьКакToolStripMenuItem1.Name = "сохранитьКакToolStripMenuItem1";
            this.сохранитьКакToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.сохранитьКакToolStripMenuItem1.Size = new System.Drawing.Size(193, 22);
            this.сохранитьКакToolStripMenuItem1.Text = "Сохранить как";
            this.сохранитьКакToolStripMenuItem1.Click += new System.EventHandler(this.Save_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(190, 6);
            // 
            // закрытьToolStripMenuItem
            // 
            this.закрытьToolStripMenuItem.AutoToolTip = true;
            this.закрытьToolStripMenuItem.Image = global::onDay10.Properties.Resources.Log_Out;
            this.закрытьToolStripMenuItem.Name = "закрытьToolStripMenuItem";
            this.закрытьToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.закрытьToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.закрытьToolStripMenuItem.Text = "Закрыть";
            this.закрытьToolStripMenuItem.Click += new System.EventHandler(this.закрытьToolStripMenuItem_Click);
            // 
            // правкаToolStripMenuItem
            // 
            this.правкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отменаToolStripMenuItem});
            this.правкаToolStripMenuItem.Name = "правкаToolStripMenuItem";
            this.правкаToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.правкаToolStripMenuItem.Text = "&Правка";
            // 
            // отменаToolStripMenuItem
            // 
            this.отменаToolStripMenuItem.Image = global::onDay10.Properties.Resources.Undo32;
            this.отменаToolStripMenuItem.Name = "отменаToolStripMenuItem";
            this.отменаToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.отменаToolStripMenuItem.Text = "Отмена";
            this.отменаToolStripMenuItem.Click += new System.EventHandler(this.Undo_Click_1);
            // 
            // настройкаToolStripMenuItem
            // 
            this.настройкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выборЦветаToolStripMenuItem,
            this.выборШрифтаToolStripMenuItem,
            this.внешнийВидToolStripMenuItem});
            this.настройкаToolStripMenuItem.Name = "настройкаToolStripMenuItem";
            this.настройкаToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.настройкаToolStripMenuItem.Text = "Настройка";
            // 
            // выборЦветаToolStripMenuItem
            // 
            this.выборЦветаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.текстаToolStripMenuItem,
            this.фонаToolStripMenuItem});
            this.выборЦветаToolStripMenuItem.Image = global::onDay10.Properties.Resources.gnome_color_browser;
            this.выборЦветаToolStripMenuItem.Name = "выборЦветаToolStripMenuItem";
            this.выборЦветаToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.выборЦветаToolStripMenuItem.Text = "Выбор цвета";
            // 
            // текстаToolStripMenuItem
            // 
            this.текстаToolStripMenuItem.Name = "текстаToolStripMenuItem";
            this.текстаToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.текстаToolStripMenuItem.Text = "Текста";
            this.текстаToolStripMenuItem.Click += new System.EventHandler(this.ColorFont_Click);
            // 
            // фонаToolStripMenuItem
            // 
            this.фонаToolStripMenuItem.Name = "фонаToolStripMenuItem";
            this.фонаToolStripMenuItem.Size = new System.Drawing.Size(110, 22);
            this.фонаToolStripMenuItem.Text = "Фона";
            this.фонаToolStripMenuItem.Click += new System.EventHandler(this.ColorBack_Click);
            // 
            // выборШрифтаToolStripMenuItem
            // 
            this.выборШрифтаToolStripMenuItem.Image = global::onDay10.Properties.Resources.applixware;
            this.выборШрифтаToolStripMenuItem.Name = "выборШрифтаToolStripMenuItem";
            this.выборШрифтаToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.выборШрифтаToolStripMenuItem.Text = "Выбор шрифта";
            this.выборШрифтаToolStripMenuItem.Click += new System.EventHandler(this.Font_Click);
            // 
            // внешнийВидToolStripMenuItem
            // 
            this.внешнийВидToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.плавающийToolStripMenuItem});
            this.внешнийВидToolStripMenuItem.Image = global::onDay10.Properties.Resources.application_form_delete;
            this.внешнийВидToolStripMenuItem.Name = "внешнийВидToolStripMenuItem";
            this.внешнийВидToolStripMenuItem.Size = new System.Drawing.Size(159, 22);
            this.внешнийВидToolStripMenuItem.Text = "Внешний вид";
            // 
            // плавающийToolStripMenuItem
            // 
            this.плавающийToolStripMenuItem.Checked = true;
            this.плавающийToolStripMenuItem.CheckOnClick = true;
            this.плавающийToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.плавающийToolStripMenuItem.Name = "плавающийToolStripMenuItem";
            this.плавающийToolStripMenuItem.Size = new System.Drawing.Size(143, 22);
            this.плавающийToolStripMenuItem.Text = "Плавающий";
            this.плавающийToolStripMenuItem.Click += new System.EventHandler(this.фиксированныйToolStripMenuItem_Click);
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem,
            this.руководствоПользователяToolStripMenuItem});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = global::onDay10.Properties.Resources.Info;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            // 
            // руководствоПользователяToolStripMenuItem
            // 
            this.руководствоПользователяToolStripMenuItem.Name = "руководствоПользователяToolStripMenuItem";
            this.руководствоПользователяToolStripMenuItem.Size = new System.Drawing.Size(221, 22);
            this.руководствоПользователяToolStripMenuItem.Text = "Руководство пользователя";
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnClear,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripSeparator2,
            this.toolStripButton3,
            this.Redo,
            this.toolStripSeparator3,
            this.toolStripLabel1,
            this.tsFind,
            this.toolStripSeparator5,
            this.Left,
            this.Center,
            this.Right,
            this.toolStripSeparator4,
            this.tsList,
            this.toolStripSeparator6,
            this.btnCopy,
            this.btnCut,
            this.btnPaste,
            this.sepEdit,
            this.toolStripSplitButton1,
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripSeparator8,
            this.toolStripButton6,
            this.toolStripSeparator7});
            this.toolStrip1.Location = new System.Drawing.Point(0, 24);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(641, 31);
            this.toolStrip1.TabIndex = 13;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // btnClear
            // 
            this.btnClear.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnClear.Image = global::onDay10.Properties.Resources.unknown;
            this.btnClear.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(23, 28);
            this.btnClear.Text = "toolStripButton7";
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::onDay10.Properties.Resources.open_file32;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 28);
            this.toolStripButton1.Text = "Открыть файл";
            this.toolStripButton1.Click += new System.EventHandler(this.Open_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::onDay10.Properties.Resources.Save32;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(23, 28);
            this.toolStripButton2.Text = "Сохранить файл";
            this.toolStripButton2.Click += new System.EventHandler(this.Save_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = global::onDay10.Properties.Resources.Undo32;
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(23, 28);
            this.toolStripButton3.Text = "Отменить действие";
            this.toolStripButton3.Click += new System.EventHandler(this.Undo_Click_1);
            // 
            // Redo
            // 
            this.Redo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Redo.Image = global::onDay10.Properties.Resources.Redo;
            this.Redo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Redo.Name = "Redo";
            this.Redo.Size = new System.Drawing.Size(23, 28);
            this.Redo.Text = "Возвратить действие";
            this.Redo.Click += new System.EventHandler(this.Redo_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(0, 28);
            // 
            // tsFind
            // 
            this.tsFind.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsFind.Image = global::onDay10.Properties.Resources.Search;
            this.tsFind.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsFind.Name = "tsFind";
            this.tsFind.Size = new System.Drawing.Size(23, 28);
            this.tsFind.Text = "Поиск текста";
            this.tsFind.Click += new System.EventHandler(this.tsFind_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 31);
            // 
            // Left
            // 
            this.Left.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Left.Image = global::onDay10.Properties.Resources.text_align_left_24;
            this.Left.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Left.Name = "Left";
            this.Left.Size = new System.Drawing.Size(23, 28);
            this.Left.Text = "toolStripButton7";
            this.Left.Click += new System.EventHandler(this.Left_Click);
            // 
            // Center
            // 
            this.Center.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Center.Image = global::onDay10.Properties.Resources.text_align_center_24;
            this.Center.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Center.Name = "Center";
            this.Center.Size = new System.Drawing.Size(23, 28);
            this.Center.Text = "toolStripButton7";
            this.Center.Click += new System.EventHandler(this.Center_Click);
            // 
            // Right
            // 
            this.Right.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Right.Image = global::onDay10.Properties.Resources.text_align_right_24;
            this.Right.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Right.Name = "Right";
            this.Right.Size = new System.Drawing.Size(23, 28);
            this.Right.Text = "toolStripButton8";
            this.Right.Click += new System.EventHandler(this.Right_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 31);
            // 
            // tsList
            // 
            this.tsList.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsList.Image = global::onDay10.Properties.Resources.ic_format_list_bulleted_48px_24;
            this.tsList.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsList.Name = "tsList";
            this.tsList.Size = new System.Drawing.Size(23, 28);
            this.tsList.Text = "toolStripButton7";
            this.tsList.Click += new System.EventHandler(this.tsList_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 31);
            // 
            // btnCopy
            // 
            this.btnCopy.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCopy.Image = global::onDay10.Properties.Resources._16_Copy_24x24;
            this.btnCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCopy.Name = "btnCopy";
            this.btnCopy.Size = new System.Drawing.Size(23, 28);
            this.btnCopy.Text = "Копировать текст";
            this.btnCopy.Visible = false;
            this.btnCopy.Click += new System.EventHandler(this.CopyText_Click);
            // 
            // btnCut
            // 
            this.btnCut.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnCut.Image = global::onDay10.Properties.Resources.Scissors;
            this.btnCut.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnCut.Name = "btnCut";
            this.btnCut.Size = new System.Drawing.Size(23, 28);
            this.btnCut.Text = "Вырезать текст";
            this.btnCut.Visible = false;
            this.btnCut.Click += new System.EventHandler(this.CutText_Click);
            // 
            // btnPaste
            // 
            this.btnPaste.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnPaste.Image = global::onDay10.Properties.Resources.edit_paste;
            this.btnPaste.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnPaste.Name = "btnPaste";
            this.btnPaste.Size = new System.Drawing.Size(23, 28);
            this.btnPaste.Text = "Вставить текст";
            this.btnPaste.Visible = false;
            this.btnPaste.Click += new System.EventHandler(this.PasteText_Click);
            // 
            // sepEdit
            // 
            this.sepEdit.Name = "sepEdit";
            this.sepEdit.Size = new System.Drawing.Size(6, 31);
            this.sepEdit.Visible = false;
            // 
            // toolStripSplitButton1
            // 
            this.toolStripSplitButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripSplitButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.текстаToolStripMenuItem1,
            this.фонаТекстаToolStripMenuItem,
            this.фонаToolStripMenuItem1});
            this.toolStripSplitButton1.Image = global::onDay10.Properties.Resources.gnome_color_browser32;
            this.toolStripSplitButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripSplitButton1.Name = "toolStripSplitButton1";
            this.toolStripSplitButton1.Size = new System.Drawing.Size(32, 28);
            this.toolStripSplitButton1.Text = "Выбор цвета";
            // 
            // текстаToolStripMenuItem1
            // 
            this.текстаToolStripMenuItem1.Name = "текстаToolStripMenuItem1";
            this.текстаToolStripMenuItem1.Size = new System.Drawing.Size(140, 22);
            this.текстаToolStripMenuItem1.Text = "Текста";
            this.текстаToolStripMenuItem1.Click += new System.EventHandler(this.ColorFont_Click);
            // 
            // фонаТекстаToolStripMenuItem
            // 
            this.фонаТекстаToolStripMenuItem.Name = "фонаТекстаToolStripMenuItem";
            this.фонаТекстаToolStripMenuItem.Size = new System.Drawing.Size(140, 22);
            this.фонаТекстаToolStripMenuItem.Text = "Фона текста";
            this.фонаТекстаToolStripMenuItem.Click += new System.EventHandler(this.фонаТекстаToolStripMenuItem_Click);
            // 
            // фонаToolStripMenuItem1
            // 
            this.фонаToolStripMenuItem1.Name = "фонаToolStripMenuItem1";
            this.фонаToolStripMenuItem1.Size = new System.Drawing.Size(140, 22);
            this.фонаToolStripMenuItem1.Text = "Фона";
            this.фонаToolStripMenuItem1.Click += new System.EventHandler(this.ColorBack_Click);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = global::onDay10.Properties.Resources.applixware32;
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(23, 28);
            this.toolStripButton4.Text = "Выбор шрифта";
            this.toolStripButton4.Click += new System.EventHandler(this.Font_Click);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.плавающийToolStripMenuItem1});
            this.toolStripButton5.Image = global::onDay10.Properties.Resources.application_form_delete;
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(32, 28);
            this.toolStripButton5.Text = "Внешний вид";
            // 
            // плавающийToolStripMenuItem1
            // 
            this.плавающийToolStripMenuItem1.Checked = true;
            this.плавающийToolStripMenuItem1.CheckOnClick = true;
            this.плавающийToolStripMenuItem1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.плавающийToolStripMenuItem1.Name = "плавающийToolStripMenuItem1";
            this.плавающийToolStripMenuItem1.Size = new System.Drawing.Size(143, 22);
            this.плавающийToolStripMenuItem1.Text = "Плавающий";
            this.плавающийToolStripMenuItem1.Click += new System.EventHandler(this.фиксированныйToolStripMenuItem_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = global::onDay10.Properties.Resources.Info32;
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(23, 28);
            this.toolStripButton6.Text = "toolStripButton6";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 31);
            // 
            // contextMenuCommon
            // 
            this.contextMenuCommon.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПрограммеToolStripMenuItem1});
            this.contextMenuCommon.Name = "contextMenuCommon";
            this.contextMenuCommon.Size = new System.Drawing.Size(150, 26);
            // 
            // оПрограммеToolStripMenuItem1
            // 
            this.оПрограммеToolStripMenuItem1.Image = global::onDay10.Properties.Resources.Info;
            this.оПрограммеToolStripMenuItem1.Name = "оПрограммеToolStripMenuItem1";
            this.оПрограммеToolStripMenuItem1.Size = new System.Drawing.Size(149, 22);
            this.оПрограммеToolStripMenuItem1.Text = "О программе";
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 55);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tbMain);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.trackBar1);
            this.splitContainer1.Panel2.Controls.Add(this.statusStrip1);
            this.splitContainer1.Size = new System.Drawing.Size(641, 402);
            this.splitContainer1.SplitterDistance = 345;
            this.splitContainer1.TabIndex = 15;
            // 
            // tbMain
            // 
            this.tbMain.AutoWordSelection = true;
            this.tbMain.BackColor = System.Drawing.Color.White;
            this.tbMain.ContextMenuStrip = this.contextMenu;
            this.tbMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbMain.Location = new System.Drawing.Point(0, 0);
            this.tbMain.Name = "tbMain";
            this.tbMain.ShortcutsEnabled = false;
            this.tbMain.Size = new System.Drawing.Size(641, 345);
            this.tbMain.TabIndex = 16;
            this.tbMain.Text = "";
            // 
            // trackBar1
            // 
            this.trackBar1.Dock = System.Windows.Forms.DockStyle.Right;
            this.trackBar1.Location = new System.Drawing.Point(446, 0);
            this.trackBar1.Maximum = 5;
            this.trackBar1.Minimum = 1;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(195, 31);
            this.trackBar1.TabIndex = 16;
            this.trackBar1.Value = 1;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.stText});
            this.statusStrip1.Location = new System.Drawing.Point(0, 31);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(641, 22);
            this.statusStrip1.TabIndex = 15;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // stText
            // 
            this.stText.Name = "stText";
            this.stText.Size = new System.Drawing.Size(0, 17);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(641, 457);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MinimumSize = new System.Drawing.Size(400, 495);
            this.Name = "MainForm";
            this.Text = "My Word";
            this.contextMenu.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.contextMenuCommon.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog opFile;
        private System.Windows.Forms.SaveFileDialog sFile;
        private System.Windows.Forms.FontDialog fontDialog;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сохранитьКакToolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem закрытьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem правкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отменаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem настройкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выборЦветаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem текстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem фонаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выборШрифтаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenu;
        private System.Windows.Forms.ToolStripMenuItem CopyText;
        private System.Windows.Forms.ToolStripMenuItem CutText;
        private System.Windows.Forms.ToolStripMenuItem PasteText;
        private System.Windows.Forms.ToolStripMenuItem внешнийВидToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem плавающийToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem руководствоПользователяToolStripMenuItem;
        public System.Windows.Forms.ToolStripMenuItem открытьToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSplitButton toolStripSplitButton1;
        private System.Windows.Forms.ToolStripMenuItem текстаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem фонаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSplitButton toolStripButton5;
        private System.Windows.Forms.ToolStripMenuItem плавающийToolStripMenuItem1;
        private System.Windows.Forms.ContextMenuStrip contextMenuCommon;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton btnCopy;
        private System.Windows.Forms.ToolStripButton btnCut;
        private System.Windows.Forms.ToolStripButton btnPaste;
        private System.Windows.Forms.ToolStripSeparator sepEdit;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem фонаТекстаToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton Left;
        private System.Windows.Forms.ToolStripButton Redo;
        private System.Windows.Forms.ToolStripButton Center;
        private System.Windows.Forms.ToolStripButton Right;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton tsFind;
        private System.Windows.Forms.ToolStripButton btnClear;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton tsList;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.RichTextBox tbMain;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel stText;

    }
}

