﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onDay10
{
    public partial class FindForm : Form
    {
        MainForm Form;

        public int IndexFind { get; set; }

        public FindForm(MainForm Form)
        {
            InitializeComponent();
            this.Form = Form;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form.FindText(tbFind.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form.FindTextNext(tbFind.Text);
        }
    }
}
