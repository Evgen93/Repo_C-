﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace onDay10
{
    public partial class MainForm : Form
    {
        FindForm find;
        public MainForm()
        {
            InitializeComponent();
            // использование контекстного меню
            tbMain.ContextMenuStrip = contextMenuCommon;
         }

       
        private void закрытьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void фиксированныйToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (плавающийToolStripMenuItem.Checked == true)
            {
                //
                this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            }
            else
            {
                this.FormBorderStyle = FormBorderStyle.None;
            }
        }

        private void Open_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == opFile.ShowDialog())
            {
              //загрузка файла 
              tbMain.LoadFile(opFile.FileName);
               
              stText.Text = opFile.FileName;
              this.Text = opFile.SafeFileName;
            }
        }

        private void Save_Click(object sender, EventArgs e)
        {
            if (DialogResult.OK == sFile.ShowDialog())
            {

                tbMain.SaveFile(sFile.FileName);
            }
        }

        private void ColorFont_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
            {
               // применение цвета к выделенному тексту
                tbMain.SelectionColor = cd.Color;
            }
        }

        private void ColorBack_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.FullOpen = true;
            if (cd.ShowDialog() == DialogResult.OK)
            {
                // изменение цвета фона элемента
                tbMain.BackColor = cd.Color;
            }
        }

        private void Font_Click(object sender, EventArgs e)
        {
            if (fontDialog.ShowDialog() == DialogResult.OK)
            {
                // применение настроект шрифта выделенному тесту
                tbMain.SelectionFont = fontDialog.Font;
            }
        }

        private void Undo_Click_1(object sender, EventArgs e)
        {
            // реализация Undo
            tbMain.Undo();
        }

        private void CopyText_Click(object sender, EventArgs e)
        {
            // реализация копирования 
            btnPaste.Visible = true;
            tbMain.Copy();
        }

        private void PasteText_Click(object sender, EventArgs e)
        {
            // получение текста из буфера
            string NewText=Clipboard.GetText();
            // установка типа формата 
            DataFormats.Format myFormat = DataFormats.GetFormat(DataFormats.Rtf);
            // проверка на возможность вставки текста к форматом
            if (tbMain.CanPaste(myFormat))
            {
                // реализация вставки
                tbMain.Paste(myFormat);
            }
        }

        private void CutText_Click(object sender, EventArgs e)
        {
            btnPaste.Visible = true;
            // реализация вырезания 
            tbMain.Cut();
        }

       

        private void фонаТекстаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            if (cd.ShowDialog() == DialogResult.OK)
            {
                // изменение фонового цвета выделнного текста
                tbMain.SelectionBackColor = cd.Color;
            }
        }

        private void btnBullet_Click(object sender, EventArgs e)
        {
            // формирование списка
            tbMain.SelectionIndent = 2;
        }

        private void Redo_Click(object sender, EventArgs e)
        {
            tbMain.Redo();
        }

        private void Center_Click(object sender, EventArgs e)
        {
            // выравнивание теста по центру 
            tbMain.SelectionAlignment = HorizontalAlignment.Center;
        }

        private void Left_Click(object sender, EventArgs e)
        {
            // выравнивание теста по левой стороне 
            tbMain.SelectionAlignment = HorizontalAlignment.Left;
        }

        private void Right_Click(object sender, EventArgs e)
        {
            // выравнивание теста по правой стороне 
            tbMain.SelectionAlignment = HorizontalAlignment.Right;
        }

        private void tsFind_Click(object sender, EventArgs e)
        {
            // реализация посика
            if (find != null) find.Close();
            find = new FindForm(this);
            find.Show();
        }

        public void FindText(string Text)
        {
            tbMain.Find(Text);
            this.Activate();
            find.IndexFind = tbMain.SelectionStart;
        }


        public void FindTextNext(string Text)
        {
            tbMain.Find(Text, find.IndexFind + Text.Length, RichTextBoxFinds.MatchCase);
            this.Activate();
            find.IndexFind = tbMain.SelectionStart;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            tbMain.Clear();
        }
      

        private void tsList_Click(object sender, EventArgs e)
        {
            // формирование списка
            tbMain.BulletIndent = 30;
          
            tbMain.SelectionBullet = true;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            // масштаб
            tbMain.ZoomFactor = trackBar1.Value;
        }

       
      
    }

}
