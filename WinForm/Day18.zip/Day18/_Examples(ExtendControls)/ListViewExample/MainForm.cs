﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ListViewExample
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            InitializeListView();

        }

        private void InitializeListView()
        {
            // установка шрифта для ListView
            lvMain.Font = new System.Drawing.Font("Arial", 14);

            lvMain.MultiSelect = false;  // установлен режим выбора одного item
            lvMain.FullRowSelect = true; // выделение всей строки

            // формирование 
            lvMain.Columns.AddRange(new ColumnHeader[] 
             {
                new ColumnHeader { Text = "Наименование", Width=180, TextAlign=HorizontalAlignment.Left},
                new ColumnHeader { Text = "Преподаватель", Width=150 }
             });


            List<Topic> lstTopics = GetDate();

            lvMain.BeginUpdate();

            foreach (var value in lstTopics)
            {
                //ListViewItem listViewitem = new ListViewItem();
                //listViewitem.Text=value.Name;
                //listViewitem.SubItems.Add(value.Trainer);

                ListViewItem listViewitem = new ListViewItem(new[] { value.Name, value.Trainer });
                listViewitem.ImageIndex = value.ImageIndex;
                listViewitem.Tag = value;    // сохранение всего объекта в Tag (тип object)

                lvMain.Items.Add(listViewitem);
            }

            lvMain.EndUpdate();

            lvMain.ColumnClick += lvMain_ColumnClick;
        }

        private int sortColumnIndex = -1;
        void lvMain_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            
            if (e.Column != sortColumnIndex)
            {
                sortColumnIndex = e.Column;
                lvMain.Sorting = SortOrder.Ascending;
            }
            else
            {
                // определение направления последней сортировки
                if (lvMain.Sorting == SortOrder.Ascending)
                    lvMain.Sorting = SortOrder.Descending;
                else
                    lvMain.Sorting = SortOrder.Ascending;
            }

            lvMain.Sort();
            lvMain.ListViewItemSorter = new ListViewItemStringComparer(e.Column, lvMain.Sorting);
        }

        private static List<Topic> GetDate()
        {
            List<Topic> lstTopics = new List<Topic>()
            {   new Topic(){Name="C", ImageIndex=1, Trainer="Vladimir"},
                new Topic(){Name="C++", ImageIndex=1, Trainer="Igor"},
                new Topic(){Name="C#", ImageIndex=0, Trainer="Ivan"},
                new Topic(){Name="Windows Forms", ImageIndex=0, Trainer="Ivan"},
                new Topic(){Name="XML", ImageIndex=1, Trainer="Olga"},
                new Topic(){Name="WPF", ImageIndex=0, Trainer="Ivan"},
                new Topic(){Name="ADO.NET", ImageIndex=0, Trainer="Ivan"},
                new Topic(){Name="WCF", ImageIndex=0, Trainer="Denis"},
                new Topic(){Name="ASP.NET", ImageIndex=0, Trainer="Jon"},
                new Topic(){Name="Java", ImageIndex=1, Trainer="Vladimir"},
                new Topic(){Name="PHP", ImageIndex=1, Trainer="Inna"},
            };
            return lstTopics;
        }

        private void largeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvMain.View = View.LargeIcon;
        }

        private void smalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvMain.View = View.SmallIcon;
        }

        private void listToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvMain.View = View.List;
        }

        private void checkBoxesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lvMain.View != View.Tile)  // CheckBoxes не поддреживаются в режиме Tile
              lvMain.CheckBoxes = true;
        }

        private void detailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lvMain.View = View.Details;
        }

        private void tableToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lvMain.CheckBoxes != true)  //Tile не поддреживаются в режиме CheckBoxes
               lvMain.View = View.Tile;
        }

        private void lvMain_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvMain.SelectedItems.Count != 0)
            {
                for (int i = 0; i < lvMain.SelectedItems.Count; i++)
			    {
                    this.Text=lvMain.SelectedItems[i].Text;
                    
                    Topic selTopic = (Topic)lvMain.SelectedItems[i].Tag;
                    stInfo.Text =selTopic.ToString();
			    } 
            }
        }
    }


    class Topic
    {
        public string Name { get; set; }
        public string Trainer { get; set; }
        public int  ImageIndex { get; set; }

        public override string ToString()
        {
            return Name + " - " + Trainer;
        }
      
    }
}
