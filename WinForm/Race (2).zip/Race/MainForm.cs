﻿using Race.entities;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace Race
{
    public partial class MainForm : Form
    {
        List<Button> _cars;
        List<Thread> _thread;
        Action<int> action;
        public MainForm()
        {
            InitializeComponent();
            _cars = new List<Button> { btnCar1, btnCar2, btnCar3, btnCar4, btnCar5, btnCar6 };
            action = new Action<int>(ThreadMove);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            _thread = new List<Thread>(Convert.ToInt32(numCars.Value));
            for (int i = 0; i < numCars.Value; i++)
            {
                _cars[i].Visible = true;
                _thread.Add(new Thread(CarMove));
                _thread[i].IsBackground = true;
                _thread[i].Start(i);
            }
            numCars.Enabled = false;
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (var item in _thread)
            {
                item.Abort();
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            SuspendAllThreads();
        }

        private void SuspendAllThreads()
        {
            foreach (var item in _thread)
            {
                item.Suspend();
            }
            btnStart.Enabled = true;
        }

        private void CarMove(object param)
        {
            for (;;)
            {
                Thread.Sleep(100);
                Invoke(action, param);
            }
        }

        private void ThreadMove(int index)
        {
            if (!RaseIsFinish(index))
            {
                _cars[index].Left += (Randomer.GetNum() + tbSpeed.Value);
                ChangeLiderColor();
            }
            else
            {
                MessageBox.Show($"{_cars[index].Text} is winner!");
            }
        }

        private bool RaseIsFinish(int index)
        {
            if ((_cars[index].Location.X + _cars[index].Width) >= pbFinish.Location.X)
            {
                _cars[index].BackColor = Color.Red;
                SuspendAllThreads();
                btnStart.Enabled = false;
                return true;
            }
            else
            {
                return false;
            }
        }

        private void ChangeLiderColor()
        {
            var l = _cars.FirstOrDefault(p => p.Left == _cars.Max(c => c.Left));
            l.BackColor = Color.Yellow;
            foreach (var item in _cars)
            {
                if (item != l)
                {
                    item.BackColor = Color.White;
                }
            }
        }

        private void btnResume_Click(object sender, EventArgs e)
        {
            SuspendAllThreads();
            foreach (var item in _cars)
            {
                item.Left = 68;
                item.BackColor = Color.White;
            }
        }
    }
}
