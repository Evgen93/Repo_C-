﻿namespace Race
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbRaceControls = new System.Windows.Forms.GroupBox();
            this.lbNumOfCars = new System.Windows.Forms.Label();
            this.numCars = new System.Windows.Forms.NumericUpDown();
            this.lbSpeed = new System.Windows.Forms.Label();
            this.tbSpeed = new System.Windows.Forms.TrackBar();
            this.btnResume = new System.Windows.Forms.Button();
            this.btnStop = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.pbFinish = new System.Windows.Forms.PictureBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.progressBar2 = new System.Windows.Forms.ProgressBar();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnCar1 = new System.Windows.Forms.Button();
            this.btnCar2 = new System.Windows.Forms.Button();
            this.btnCar3 = new System.Windows.Forms.Button();
            this.btnCar4 = new System.Windows.Forms.Button();
            this.btnCar5 = new System.Windows.Forms.Button();
            this.btnCar6 = new System.Windows.Forms.Button();
            this.gbRaceControls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numCars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFinish)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gbRaceControls
            // 
            this.gbRaceControls.Controls.Add(this.lbNumOfCars);
            this.gbRaceControls.Controls.Add(this.numCars);
            this.gbRaceControls.Controls.Add(this.lbSpeed);
            this.gbRaceControls.Controls.Add(this.tbSpeed);
            this.gbRaceControls.Controls.Add(this.btnResume);
            this.gbRaceControls.Controls.Add(this.btnStop);
            this.gbRaceControls.Controls.Add(this.btnStart);
            this.gbRaceControls.Location = new System.Drawing.Point(12, 493);
            this.gbRaceControls.Name = "gbRaceControls";
            this.gbRaceControls.Size = new System.Drawing.Size(1065, 133);
            this.gbRaceControls.TabIndex = 0;
            this.gbRaceControls.TabStop = false;
            this.gbRaceControls.Text = "Race Controls";
            // 
            // lbNumOfCars
            // 
            this.lbNumOfCars.AutoSize = true;
            this.lbNumOfCars.Location = new System.Drawing.Point(18, 65);
            this.lbNumOfCars.Name = "lbNumOfCars";
            this.lbNumOfCars.Size = new System.Drawing.Size(80, 13);
            this.lbNumOfCars.TabIndex = 6;
            this.lbNumOfCars.Text = "Number of Cars";
            // 
            // numCars
            // 
            this.numCars.Location = new System.Drawing.Point(104, 63);
            this.numCars.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.numCars.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numCars.Name = "numCars";
            this.numCars.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numCars.Size = new System.Drawing.Size(48, 20);
            this.numCars.TabIndex = 5;
            this.numCars.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // lbSpeed
            // 
            this.lbSpeed.AutoSize = true;
            this.lbSpeed.Location = new System.Drawing.Point(837, 28);
            this.lbSpeed.Name = "lbSpeed";
            this.lbSpeed.Size = new System.Drawing.Size(38, 13);
            this.lbSpeed.TabIndex = 4;
            this.lbSpeed.Text = "Speed";
            // 
            // tbSpeed
            // 
            this.tbSpeed.Location = new System.Drawing.Point(626, 53);
            this.tbSpeed.Maximum = 100;
            this.tbSpeed.Minimum = 1;
            this.tbSpeed.Name = "tbSpeed";
            this.tbSpeed.Size = new System.Drawing.Size(418, 45);
            this.tbSpeed.TabIndex = 3;
            this.tbSpeed.Value = 1;
            // 
            // btnResume
            // 
            this.btnResume.Location = new System.Drawing.Point(480, 28);
            this.btnResume.Name = "btnResume";
            this.btnResume.Size = new System.Drawing.Size(126, 87);
            this.btnResume.TabIndex = 2;
            this.btnResume.Text = "Restart";
            this.btnResume.UseVisualStyleBackColor = true;
            this.btnResume.Click += new System.EventHandler(this.btnResume_Click);
            // 
            // btnStop
            // 
            this.btnStop.Location = new System.Drawing.Point(326, 28);
            this.btnStop.Name = "btnStop";
            this.btnStop.Size = new System.Drawing.Size(126, 87);
            this.btnStop.TabIndex = 1;
            this.btnStop.Text = "Stop";
            this.btnStop.UseVisualStyleBackColor = true;
            this.btnStop.Click += new System.EventHandler(this.btnStop_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(174, 28);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(126, 87);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // pbFinish
            // 
            this.pbFinish.BackColor = System.Drawing.Color.Blue;
            this.pbFinish.Location = new System.Drawing.Point(1035, 13);
            this.pbFinish.Name = "pbFinish";
            this.pbFinish.Size = new System.Drawing.Size(20, 474);
            this.pbFinish.TabIndex = 1;
            this.pbFinish.TabStop = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(186, 13);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(849, 23);
            this.progressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar1.TabIndex = 2;
            // 
            // progressBar2
            // 
            this.progressBar2.Location = new System.Drawing.Point(186, 464);
            this.progressBar2.Name = "progressBar2";
            this.progressBar2.Size = new System.Drawing.Size(849, 23);
            this.progressBar2.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.progressBar2.TabIndex = 3;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Red;
            this.pictureBox1.Location = new System.Drawing.Point(160, 13);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(20, 474);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // btnCar1
            // 
            this.btnCar1.BackColor = System.Drawing.Color.White;
            this.btnCar1.Location = new System.Drawing.Point(68, 54);
            this.btnCar1.Name = "btnCar1";
            this.btnCar1.Size = new System.Drawing.Size(75, 23);
            this.btnCar1.TabIndex = 0;
            this.btnCar1.Text = "Car_1";
            this.btnCar1.UseVisualStyleBackColor = false;
            // 
            // btnCar2
            // 
            this.btnCar2.BackColor = System.Drawing.Color.White;
            this.btnCar2.Location = new System.Drawing.Point(68, 123);
            this.btnCar2.Name = "btnCar2";
            this.btnCar2.Size = new System.Drawing.Size(75, 23);
            this.btnCar2.TabIndex = 1;
            this.btnCar2.Text = "Car_2";
            this.btnCar2.UseVisualStyleBackColor = false;
            // 
            // btnCar3
            // 
            this.btnCar3.BackColor = System.Drawing.Color.White;
            this.btnCar3.Location = new System.Drawing.Point(68, 191);
            this.btnCar3.Name = "btnCar3";
            this.btnCar3.Size = new System.Drawing.Size(75, 23);
            this.btnCar3.TabIndex = 2;
            this.btnCar3.Text = "Car_3";
            this.btnCar3.UseVisualStyleBackColor = false;
            // 
            // btnCar4
            // 
            this.btnCar4.BackColor = System.Drawing.Color.White;
            this.btnCar4.Location = new System.Drawing.Point(68, 268);
            this.btnCar4.Name = "btnCar4";
            this.btnCar4.Size = new System.Drawing.Size(75, 23);
            this.btnCar4.TabIndex = 3;
            this.btnCar4.Text = "Car_4";
            this.btnCar4.UseVisualStyleBackColor = false;
            // 
            // btnCar5
            // 
            this.btnCar5.BackColor = System.Drawing.Color.White;
            this.btnCar5.Location = new System.Drawing.Point(68, 339);
            this.btnCar5.Name = "btnCar5";
            this.btnCar5.Size = new System.Drawing.Size(75, 23);
            this.btnCar5.TabIndex = 4;
            this.btnCar5.Text = "Car_5";
            this.btnCar5.UseVisualStyleBackColor = false;
            // 
            // btnCar6
            // 
            this.btnCar6.BackColor = System.Drawing.Color.White;
            this.btnCar6.Location = new System.Drawing.Point(68, 420);
            this.btnCar6.Name = "btnCar6";
            this.btnCar6.Size = new System.Drawing.Size(75, 23);
            this.btnCar6.TabIndex = 5;
            this.btnCar6.Text = "Car_6";
            this.btnCar6.UseVisualStyleBackColor = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1089, 638);
            this.Controls.Add(this.btnCar6);
            this.Controls.Add(this.btnCar5);
            this.Controls.Add(this.btnCar4);
            this.Controls.Add(this.btnCar3);
            this.Controls.Add(this.btnCar2);
            this.Controls.Add(this.btnCar1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.progressBar2);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.pbFinish);
            this.Controls.Add(this.gbRaceControls);
            this.Name = "MainForm";
            this.Text = "Race";
            this.gbRaceControls.ResumeLayout(false);
            this.gbRaceControls.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numCars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbFinish)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbRaceControls;
        private System.Windows.Forms.Button btnResume;
        private System.Windows.Forms.Button btnStop;
        private System.Windows.Forms.Label lbSpeed;
        private System.Windows.Forms.TrackBar tbSpeed;
        private System.Windows.Forms.PictureBox pbFinish;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.ProgressBar progressBar2;
        private System.Windows.Forms.Label lbNumOfCars;
        private System.Windows.Forms.NumericUpDown numCars;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnCar1;
        private System.Windows.Forms.Button btnCar2;
        private System.Windows.Forms.Button btnCar3;
        private System.Windows.Forms.Button btnCar4;
        private System.Windows.Forms.Button btnCar5;
        private System.Windows.Forms.Button btnCar6;
    }
}

