﻿using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;

namespace GasStation.Validators
{
    public static class TextBoxValidator
    {
        public static bool ValidatorNumbers(this TextBox textBox)
        {
            var numberFormat = new NumberFormatInfo { NumberDecimalSeparator = "," };
            decimal value = 0;

            if (textBox.Text.Length == 0)
            {
                textBox.BackColor = Color.White;
                return false;
            }

            if (!Decimal.TryParse(textBox.Text, NumberStyles.AllowDecimalPoint, numberFormat, out value))
            {
                textBox.BackColor = Color.Red;
                return false;
            }
            else
            {
                textBox.BackColor = Color.White;
                return true;
            }
        }
    }
}
