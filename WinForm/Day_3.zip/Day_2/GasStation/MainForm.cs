﻿using GasStation.Model.Entites;
using GasStation.Model.Repositories;
using GasStation.Validators;
using System;
using System.Linq;
using System.Windows.Forms;

namespace GasStation
{
    public partial class MainForm : Form
    {
        private const int DefaultValue = 0;
        private const int DefaultOne = 1;
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, System.EventArgs e)
        {
            IRepository repo = new FuelRopository();
            cbGas.DisplayMember = "Name";
            cbGas.DataSource = repo.Get();
        }

        private void cbGas_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            FuelInfo select = cbGas.SelectedItem as FuelInfo;
            if (select != null)
            {
                tbGasPriceliter.Text = select.Price.ToString();
            }
        }

        private void rbCol_CheckedChanged(object sender, System.EventArgs e)
        {
            tbGasNum.ReadOnly = !rbCol.Checked;
            tbGasNum.Text = String.Empty;
            tbGasPrice.ReadOnly = rbCol.Checked;
            tbGasPrice.Text = String.Empty;
        }

        private void cbHotDog_CheckedChanged(object sender, System.EventArgs e)
        {
            CheckBox check = (CheckBox)sender;
            var control = this.Controls.Find(check.Tag.ToString(), true).First() as TextBox;
            control.ReadOnly = !check.Checked;

            if (!check.Checked)
            {
                control.Text = DefaultOne.ToString();
            }
            CulculateMarker();
        }

        private void tbGasNum_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;
            if (textBox.ValidatorNumbers())
            {
                tbGasTotal.Text = (Decimal.Parse(textBox.Text) * Decimal.Parse(tbGasPriceliter.Text)).ToString();
                tbGasPrice.Text = tbGasTotal.Text;
            }
            else
            {
                tbGasTotal.Text = DefaultValue.ToString();
            }
        }

        private void CulculateMarker()
        {
            var constrols = gbCafe.Controls.OfType<CheckBox>();
            var markertSumma = 0m;
            foreach (var item in constrols)
            {
                if (!item.Checked)
                    continue;

                var controlAmount = (TextBox)Controls.Find(item.Tag.ToString(), true).First();
                if (!controlAmount.ValidatorNumbers())
                {
                    continue;
                }
                var controlPrice = (TextBox)Controls.Find(controlAmount.Tag.ToString(), true).First();
                markertSumma += Decimal.Parse(controlAmount.Text) * Decimal.Parse(controlPrice.Text);
            }

            tbCafeTotal.Text = markertSumma.ToString("N2");
        }

        private void tbGasPrice_TextChanged(object sender, EventArgs e)
        {
            var textBox = (TextBox)sender;
            if (textBox.ValidatorNumbers())
            {
                tbGasTotal.Text = textBox.Text;
                tbGasNum.Text = (Decimal.Parse(textBox.Text) / Decimal.Parse(tbGasPriceliter.Text)).ToString();
            }
            else
            {
                tbGasTotal.Text = DefaultValue.ToString();
            }
        }

        private void tbHotFogNum_TextChanged(object sender, EventArgs e)
        {
            TextBox textbox = (TextBox)sender;
            if (textbox.ValidatorNumbers())
            {
                if (textbox.Text.Length == 0)
                {
                    textbox.Text = DefaultValue.ToString();
                }
                else
                {
                    CulculateMarker();
                }
            }
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            
        }

        private void tbTotal_TextChanged(object sender, EventArgs e)
        {

        }

        private void MainForm_Resize(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
        }

        private void tbGasTotal_TextChanged(object sender, EventArgs e)
        {
            tbTotal.Text = (Decimal.Parse(tbCafeTotal.Text) + Decimal.Parse(tbGasTotal.Text)).ToString();
        }
    }
}
