﻿
namespace GasStation.Model.Entites
{
    public class FuelInfo
    {
        public string Name { set; get; }

        public decimal Price { set; get; }

        public override string ToString()
        {
            return $"{Name} - {Price}";
        }
    }
}
