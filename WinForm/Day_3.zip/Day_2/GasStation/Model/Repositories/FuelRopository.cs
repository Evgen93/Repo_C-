﻿using System.Collections.Generic;
using GasStation.Model.Entites;

namespace GasStation.Model.Repositories
{
    public class FuelRopository : IRepository
    {
        public IEnumerable<FuelInfo> Get()
        {
            return new List<FuelInfo>()
            {
                new FuelInfo() { Name = "АИ-92", Price = 1.40m},
                 new FuelInfo() { Name = "АИ-95", Price = 1.45m},
                  new FuelInfo() { Name = "АИ-98", Price = 1.48m},
            };
        }
    }
}
