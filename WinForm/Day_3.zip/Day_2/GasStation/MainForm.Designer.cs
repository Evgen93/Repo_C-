﻿namespace GasStation
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbGas = new System.Windows.Forms.GroupBox();
            this.tbGasPriceliter = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbGasTotal = new System.Windows.Forms.TextBox();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.lbRub = new System.Windows.Forms.Label();
            this.cbGas = new System.Windows.Forms.ComboBox();
            this.lbPrice = new System.Windows.Forms.Label();
            this.lbgas = new System.Windows.Forms.Label();
            this.gbCol = new System.Windows.Forms.GroupBox();
            this.tbGasPrice = new System.Windows.Forms.TextBox();
            this.tbGasNum = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rbSum = new System.Windows.Forms.RadioButton();
            this.rbCol = new System.Windows.Forms.RadioButton();
            this.cbHotDog = new System.Windows.Forms.CheckBox();
            this.cbGumb = new System.Windows.Forms.CheckBox();
            this.cbChez = new System.Windows.Forms.CheckBox();
            this.cbCola = new System.Windows.Forms.CheckBox();
            this.lbPriceCafe = new System.Windows.Forms.Label();
            this.lbColCafe = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbCafeTotal = new System.Windows.Forms.TextBox();
            this.gbCafe = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbColaNum = new System.Windows.Forms.TextBox();
            this.tbColaPrice = new System.Windows.Forms.TextBox();
            this.tbChezPNum = new System.Windows.Forms.TextBox();
            this.tbChezPrice = new System.Windows.Forms.TextBox();
            this.tbGumbNum = new System.Windows.Forms.TextBox();
            this.tbGumbPrice = new System.Windows.Forms.TextBox();
            this.tbHotFogNum = new System.Windows.Forms.TextBox();
            this.tbHotFogPrice = new System.Windows.Forms.TextBox();
            this.tbTotal = new System.Windows.Forms.TextBox();
            this.btnCalc = new System.Windows.Forms.Button();
            this.lbTotal = new System.Windows.Forms.Label();
            this.gbGas.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.gbCol.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbCafe.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbGas
            // 
            this.gbGas.Controls.Add(this.tbGasPriceliter);
            this.gbGas.Controls.Add(this.groupBox2);
            this.gbGas.Controls.Add(this.comboBox5);
            this.gbGas.Controls.Add(this.lbRub);
            this.gbGas.Controls.Add(this.cbGas);
            this.gbGas.Controls.Add(this.lbPrice);
            this.gbGas.Controls.Add(this.lbgas);
            this.gbGas.Location = new System.Drawing.Point(20, 20);
            this.gbGas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbGas.Name = "gbGas";
            this.gbGas.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbGas.Size = new System.Drawing.Size(440, 509);
            this.gbGas.TabIndex = 0;
            this.gbGas.TabStop = false;
            this.gbGas.Text = "Топливо";
            // 
            // tbGasPriceliter
            // 
            this.tbGasPriceliter.Location = new System.Drawing.Point(156, 92);
            this.tbGasPriceliter.Name = "tbGasPriceliter";
            this.tbGasPriceliter.ReadOnly = true;
            this.tbGasPriceliter.Size = new System.Drawing.Size(180, 26);
            this.tbGasPriceliter.TabIndex = 16;
            this.tbGasPriceliter.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tbGasTotal);
            this.groupBox2.Location = new System.Drawing.Point(21, 322);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(409, 179);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "К оплате";
            // 
            // tbGasTotal
            // 
            this.tbGasTotal.BackColor = System.Drawing.Color.White;
            this.tbGasTotal.Location = new System.Drawing.Point(17, 25);
            this.tbGasTotal.Multiline = true;
            this.tbGasTotal.Name = "tbGasTotal";
            this.tbGasTotal.ReadOnly = true;
            this.tbGasTotal.Size = new System.Drawing.Size(369, 110);
            this.tbGasTotal.TabIndex = 0;
            this.tbGasTotal.Text = "0";
            this.tbGasTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbGasTotal.TextChanged += new System.EventHandler(this.tbGasTotal_TextChanged);
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(130, 240);
            this.comboBox5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(180, 28);
            this.comboBox5.TabIndex = 5;
            // 
            // lbRub
            // 
            this.lbRub.AutoSize = true;
            this.lbRub.ForeColor = System.Drawing.Color.Red;
            this.lbRub.Location = new System.Drawing.Point(278, 98);
            this.lbRub.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbRub.Name = "lbRub";
            this.lbRub.Size = new System.Drawing.Size(38, 20);
            this.lbRub.TabIndex = 4;
            this.lbRub.Text = "руб.";
            // 
            // cbGas
            // 
            this.cbGas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbGas.FormattingEnabled = true;
            this.cbGas.Location = new System.Drawing.Point(156, 28);
            this.cbGas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbGas.Name = "cbGas";
            this.cbGas.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.cbGas.Size = new System.Drawing.Size(180, 28);
            this.cbGas.TabIndex = 2;
            this.cbGas.SelectedIndexChanged += new System.EventHandler(this.cbGas_SelectedIndexChanged);
            // 
            // lbPrice
            // 
            this.lbPrice.AutoSize = true;
            this.lbPrice.ForeColor = System.Drawing.Color.Red;
            this.lbPrice.Location = new System.Drawing.Point(34, 95);
            this.lbPrice.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbPrice.Name = "lbPrice";
            this.lbPrice.Size = new System.Drawing.Size(48, 20);
            this.lbPrice.TabIndex = 1;
            this.lbPrice.Text = "Цена";
            // 
            // lbgas
            // 
            this.lbgas.AutoSize = true;
            this.lbgas.ForeColor = System.Drawing.Color.Blue;
            this.lbgas.Location = new System.Drawing.Point(32, 31);
            this.lbgas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbgas.Name = "lbgas";
            this.lbgas.Size = new System.Drawing.Size(64, 20);
            this.lbgas.TabIndex = 0;
            this.lbgas.Text = "Бензин";
            // 
            // gbCol
            // 
            this.gbCol.Controls.Add(this.tbGasPrice);
            this.gbCol.Controls.Add(this.tbGasNum);
            this.gbCol.Controls.Add(this.label2);
            this.gbCol.Controls.Add(this.label1);
            this.gbCol.Controls.Add(this.rbSum);
            this.gbCol.Controls.Add(this.rbCol);
            this.gbCol.Location = new System.Drawing.Point(20, 183);
            this.gbCol.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbCol.Name = "gbCol";
            this.gbCol.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbCol.Size = new System.Drawing.Size(430, 154);
            this.gbCol.TabIndex = 1;
            this.gbCol.TabStop = false;
            // 
            // tbGasPrice
            // 
            this.tbGasPrice.Location = new System.Drawing.Point(156, 69);
            this.tbGasPrice.Name = "tbGasPrice";
            this.tbGasPrice.ReadOnly = true;
            this.tbGasPrice.Size = new System.Drawing.Size(170, 26);
            this.tbGasPrice.TabIndex = 9;
            this.tbGasPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbGasPrice.TextChanged += new System.EventHandler(this.tbGasPrice_TextChanged);
            // 
            // tbGasNum
            // 
            this.tbGasNum.Location = new System.Drawing.Point(156, 30);
            this.tbGasNum.Name = "tbGasNum";
            this.tbGasNum.ReadOnly = true;
            this.tbGasNum.Size = new System.Drawing.Size(170, 26);
            this.tbGasNum.TabIndex = 8;
            this.tbGasNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbGasNum.TextChanged += new System.EventHandler(this.tbGasNum_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(345, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "руб.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(345, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "л.";
            // 
            // rbSum
            // 
            this.rbSum.AutoSize = true;
            this.rbSum.Location = new System.Drawing.Point(20, 68);
            this.rbSum.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbSum.Name = "rbSum";
            this.rbSum.Size = new System.Drawing.Size(76, 24);
            this.rbSum.TabIndex = 1;
            this.rbSum.Text = "Сумма";
            this.rbSum.UseVisualStyleBackColor = true;
            this.rbSum.CheckedChanged += new System.EventHandler(this.rbCol_CheckedChanged);
            // 
            // rbCol
            // 
            this.rbCol.AutoSize = true;
            this.rbCol.Location = new System.Drawing.Point(20, 31);
            this.rbCol.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbCol.Name = "rbCol";
            this.rbCol.Size = new System.Drawing.Size(118, 24);
            this.rbCol.TabIndex = 0;
            this.rbCol.TabStop = true;
            this.rbCol.Text = "Количество";
            this.rbCol.UseVisualStyleBackColor = true;
            this.rbCol.CheckedChanged += new System.EventHandler(this.rbCol_CheckedChanged);
            // 
            // cbHotDog
            // 
            this.cbHotDog.AutoSize = true;
            this.cbHotDog.ForeColor = System.Drawing.Color.Blue;
            this.cbHotDog.Location = new System.Drawing.Point(8, 76);
            this.cbHotDog.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbHotDog.Name = "cbHotDog";
            this.cbHotDog.Size = new System.Drawing.Size(89, 24);
            this.cbHotDog.TabIndex = 0;
            this.cbHotDog.Tag = "tbHotFogNum";
            this.cbHotDog.Text = "Хот-дог";
            this.cbHotDog.UseVisualStyleBackColor = true;
            this.cbHotDog.CheckedChanged += new System.EventHandler(this.cbHotDog_CheckedChanged);
            // 
            // cbGumb
            // 
            this.cbGumb.AutoSize = true;
            this.cbGumb.ForeColor = System.Drawing.Color.Blue;
            this.cbGumb.Location = new System.Drawing.Point(8, 136);
            this.cbGumb.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbGumb.Name = "cbGumb";
            this.cbGumb.Size = new System.Drawing.Size(107, 24);
            this.cbGumb.TabIndex = 1;
            this.cbGumb.Tag = "tbGumbNum";
            this.cbGumb.Text = "Гамбургер";
            this.cbGumb.UseVisualStyleBackColor = true;
            this.cbGumb.CheckedChanged += new System.EventHandler(this.cbHotDog_CheckedChanged);
            // 
            // cbChez
            // 
            this.cbChez.AutoSize = true;
            this.cbChez.ForeColor = System.Drawing.Color.Blue;
            this.cbChez.Location = new System.Drawing.Point(8, 193);
            this.cbChez.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbChez.Name = "cbChez";
            this.cbChez.Size = new System.Drawing.Size(107, 24);
            this.cbChez.TabIndex = 2;
            this.cbChez.Tag = "tbChezPNum";
            this.cbChez.Text = "Чизбургер";
            this.cbChez.UseVisualStyleBackColor = true;
            this.cbChez.CheckedChanged += new System.EventHandler(this.cbHotDog_CheckedChanged);
            // 
            // cbCola
            // 
            this.cbCola.AutoSize = true;
            this.cbCola.ForeColor = System.Drawing.Color.Blue;
            this.cbCola.Location = new System.Drawing.Point(8, 256);
            this.cbCola.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbCola.Name = "cbCola";
            this.cbCola.Size = new System.Drawing.Size(105, 24);
            this.cbCola.TabIndex = 3;
            this.cbCola.Tag = "tbColaNum";
            this.cbCola.Text = "Кока-кола";
            this.cbCola.UseVisualStyleBackColor = true;
            this.cbCola.CheckedChanged += new System.EventHandler(this.cbHotDog_CheckedChanged);
            // 
            // lbPriceCafe
            // 
            this.lbPriceCafe.AutoSize = true;
            this.lbPriceCafe.ForeColor = System.Drawing.Color.Red;
            this.lbPriceCafe.Location = new System.Drawing.Point(207, 52);
            this.lbPriceCafe.Name = "lbPriceCafe";
            this.lbPriceCafe.Size = new System.Drawing.Size(48, 20);
            this.lbPriceCafe.TabIndex = 12;
            this.lbPriceCafe.Text = "Цена";
            // 
            // lbColCafe
            // 
            this.lbColCafe.AutoSize = true;
            this.lbColCafe.ForeColor = System.Drawing.Color.Blue;
            this.lbColCafe.Location = new System.Drawing.Point(343, 49);
            this.lbColCafe.Name = "lbColCafe";
            this.lbColCafe.Size = new System.Drawing.Size(100, 20);
            this.lbColCafe.TabIndex = 13;
            this.lbColCafe.Text = "Количество";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbCafeTotal);
            this.groupBox1.Location = new System.Drawing.Point(7, 322);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(409, 179);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "К оплате";
            // 
            // tbCafeTotal
            // 
            this.tbCafeTotal.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.tbCafeTotal.Location = new System.Drawing.Point(24, 25);
            this.tbCafeTotal.Multiline = true;
            this.tbCafeTotal.Name = "tbCafeTotal";
            this.tbCafeTotal.ReadOnly = true;
            this.tbCafeTotal.Size = new System.Drawing.Size(369, 110);
            this.tbCafeTotal.TabIndex = 1;
            this.tbCafeTotal.Text = "0";
            this.tbCafeTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gbCafe
            // 
            this.gbCafe.Controls.Add(this.label6);
            this.gbCafe.Controls.Add(this.label5);
            this.gbCafe.Controls.Add(this.label4);
            this.gbCafe.Controls.Add(this.label3);
            this.gbCafe.Controls.Add(this.tbColaNum);
            this.gbCafe.Controls.Add(this.tbColaPrice);
            this.gbCafe.Controls.Add(this.tbChezPNum);
            this.gbCafe.Controls.Add(this.tbChezPrice);
            this.gbCafe.Controls.Add(this.tbGumbNum);
            this.gbCafe.Controls.Add(this.tbGumbPrice);
            this.gbCafe.Controls.Add(this.tbHotFogNum);
            this.gbCafe.Controls.Add(this.tbHotFogPrice);
            this.gbCafe.Controls.Add(this.groupBox1);
            this.gbCafe.Controls.Add(this.lbColCafe);
            this.gbCafe.Controls.Add(this.lbPriceCafe);
            this.gbCafe.Controls.Add(this.cbCola);
            this.gbCafe.Controls.Add(this.cbChez);
            this.gbCafe.Controls.Add(this.cbGumb);
            this.gbCafe.Controls.Add(this.cbHotDog);
            this.gbCafe.Location = new System.Drawing.Point(468, 20);
            this.gbCafe.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbCafe.Name = "gbCafe";
            this.gbCafe.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gbCafe.Size = new System.Drawing.Size(483, 509);
            this.gbCafe.TabIndex = 2;
            this.gbCafe.TabStop = false;
            this.gbCafe.Text = "Мини-кафе";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(261, 260);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 20);
            this.label6.TabIndex = 26;
            this.label6.Text = "руб.";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(261, 194);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 20);
            this.label5.TabIndex = 25;
            this.label5.Text = "руб.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(261, 137);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 20);
            this.label4.TabIndex = 24;
            this.label4.Text = "руб.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(261, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 20);
            this.label3.TabIndex = 23;
            this.label3.Text = "руб.";
            // 
            // tbColaNum
            // 
            this.tbColaNum.Location = new System.Drawing.Point(322, 254);
            this.tbColaNum.Name = "tbColaNum";
            this.tbColaNum.ReadOnly = true;
            this.tbColaNum.Size = new System.Drawing.Size(121, 26);
            this.tbColaNum.TabIndex = 22;
            this.tbColaNum.Tag = "tbColaPrice";
            this.tbColaNum.Text = "1";
            this.tbColaNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbColaNum.TextChanged += new System.EventHandler(this.tbHotFogNum_TextChanged);
            // 
            // tbColaPrice
            // 
            this.tbColaPrice.Location = new System.Drawing.Point(134, 254);
            this.tbColaPrice.Name = "tbColaPrice";
            this.tbColaPrice.ReadOnly = true;
            this.tbColaPrice.Size = new System.Drawing.Size(121, 26);
            this.tbColaPrice.TabIndex = 21;
            this.tbColaPrice.Text = "2";
            this.tbColaPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbChezPNum
            // 
            this.tbChezPNum.Location = new System.Drawing.Point(322, 191);
            this.tbChezPNum.Name = "tbChezPNum";
            this.tbChezPNum.ReadOnly = true;
            this.tbChezPNum.Size = new System.Drawing.Size(121, 26);
            this.tbChezPNum.TabIndex = 20;
            this.tbChezPNum.Tag = "tbChezPrice";
            this.tbChezPNum.Text = "1";
            this.tbChezPNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbChezPNum.TextChanged += new System.EventHandler(this.tbHotFogNum_TextChanged);
            // 
            // tbChezPrice
            // 
            this.tbChezPrice.Location = new System.Drawing.Point(134, 191);
            this.tbChezPrice.Name = "tbChezPrice";
            this.tbChezPrice.ReadOnly = true;
            this.tbChezPrice.Size = new System.Drawing.Size(121, 26);
            this.tbChezPrice.TabIndex = 19;
            this.tbChezPrice.Text = "1,7";
            this.tbChezPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbGumbNum
            // 
            this.tbGumbNum.Location = new System.Drawing.Point(322, 134);
            this.tbGumbNum.Name = "tbGumbNum";
            this.tbGumbNum.ReadOnly = true;
            this.tbGumbNum.Size = new System.Drawing.Size(121, 26);
            this.tbGumbNum.TabIndex = 18;
            this.tbGumbNum.Tag = "tbGumbPrice";
            this.tbGumbNum.Text = "1";
            this.tbGumbNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbGumbNum.TextChanged += new System.EventHandler(this.tbHotFogNum_TextChanged);
            // 
            // tbGumbPrice
            // 
            this.tbGumbPrice.Location = new System.Drawing.Point(134, 134);
            this.tbGumbPrice.Name = "tbGumbPrice";
            this.tbGumbPrice.ReadOnly = true;
            this.tbGumbPrice.Size = new System.Drawing.Size(121, 26);
            this.tbGumbPrice.TabIndex = 17;
            this.tbGumbPrice.Text = "1,5";
            this.tbGumbPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbHotFogNum
            // 
            this.tbHotFogNum.Location = new System.Drawing.Point(322, 76);
            this.tbHotFogNum.Name = "tbHotFogNum";
            this.tbHotFogNum.ReadOnly = true;
            this.tbHotFogNum.Size = new System.Drawing.Size(121, 26);
            this.tbHotFogNum.TabIndex = 16;
            this.tbHotFogNum.Tag = "tbHotFogPrice";
            this.tbHotFogNum.Text = "1";
            this.tbHotFogNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbHotFogNum.TextChanged += new System.EventHandler(this.tbHotFogNum_TextChanged);
            // 
            // tbHotFogPrice
            // 
            this.tbHotFogPrice.Location = new System.Drawing.Point(134, 76);
            this.tbHotFogPrice.Name = "tbHotFogPrice";
            this.tbHotFogPrice.ReadOnly = true;
            this.tbHotFogPrice.Size = new System.Drawing.Size(121, 26);
            this.tbHotFogPrice.TabIndex = 15;
            this.tbHotFogPrice.Text = "2";
            this.tbHotFogPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbTotal
            // 
            this.tbTotal.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.tbTotal.Location = new System.Drawing.Point(512, 537);
            this.tbTotal.Multiline = true;
            this.tbTotal.Name = "tbTotal";
            this.tbTotal.ReadOnly = true;
            this.tbTotal.Size = new System.Drawing.Size(324, 88);
            this.tbTotal.TabIndex = 3;
            this.tbTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.tbTotal.TextChanged += new System.EventHandler(this.tbTotal_TextChanged);
            // 
            // btnCalc
            // 
            this.btnCalc.BackColor = System.Drawing.Color.Silver;
            this.btnCalc.ForeColor = System.Drawing.Color.Red;
            this.btnCalc.Location = new System.Drawing.Point(150, 550);
            this.btnCalc.Name = "btnCalc";
            this.btnCalc.Size = new System.Drawing.Size(222, 64);
            this.btnCalc.TabIndex = 4;
            this.btnCalc.Text = "Рассчитать";
            this.btnCalc.UseVisualStyleBackColor = false;
            this.btnCalc.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // lbTotal
            // 
            this.lbTotal.AutoSize = true;
            this.lbTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbTotal.Location = new System.Drawing.Point(393, 561);
            this.lbTotal.Name = "lbTotal";
            this.lbTotal.Size = new System.Drawing.Size(100, 33);
            this.lbTotal.TabIndex = 5;
            this.lbTotal.Text = "Итого:";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(974, 761);
            this.Controls.Add(this.lbTotal);
            this.Controls.Add(this.btnCalc);
            this.Controls.Add(this.tbTotal);
            this.Controls.Add(this.gbCafe);
            this.Controls.Add(this.gbCol);
            this.Controls.Add(this.gbGas);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "MainForm";
            this.Text = "Автозаправка";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this.gbGas.ResumeLayout(false);
            this.gbGas.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.gbCol.ResumeLayout(false);
            this.gbCol.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbCafe.ResumeLayout(false);
            this.gbCafe.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbGas;
        private System.Windows.Forms.TextBox tbGasPriceliter;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbGasTotal;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label lbRub;
        private System.Windows.Forms.ComboBox cbGas;
        private System.Windows.Forms.Label lbPrice;
        private System.Windows.Forms.Label lbgas;
        private System.Windows.Forms.GroupBox gbCol;
        private System.Windows.Forms.TextBox tbGasPrice;
        private System.Windows.Forms.TextBox tbGasNum;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rbSum;
        private System.Windows.Forms.RadioButton rbCol;
        private System.Windows.Forms.CheckBox cbHotDog;
        private System.Windows.Forms.CheckBox cbGumb;
        private System.Windows.Forms.CheckBox cbChez;
        private System.Windows.Forms.CheckBox cbCola;
        private System.Windows.Forms.Label lbPriceCafe;
        private System.Windows.Forms.Label lbColCafe;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox tbCafeTotal;
        private System.Windows.Forms.GroupBox gbCafe;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbColaNum;
        private System.Windows.Forms.TextBox tbColaPrice;
        private System.Windows.Forms.TextBox tbChezPNum;
        private System.Windows.Forms.TextBox tbChezPrice;
        private System.Windows.Forms.TextBox tbGumbNum;
        private System.Windows.Forms.TextBox tbGumbPrice;
        private System.Windows.Forms.TextBox tbHotFogNum;
        private System.Windows.Forms.TextBox tbHotFogPrice;
        private System.Windows.Forms.TextBox tbTotal;
        private System.Windows.Forms.Button btnCalc;
        private System.Windows.Forms.Label lbTotal;
    }
}

