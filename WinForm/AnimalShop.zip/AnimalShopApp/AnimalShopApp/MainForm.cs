﻿using AnimalShopApp.Model.Entities;
using AnimalShopApp.Model.Repositories;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnimalShopApp
{
    public partial class MainForm : Form
    {
        private IRepository<AnimalInfo> _animals;

        public MainForm()
        {
            InitializeComponent();
            _animals = new AnimalRepository();

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            lstAnimals.DataSource = _animals.Load();
            lstProperties.DataSource = _animals.Load();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AnimalInfo animalInfo = new AnimalInfo()
            {
                Name = tbName.Text,
                Age = (int)numAge.Value,
                Price = numPrice.Value
            };
            _animals.Add(animalInfo);

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var select = lstAnimals.SelectedItem as AnimalInfo;
            if (select != null)
            {
                _animals.Remove(select);
            }
        }

        private void lstAnimals_SelectedIndexChanged(object sender, EventArgs e)
        {
            var select = lstAnimals.SelectedItem as AnimalInfo;
            if (select != null)
            {
                tbName.Text = select.Name;
                numAge.Value = select.Age;
                numPrice.Value = select.Price;
                lstAnimalProperties.DataSource = select.Propetries;
            }
        }

        private void btnSaveItem_Click(object sender, EventArgs e)
        {
            var select = lstAnimals.SelectedItem as AnimalInfo;
            if (select != null)
            {
                foreach (var item in new[] {"Хвост","Зубы","тттт" })
                {
                    select.Propetries.Add(new AnimalProperties() {Name= item});
                }
                
                select.Name = tbName.Text;
                select.Age = (int)numAge.Value;
                select.Price = numPrice.Value;
                _animals.Update();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            _animals.Save(null);
        }
    }
}
