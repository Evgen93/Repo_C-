﻿using AnimalShopApp.Helpers;
using AnimalShopApp.Model.Entities;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalShopApp.Model.Repositories
{
    public class AnimalRepository : IRepository<AnimalInfo>
    {
        private BindingList<AnimalInfo> _animals;

        public AnimalRepository()
        {
            _animals = new BindingList<AnimalInfo>();
        }

        public void Add(AnimalInfo item)
        {
            if (item == null)
            {
                throw new ArgumentNullException();
            }
            _animals.Add(item);
        }

        public IList<AnimalInfo> Load()
        {
            return SerializerHelper.Deserialize<AnimalInfo>("animals.dat"); ;
        }

        public void Remove(AnimalInfo item)
        {
            if (item == null)
            {
                throw new ArgumentNullException();
            }
            _animals.Remove(item);
        }

        public void Save(IList<AnimalInfo> list)
        {
            SerializerHelper.Serialize(_animals, "animals.dat");
        }

        public void Update()
        {

            _animals.ResetBindings();
        }
    }
}
