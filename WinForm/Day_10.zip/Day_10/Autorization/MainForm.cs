﻿using Autorization.Model.Entities;
using Autorization.Model.Forms;
using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace Autorization
{
    public partial class MainForm : Form
    {
        public event EventHandler GotFocus;
        public event EventHandler LostFocus;

        private PasswordChangeForm _passwordChangeform;
        private RegistrationForm _regForm;
        private BindingList<UserInfo> _userList;

        public MainForm()
        {
            InitializeComponent();
            _passwordChangeform = new PasswordChangeForm();
            _regForm = new RegistrationForm();
            GotFocus += new EventHandler(tbLogin_GotFocus);
            LostFocus += new EventHandler(tbLogin_LostFocus);
            _userList = new BindingList<UserInfo>();
        }

        private void llbRegistration_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            _regForm.ShowDialog();
        }

        private void llbChangePasswd_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (_passwordChangeform.ShowDialog() == DialogResult.OK)
            { 
                _userList.Add(_regForm.GetUserData());
            }
        }

        private void tbLogin_GotFocus(object sender, EventArgs e)
        {

        }

        private void tbLogin_LostFocus(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

        }
    }
}
