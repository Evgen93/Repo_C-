﻿using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Autorization.Helpers
{
    public static class SerializerHelper
    {
        public static void Serialize<T>(IList<T> list, string fileName)
        {
            using (FileStream file = new FileStream(fileName, FileMode.OpenOrCreate))
            {
                BinaryFormatter serializer = new BinaryFormatter();
                serializer.Serialize(file, list);
            }
        }

        public static IList<T> DeSerialize<T>(string fileName)
        {
            using (FileStream file = new FileStream(fileName, FileMode.Open))
            {
                BinaryFormatter serializer = new BinaryFormatter();
                return (IList<T>)serializer.Deserialize(file);
            }
        }
    }
}
