﻿namespace Autorization
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grPicture = new System.Windows.Forms.GroupBox();
            this.grAutorizationSettings = new System.Windows.Forms.GroupBox();
            this.llbChangePasswd = new System.Windows.Forms.LinkLabel();
            this.llbRegistration = new System.Windows.Forms.LinkLabel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbLogin = new System.Windows.Forms.Label();
            this.lbPassword = new System.Windows.Forms.Label();
            this.tbLogin = new System.Windows.Forms.TextBox();
            this.textBox2tbPassword = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.grPicture.SuspendLayout();
            this.grAutorizationSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // grPicture
            // 
            this.grPicture.Controls.Add(this.pictureBox1);
            this.grPicture.Location = new System.Drawing.Point(13, 13);
            this.grPicture.Name = "grPicture";
            this.grPicture.Size = new System.Drawing.Size(282, 345);
            this.grPicture.TabIndex = 0;
            this.grPicture.TabStop = false;
            // 
            // grAutorizationSettings
            // 
            this.grAutorizationSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.grAutorizationSettings.Controls.Add(this.btnLogin);
            this.grAutorizationSettings.Controls.Add(this.textBox2tbPassword);
            this.grAutorizationSettings.Controls.Add(this.tbLogin);
            this.grAutorizationSettings.Controls.Add(this.lbPassword);
            this.grAutorizationSettings.Controls.Add(this.lbLogin);
            this.grAutorizationSettings.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.grAutorizationSettings.Location = new System.Drawing.Point(301, 13);
            this.grAutorizationSettings.Name = "grAutorizationSettings";
            this.grAutorizationSettings.Size = new System.Drawing.Size(294, 345);
            this.grAutorizationSettings.TabIndex = 1;
            this.grAutorizationSettings.TabStop = false;
            this.grAutorizationSettings.Text = "Параметры авторизации";
            // 
            // llbChangePasswd
            // 
            this.llbChangePasswd.AutoSize = true;
            this.llbChangePasswd.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.llbChangePasswd.Location = new System.Drawing.Point(9, 406);
            this.llbChangePasswd.Name = "llbChangePasswd";
            this.llbChangePasswd.Size = new System.Drawing.Size(136, 20);
            this.llbChangePasswd.TabIndex = 2;
            this.llbChangePasswd.TabStop = true;
            this.llbChangePasswd.Text = "Забыли пароль?";
            this.llbChangePasswd.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbChangePasswd_LinkClicked);
            // 
            // llbRegistration
            // 
            this.llbRegistration.AutoSize = true;
            this.llbRegistration.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.llbRegistration.Location = new System.Drawing.Point(489, 406);
            this.llbRegistration.Name = "llbRegistration";
            this.llbRegistration.Size = new System.Drawing.Size(106, 20);
            this.llbRegistration.TabIndex = 3;
            this.llbRegistration.TabStop = true;
            this.llbRegistration.Text = "Регистрация";
            this.llbRegistration.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llbRegistration_LinkClicked);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(6, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(270, 310);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // lbLogin
            // 
            this.lbLogin.AutoSize = true;
            this.lbLogin.Location = new System.Drawing.Point(7, 48);
            this.lbLogin.Name = "lbLogin";
            this.lbLogin.Size = new System.Drawing.Size(157, 20);
            this.lbLogin.TabIndex = 0;
            this.lbLogin.Text = "Имя пользователя:";
            // 
            // lbPassword
            // 
            this.lbPassword.AutoSize = true;
            this.lbPassword.Location = new System.Drawing.Point(7, 148);
            this.lbPassword.Name = "lbPassword";
            this.lbPassword.Size = new System.Drawing.Size(71, 20);
            this.lbPassword.TabIndex = 1;
            this.lbPassword.Text = "Пароль:";
            // 
            // tbLogin
            // 
            this.tbLogin.Location = new System.Drawing.Point(11, 71);
            this.tbLogin.Name = "tbLogin";
            this.tbLogin.Size = new System.Drawing.Size(249, 26);
            this.tbLogin.TabIndex = 2;
            // 
            // textBox2tbPassword
            // 
            this.textBox2tbPassword.Location = new System.Drawing.Point(11, 180);
            this.textBox2tbPassword.Name = "textBox2tbPassword";
            this.textBox2tbPassword.PasswordChar = '*';
            this.textBox2tbPassword.Size = new System.Drawing.Size(249, 26);
            this.textBox2tbPassword.TabIndex = 3;
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(108, 260);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(152, 56);
            this.btnLogin.TabIndex = 4;
            this.btnLogin.Text = "Войти";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // MainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(607, 432);
            this.Controls.Add(this.llbRegistration);
            this.Controls.Add(this.llbChangePasswd);
            this.Controls.Add(this.grAutorizationSettings);
            this.Controls.Add(this.grPicture);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Авторизация";
            this.grPicture.ResumeLayout(false);
            this.grAutorizationSettings.ResumeLayout(false);
            this.grAutorizationSettings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grPicture;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox grAutorizationSettings;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.TextBox textBox2tbPassword;
        private System.Windows.Forms.TextBox tbLogin;
        private System.Windows.Forms.Label lbPassword;
        private System.Windows.Forms.Label lbLogin;
        private System.Windows.Forms.LinkLabel llbChangePasswd;
        private System.Windows.Forms.LinkLabel llbRegistration;
    }
}

