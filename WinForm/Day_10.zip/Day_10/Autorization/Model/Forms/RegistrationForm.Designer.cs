﻿namespace Autorization.Model.Forms
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grAutorizationInfo = new System.Windows.Forms.GroupBox();
            this.grUserData = new System.Windows.Forms.GroupBox();
            this.lbLogin = new System.Windows.Forms.Label();
            this.tbLogin = new System.Windows.Forms.TextBox();
            this.tbPasswprd = new System.Windows.Forms.TextBox();
            this.lbPasswprd = new System.Windows.Forms.Label();
            this.tbRepeatPassword = new System.Windows.Forms.TextBox();
            this.lbRepeatPassword = new System.Windows.Forms.Label();
            this.tbFirstName = new System.Windows.Forms.TextBox();
            this.lbFirstName = new System.Windows.Forms.Label();
            this.tbLastName = new System.Windows.Forms.TextBox();
            this.lbLastName = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.lbEmail = new System.Windows.Forms.Label();
            this.lbRequiredFields = new System.Windows.Forms.Label();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lbStarLogin = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.grAutorizationInfo.SuspendLayout();
            this.grUserData.SuspendLayout();
            this.SuspendLayout();
            // 
            // grAutorizationInfo
            // 
            this.grAutorizationInfo.Controls.Add(this.label2);
            this.grAutorizationInfo.Controls.Add(this.label1);
            this.grAutorizationInfo.Controls.Add(this.lbStarLogin);
            this.grAutorizationInfo.Controls.Add(this.tbRepeatPassword);
            this.grAutorizationInfo.Controls.Add(this.lbRepeatPassword);
            this.grAutorizationInfo.Controls.Add(this.tbPasswprd);
            this.grAutorizationInfo.Controls.Add(this.lbPasswprd);
            this.grAutorizationInfo.Controls.Add(this.tbLogin);
            this.grAutorizationInfo.Controls.Add(this.lbLogin);
            this.grAutorizationInfo.Location = new System.Drawing.Point(13, 13);
            this.grAutorizationInfo.Name = "grAutorizationInfo";
            this.grAutorizationInfo.Size = new System.Drawing.Size(358, 239);
            this.grAutorizationInfo.TabIndex = 0;
            this.grAutorizationInfo.TabStop = false;
            this.grAutorizationInfo.Text = "Информация авторизации";
            // 
            // grUserData
            // 
            this.grUserData.Controls.Add(this.label3);
            this.grUserData.Controls.Add(this.tbFirstName);
            this.grUserData.Controls.Add(this.tbLastName);
            this.grUserData.Controls.Add(this.lbFirstName);
            this.grUserData.Controls.Add(this.lbEmail);
            this.grUserData.Controls.Add(this.tbEmail);
            this.grUserData.Controls.Add(this.lbLastName);
            this.grUserData.Location = new System.Drawing.Point(377, 13);
            this.grUserData.Name = "grUserData";
            this.grUserData.Size = new System.Drawing.Size(358, 239);
            this.grUserData.TabIndex = 1;
            this.grUserData.TabStop = false;
            this.grUserData.Text = "Личные данные пользователя";
            // 
            // lbLogin
            // 
            this.lbLogin.AutoSize = true;
            this.lbLogin.Location = new System.Drawing.Point(7, 33);
            this.lbLogin.Name = "lbLogin";
            this.lbLogin.Size = new System.Drawing.Size(41, 13);
            this.lbLogin.TabIndex = 0;
            this.lbLogin.Text = "Логин:";
            // 
            // tbLogin
            // 
            this.tbLogin.Location = new System.Drawing.Point(10, 50);
            this.tbLogin.Name = "tbLogin";
            this.tbLogin.Size = new System.Drawing.Size(266, 20);
            this.tbLogin.TabIndex = 1;
            // 
            // tbPasswprd
            // 
            this.tbPasswprd.Location = new System.Drawing.Point(10, 121);
            this.tbPasswprd.Name = "tbPasswprd";
            this.tbPasswprd.PasswordChar = '*';
            this.tbPasswprd.Size = new System.Drawing.Size(266, 20);
            this.tbPasswprd.TabIndex = 3;
            // 
            // lbPasswprd
            // 
            this.lbPasswprd.AutoSize = true;
            this.lbPasswprd.Location = new System.Drawing.Point(7, 105);
            this.lbPasswprd.Name = "lbPasswprd";
            this.lbPasswprd.Size = new System.Drawing.Size(48, 13);
            this.lbPasswprd.TabIndex = 2;
            this.lbPasswprd.Text = "Пароль:";
            // 
            // tbRepeatPassword
            // 
            this.tbRepeatPassword.Location = new System.Drawing.Point(10, 191);
            this.tbRepeatPassword.Name = "tbRepeatPassword";
            this.tbRepeatPassword.PasswordChar = '*';
            this.tbRepeatPassword.Size = new System.Drawing.Size(266, 20);
            this.tbRepeatPassword.TabIndex = 5;
            // 
            // lbRepeatPassword
            // 
            this.lbRepeatPassword.AutoSize = true;
            this.lbRepeatPassword.Location = new System.Drawing.Point(7, 174);
            this.lbRepeatPassword.Name = "lbRepeatPassword";
            this.lbRepeatPassword.Size = new System.Drawing.Size(103, 13);
            this.lbRepeatPassword.TabIndex = 4;
            this.lbRepeatPassword.Text = "Повторите пароль:";
            // 
            // tbFirstName
            // 
            this.tbFirstName.Location = new System.Drawing.Point(15, 191);
            this.tbFirstName.Name = "tbFirstName";
            this.tbFirstName.Size = new System.Drawing.Size(266, 20);
            this.tbFirstName.TabIndex = 11;
            // 
            // lbFirstName
            // 
            this.lbFirstName.AutoSize = true;
            this.lbFirstName.Location = new System.Drawing.Point(12, 174);
            this.lbFirstName.Name = "lbFirstName";
            this.lbFirstName.Size = new System.Drawing.Size(59, 13);
            this.lbFirstName.TabIndex = 10;
            this.lbFirstName.Text = "Фамилия:";
            // 
            // tbLastName
            // 
            this.tbLastName.Location = new System.Drawing.Point(15, 121);
            this.tbLastName.Name = "tbLastName";
            this.tbLastName.Size = new System.Drawing.Size(266, 20);
            this.tbLastName.TabIndex = 9;
            // 
            // lbLastName
            // 
            this.lbLastName.AutoSize = true;
            this.lbLastName.Location = new System.Drawing.Point(12, 105);
            this.lbLastName.Name = "lbLastName";
            this.lbLastName.Size = new System.Drawing.Size(32, 13);
            this.lbLastName.TabIndex = 8;
            this.lbLastName.Text = "Имя:";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(15, 50);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(266, 20);
            this.tbEmail.TabIndex = 7;
            // 
            // lbEmail
            // 
            this.lbEmail.AutoSize = true;
            this.lbEmail.Location = new System.Drawing.Point(12, 33);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(38, 13);
            this.lbEmail.TabIndex = 6;
            this.lbEmail.Text = "E-mail:";
            // 
            // lbRequiredFields
            // 
            this.lbRequiredFields.AutoSize = true;
            this.lbRequiredFields.ForeColor = System.Drawing.Color.Red;
            this.lbRequiredFields.Location = new System.Drawing.Point(20, 285);
            this.lbRequiredFields.Name = "lbRequiredFields";
            this.lbRequiredFields.Size = new System.Drawing.Size(204, 13);
            this.lbRequiredFields.TabIndex = 6;
            this.lbRequiredFields.Text = "* - обязательные для заполнения поля";
            // 
            // btnOK
            // 
            this.btnOK.Location = new System.Drawing.Point(505, 268);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(106, 41);
            this.btnOK.TabIndex = 7;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(629, 268);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(106, 41);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // lbStarLogin
            // 
            this.lbStarLogin.AutoSize = true;
            this.lbStarLogin.ForeColor = System.Drawing.Color.Red;
            this.lbStarLogin.Location = new System.Drawing.Point(305, 57);
            this.lbStarLogin.Name = "lbStarLogin";
            this.lbStarLogin.Size = new System.Drawing.Size(11, 13);
            this.lbStarLogin.TabIndex = 9;
            this.lbStarLogin.Text = "*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(305, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "*";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(305, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(11, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(313, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "*";
            // 
            // RegistrationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(745, 324);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnOK);
            this.Controls.Add(this.lbRequiredFields);
            this.Controls.Add(this.grUserData);
            this.Controls.Add(this.grAutorizationInfo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "RegistrationForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Регистрация нового пользователя:";
            this.grAutorizationInfo.ResumeLayout(false);
            this.grAutorizationInfo.PerformLayout();
            this.grUserData.ResumeLayout(false);
            this.grUserData.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grAutorizationInfo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbStarLogin;
        private System.Windows.Forms.TextBox tbRepeatPassword;
        private System.Windows.Forms.Label lbRepeatPassword;
        private System.Windows.Forms.TextBox tbPasswprd;
        private System.Windows.Forms.Label lbPasswprd;
        private System.Windows.Forms.TextBox tbLogin;
        private System.Windows.Forms.Label lbLogin;
        private System.Windows.Forms.GroupBox grUserData;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbFirstName;
        private System.Windows.Forms.TextBox tbLastName;
        private System.Windows.Forms.Label lbFirstName;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.Label lbLastName;
        private System.Windows.Forms.Label lbRequiredFields;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnCancel;
    }
}