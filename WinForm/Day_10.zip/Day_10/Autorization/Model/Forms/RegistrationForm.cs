﻿using Autorization.Model.Entities;
using System;
using System.Windows.Forms;

namespace Autorization.Model.Forms
{
    public partial class RegistrationForm : Form
    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }

        public UserInfo GetUserData()
        {
            UserInfo userInfo = new UserInfo();
            userInfo.Email = tbEmail.Text;
            userInfo.FirstName = tbFirstName.Text;
            userInfo.LastName = tbFirstName.Text;
            userInfo.Login = tbLogin.Text;
            userInfo.Password = tbPasswprd.Text;

            return userInfo;
        }
    }
}
