﻿namespace Autorization.Model.Forms
{
    partial class PasswordChangeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grChangePasswd = new System.Windows.Forms.GroupBox();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbNewPassword = new System.Windows.Forms.TextBox();
            this.tbRepeatPassword = new System.Windows.Forms.TextBox();
            this.lbEmail = new System.Windows.Forms.Label();
            this.lbNewPassword = new System.Windows.Forms.Label();
            this.lbRepeatPassword = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnOk = new System.Windows.Forms.Button();
            this.grChangePasswd.SuspendLayout();
            this.SuspendLayout();
            // 
            // grChangePasswd
            // 
            this.grChangePasswd.Controls.Add(this.lbRepeatPassword);
            this.grChangePasswd.Controls.Add(this.lbNewPassword);
            this.grChangePasswd.Controls.Add(this.lbEmail);
            this.grChangePasswd.Controls.Add(this.tbRepeatPassword);
            this.grChangePasswd.Controls.Add(this.tbNewPassword);
            this.grChangePasswd.Controls.Add(this.tbEmail);
            this.grChangePasswd.Location = new System.Drawing.Point(12, 25);
            this.grChangePasswd.Name = "grChangePasswd";
            this.grChangePasswd.Size = new System.Drawing.Size(268, 260);
            this.grChangePasswd.TabIndex = 0;
            this.grChangePasswd.TabStop = false;
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(20, 58);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(233, 20);
            this.tbEmail.TabIndex = 0;
            // 
            // tbNewPassword
            // 
            this.tbNewPassword.Location = new System.Drawing.Point(20, 119);
            this.tbNewPassword.Name = "tbNewPassword";
            this.tbNewPassword.PasswordChar = '*';
            this.tbNewPassword.Size = new System.Drawing.Size(233, 20);
            this.tbNewPassword.TabIndex = 1;
            // 
            // tbRepeatPassword
            // 
            this.tbRepeatPassword.Location = new System.Drawing.Point(20, 183);
            this.tbRepeatPassword.Name = "tbRepeatPassword";
            this.tbRepeatPassword.PasswordChar = '*';
            this.tbRepeatPassword.Size = new System.Drawing.Size(233, 20);
            this.tbRepeatPassword.TabIndex = 2;
            // 
            // lbEmail
            // 
            this.lbEmail.AutoSize = true;
            this.lbEmail.Location = new System.Drawing.Point(20, 39);
            this.lbEmail.Name = "lbEmail";
            this.lbEmail.Size = new System.Drawing.Size(82, 13);
            this.lbEmail.TabIndex = 3;
            this.lbEmail.Text = "Введите e-mail:";
            // 
            // lbNewPassword
            // 
            this.lbNewPassword.AutoSize = true;
            this.lbNewPassword.Location = new System.Drawing.Point(20, 103);
            this.lbNewPassword.Name = "lbNewPassword";
            this.lbNewPassword.Size = new System.Drawing.Size(126, 13);
            this.lbNewPassword.TabIndex = 4;
            this.lbNewPassword.Text = "Введите новый пароль:";
            // 
            // lbRepeatPassword
            // 
            this.lbRepeatPassword.AutoSize = true;
            this.lbRepeatPassword.Location = new System.Drawing.Point(20, 167);
            this.lbRepeatPassword.Name = "lbRepeatPassword";
            this.lbRepeatPassword.Size = new System.Drawing.Size(138, 13);
            this.lbRepeatPassword.TabIndex = 5;
            this.lbRepeatPassword.Text = "Повторите новый пароль:";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(180, 313);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(99, 32);
            this.btnCancel.TabIndex = 2;
            this.btnCancel.Text = "Отмена";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(71, 313);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(99, 32);
            this.btnOk.TabIndex = 3;
            this.btnOk.Text = "OK";
            this.btnOk.UseVisualStyleBackColor = true;
            // 
            // PasswordChangeForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(291, 356);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.grChangePasswd);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "PasswordChangeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Востановление пароля";
            this.grChangePasswd.ResumeLayout(false);
            this.grChangePasswd.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grChangePasswd;
        private System.Windows.Forms.Label lbRepeatPassword;
        private System.Windows.Forms.Label lbNewPassword;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.TextBox tbRepeatPassword;
        private System.Windows.Forms.TextBox tbNewPassword;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnOk;
    }
}