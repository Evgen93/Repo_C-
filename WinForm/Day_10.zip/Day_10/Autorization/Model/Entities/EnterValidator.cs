﻿using System.Collections.Generic;

namespace Autorization.Model.Entities
{
    public static class EnterValidator
    {
        static int Validate(T user, IList<T> userList)
        {
            for (int i = 0; i < userList.Count; i++)
            {
                if ()
                {

                }
            }
        }
    }
}
