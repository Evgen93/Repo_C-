﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// указываем для аттрибута InternalsVisibleTo
using System.Runtime.CompilerServices;

// аттрибут будет позволять сборке  Example1.1StandartAttribute
// получать доступ к internal типам и методам текущей сборки

[assembly: InternalsVisibleTo("Example1.1StandartAttribute")]

namespace FriendAssemblies
{
    internal sealed class CarInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
