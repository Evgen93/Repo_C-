﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FriendAssemblies
{
    public class ShopCars
    {
        List<CarInfo> lstCars;

        public ShopCars()
        {
            lstCars = new List<CarInfo>();
        }

        public int CountCars
        {
            get { return lstCars.Count; }
        }

        internal void AddCar(CarInfo car)  // метод тоже internal т.к. работает с internal CarInfo
        {                                  //  public нельзя т.к. inconsistent accessibility  
            lstCars.Add(car);
        }
    }
}
