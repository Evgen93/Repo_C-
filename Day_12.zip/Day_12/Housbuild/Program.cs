﻿using System;

namespace Housbuild
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
