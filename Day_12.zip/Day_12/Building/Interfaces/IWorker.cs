﻿using System;

namespace Building.Interfaces
{
    interface IWorker
    {
        IPart Work(House house);
    }
}
