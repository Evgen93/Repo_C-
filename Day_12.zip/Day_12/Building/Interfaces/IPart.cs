﻿using System;

namespace Building.Interfaces
{
    interface IPart
    {
        bool Create();
    }
}
