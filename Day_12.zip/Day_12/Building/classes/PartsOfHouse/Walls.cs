﻿using Building.Interfaces;
using System;

namespace Building
{
    public class Walls : IPart
    { 

        public bool Create()
        {
            throw new NotImplementedException();
        }
    }
}
