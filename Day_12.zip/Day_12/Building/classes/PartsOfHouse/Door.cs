﻿using System;
using Building.Interfaces;

namespace Building
{
    class Door : IPart
    {
    }
}
