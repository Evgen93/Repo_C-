﻿using Building.Interfaces;
using System;

namespace Building
{
    public class House
    {
        private IPart[] housPartArr;

        private int _lenth;

        public int Lenth
        {
            get { return _lenth; }
        }


    }
}
