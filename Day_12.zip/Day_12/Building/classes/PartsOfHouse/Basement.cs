﻿using System;
using Building.Interfaces;

namespace Building
{
    public class Basement : IPart
    {
    }
}
