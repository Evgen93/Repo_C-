﻿using Building.Interfaces;
using System;

namespace Building.PartsOfHouse
{
    class PlanOfHouse : IPart
    {

    }
}
