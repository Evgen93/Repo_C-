﻿using System;
using Building.Interfaces;

namespace Building
{
    class Team
    {
        private IWorker[] workers;


        private int _lenth;

        public int Lenth
        {
            get { return _lenth; }
        }

    }
}
