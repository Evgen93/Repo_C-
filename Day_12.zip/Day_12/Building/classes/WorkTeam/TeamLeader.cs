﻿using System;
using Building.Interfaces;

namespace Building.WorkTeam
{
    class TeamLeader : IWorker
    {
        
        public IPart Work(House house)
        {
            
        }
    }
}
