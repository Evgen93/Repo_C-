﻿using System;
using Building.Interfaces;

namespace Building.WorkTeam
{
    class Worker : IWorker
    {
        public IPart Work(House house)
        {
           
        }
    }
}
