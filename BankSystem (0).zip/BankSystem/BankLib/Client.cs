﻿using System;

namespace BankLib
{
    public class Client
    {
        #region FIELD
        const int ACC_COUNT = 2;
        private Account[] account;

        public int getAccountId(int index)
        {
            if (account.Length == 0)
            {
                return -1;
            }
            else
            {
                if (account[index] == null)
                {
                    throw new ArgumentException("accoun[index] is null");
                }
                else
                {
                    return account[index].NumOfAccId;

                }
            }
        }

        private string lastName;

        public string LastName
        {
            get { return lastName; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Name is not correct...");
                }
                lastName = value;
            }
        }

        private string firstName;

        public string FirstName
        {
            get { return firstName; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException("Name is not correct...");
                }
                firstName = value;
            }
        }

        private string login;

        public string Login
        {
            get { return login; }
        }

        private string passwd;

        public string Passwd
        {
            get { return passwd; }
            set { passwd = value; }
        }
        #endregion

        #region CTOR
        public Client(string _LastName, string _firstName, string _login, string _passwd)
        {
            lastName = _LastName; firstName = _firstName; login = _login; passwd = _passwd;
            account = new Account[ACC_COUNT];
        }

        #endregion

        #region METHODS
        public double GetDeposit(int AccId)
        {
            for (int i = 0; i < account.Length; i++)
            {
                if (account[i] != null && account[i].NumOfAccId == AccId)
                {
                    return account[i].Deposit;
                }
            }
                return -1;
        }

        public bool ArrIsEmpty()
        {
            if(account.Length == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// add an account
        /// </summary>
        /// <param name="acc"></param>
        /// <returns>
        /// false - if the array is full
        /// true - if the addition was successful
        /// </returns>
        public bool AddAccount(Account acc)
        {
            if (acc == null)
            {
                throw new ArgumentNullException("Account is null");
            }
            else
            {
                int index = SearchAFreeElem();
                if (index == -1)
                {
                    return false;
                }
                else
                {
                    account[index] = acc;
                    return true;
                }
            }

        }

        /// <summary>
        /// search for a free element of an array of type Account
        /// </summary>
        /// <returns>
        /// -1 : if array is full
        /// otherwise returns the index of the free cell of the array
        /// </returns>
        public int SearchAFreeElem()
        {
            for (int i = 0; i < account.Length; i++)
            {
                if (account[i] == null)
                {
                    return i;
                }
            }
            return -1;
        }
        #endregion
    }
}
