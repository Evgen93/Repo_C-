﻿using System;


namespace BankLib
{
    public class Account
    {
        #region FIELD
        private string numOfPassport;

        public string NumOfPassport
        {
            get { return numOfPassport; }
        }

        private int numOfAccId;

        public int NumOfAccId
        {
            get { return numOfAccId; }
        }

        private double percentOfBank;

        public double PercentOfBank
        {
            get { return percentOfBank; }
        }

        private double deposit;

        public double Deposit
        {
            get { return deposit; }
        }

        private string accType;

        public string AccType
        {
            get { return accType; }
        }
        #endregion

        #region CTOR
        public Account(string _numOfPassport, string typeOfAcc)
        {
            if (typeOfAcc != "val" && typeOfAcc != "rub")
            {
                throw new ArgumentException("Incorrect argument");
            }
            else
            {
                numOfPassport = _numOfPassport;
                numOfAccId = Rand.Rnd;
                deposit = 0;
                accType = typeOfAcc;
                if (accType == "rub")
                {
                    percentOfBank = 1;
                }
                else
                {
                    percentOfBank = 1.5d;
                }
            }
        }
        #endregion
    }
}
