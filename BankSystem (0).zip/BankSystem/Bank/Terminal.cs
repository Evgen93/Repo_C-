﻿using System;
using BankLib;

namespace BankSystem
{
    class Terminal
    {
        public static Client RegistrationClientForm()
        {
            Console.Write("Введите логин: ");
            string login = Console.ReadLine();

            string passwd;

            while (true)
            {
                Console.Write("Введите пароль (пароль должен быть не менее 6 символов и содержать символы верхнего регистра): ");
                passwd = Console.ReadLine();
                if (!Banksecurity.SecurityCheckPasswd(passwd))
                {
                    Console.WriteLine("Неподходящий пароль");
                }
                else
                {
                    break;
                }
            }

            Console.Write("Введите имя: ");
            string firstName = Console.ReadLine();

            Console.Write("Введите фамилию: ");
            string lastName = Console.ReadLine();

            return new Client(lastName, firstName, login, passwd);
        }

        private static Account RegistrationAccountForm()
        {
            string numOfPas;

            while (true)
            {
                Console.Write("Введите номер паспорта (пример: 7123456А001РВ3): ");
                numOfPas = Console.ReadLine();
                if (!Banksecurity.CheckNumOfPassport(numOfPas))
                {
                    Console.Clear();
                    Console.WriteLine("Неверный номер паспорта");
                }
                else
                {
                    break;
                }
            }

            string typeOfAcc;
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Выберите тип счета:\n1 - в инностранной валюте;\n2 - в рублях.");
                typeOfAcc = Console.ReadLine();
                if (typeOfAcc != "1" && typeOfAcc != "2")
                {
                    Console.Clear();
                    Console.WriteLine("Неверное знычение.");
                }
                else
                {
                    break;
                }
            }

            if (typeOfAcc == "1")
            {
                typeOfAcc = "val";
            }
            else
            {
                typeOfAcc = "rub";
            }
            return new Account(numOfPas, typeOfAcc);
        }

        private static int ChoiseCheck(string menu, int maxChoise)
        {
            while (true)
            {
                Console.WriteLine(menu);
                int choice = -1;
                try
                {
                    choice = Convert.ToInt32(Console.ReadLine());
                }
                catch (FormatException)
                {
                    Console.Clear();
                    Console.WriteLine("введено не верное значение");
                    continue;
                }

                if (choice < 0 || choice > maxChoise)
                {
                    Console.Clear();
                    Console.WriteLine("введено не верное значение");
                    continue;
                }
                else
                {
                    return choice;
                }
            }
        }

        public static int MainMenu()
        {
            return ChoiseCheck("1 - войти в личный кабинет;\n2 - создать личный кибинет;\n0 - выход.", 2);
        }

        private static void IpMenu(Client client)
        {
            int choise;
            if (client.SearchAFreeElem() == -1)
            {
                string menu = "Выберите счет:\n1 - " + client.getAccountId(0) + "\n2 - " + client.getAccountId(1) + "\n0 - возврат в предидущее меню.";
                choise = ChoiseCheck(menu, 2);
                Console.WriteLine("Баланс: {0}", client.GetDeposit(client.getAccountId(choise--)));
            }
            else if(client.ArrIsEmpty())
            {
                Console.Clear();
                Console.WriteLine("У вас нету ни одного счета.");
            }
            else
            {
                Console.WriteLine("Баланс: {0}", client.GetDeposit(client.getAccountId(0)));
                choise = ChoiseCheck("1 - пополнить счет;\n2 - снять сумму со счета;\n0 - выход.", 2);
            }
            
        }

        public static void ClientMenu(Client client)
        {
            Console.WriteLine("Добрый день {0}!", client.FirstName);

            bool exit = false;
            while (!exit)
            {
                int choise = ChoiseCheck("1 - просмотр баланса, снятие денег/пополнение счета;\n2 - регистрация ИП\n0 - выход в главное меню.", 2);

                switch (choise)
                {
                    case 1:
                        IpMenu(client);
                        break;
                    case 2:
                        int index = client.SearchAFreeElem();
                        if (index == -1)
                        {
                            Console.WriteLine("Достигнуто максимальное количество счетов");
                        }
                        else
                        {
                            if (client.AddAccount(Terminal.RegistrationAccountForm()))
                            {
                                Console.Clear();
                                Console.WriteLine("Регистрация счета прошла успешно, номер:{0}", client.getAccountId(index));
                            }
                            else
                            {
                                Console.WriteLine("Ошибка при регистрации.");
                            }
                        }
                        break;
                    case 0:
                        exit = true;
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
