﻿using System;
using BankLib;

namespace BankSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank bank = new Bank("SUPER_IVAN");
            Console.Title = "SUPER_IVAN";
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("Добро пожаловать в банк \"{0}\"!", bank.Name);

                int choise = Terminal.MainMenu();

                switch (choise)
                {
                    case 0:
                        exit = true;
                        break;
                    case 1:
                        Console.WriteLine("Введите логин:");     
                        string login = Console.ReadLine();

                        Console.WriteLine("Введите пароль:");
                        string passwd = Console.ReadLine();

                        Client client = bank.EnterToClient(login, passwd);

                        if (client == null)
                        {
                            Console.WriteLine("Неверный логин или пароль.");
                        }
                        else
                        {
                            Terminal.ClientMenu(client);
                        }
                        break;
                    case 2:
                        bool check = bank.AddClient(Terminal.RegistrationClientForm());
                        if (check)
                        {
                            Console.Clear();
                            Console.WriteLine("Регистрация прошла успешно!");
                            Console.Read();
                        }
                        //todo: arr is full and null
                        else
                        {
                            Console.WriteLine("!!!");
                        }
                        break;
                    default:
                        Console.Clear();
                        break;
                }
            }
        }
    }
}
