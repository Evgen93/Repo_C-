﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfStopwatch
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DispatcherTimer timer;
        private DateTime startTime;
        private DateTime stopTime;
        private BindingList<string> stringList;
        private NotifyIcon notifyIcon;
        private bool flag;

        public MainWindow()
        {
            InitializeComponent();
            timer = new DispatcherTimer();
            notifyIcon = new NotifyIcon();
            flag = true;
            //notifyIcon.Icon = new Icon(@"C:\Users\st\source\repos\WpfStopwatch\WpfStopwatch\Resources\notify_7560");
            notifyIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(notifyIcon_MouseDoubleClick);
            stringList = new BindingList<string>();
            lsCirle.ItemsSource = stringList;
            timer.Interval = new TimeSpan(0,0,0,0,1);
            timer.Tick += (o, e) => {tbSecond.Text = (stopTime - startTime).ToString(); };
            timer.Tick += timer_tick(object sender, EventArgs e);
        }

        private EventHandler timer_tick(object v, object sender, EventArgs eventArgs, object e)
        {
            throw new NotImplementedException();
        }

        private void notifyIcon_MouseDoubleClick(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            this.WindowState = WindowState.Normal;
        }

        private void btnCircle_Click(object sender, RoutedEventArgs e)
        {
            stringList.Add((stringList.Count + 1).ToString() + "-й круг, время: " + tbSecond.Text);
            startTime = DateTime.Now;
        }

        private void btnStart_Click(object sender, RoutedEventArgs e)
        {
            timer.Start();
            if (flag)
            {
                startTime = DateTime.Now;
                flag = false;
            }
            btnStop.Content = "Стоп";
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            if (timer.IsEnabled)
            {
                timer.Stop();
                btnStop.Content = "Сброс";
            }
            else
            {
                startTime = DateTime.Now;
                tbSecond.Text = "00:00:00:000";
                btnStop.Content = "Старт";
                stringList.Clear();
            }
        }
    }
}
