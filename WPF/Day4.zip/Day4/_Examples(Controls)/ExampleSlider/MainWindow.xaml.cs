﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Xps.Packaging;


namespace ExampleSlider
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            lbValue.Content = String.Format("NewValue={0:N2}, OldValue={1:N2}", e.NewValue, e.OldValue);
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dpBeginDate.SelectedDate = new DateTime(2016,11,15);  // установка начальных значений 
            dpEndDate.SelectedDate = new DateTime(2016, 11, 30);
            calendarMain.SelectionMode = CalendarSelectionMode.MultipleRange; 
            SetDateSelections(calendarMain);
        }

        private void dpBeginDate_CalendarClosed(object sender, RoutedEventArgs e)
        {
            SetDateSelections(calendarMain);
        }

        private void dpEndDate_CalendarClosed(object sender, RoutedEventArgs e)
        {
            SetDateSelections(calendarMain);
        }

       
        private void SetDateSelections(Calendar calendar)
        {
            // выделение диапазона дат
            calendar.SelectedDates.Clear();
            for (DateTime i = dpBeginDate.SelectedDate.Value; i < dpEndDate.SelectedDate.Value; i=i.AddDays(1))
            {
                calendar.SelectedDates.Add(i);
            }

            // выделение диапазона запретных дат
            calendar.BlackoutDates.Add(new CalendarDateRange(dpBeginDate.SelectedDate.Value.AddMonths(1), dpEndDate.SelectedDate.Value.AddMonths(1)));
          }

        private void dpTime_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            lbDateSelect.Content = dpTime.SelectedDate.Value.ToString("dd-MM-yyyy");
            lbDateDisplay.Content = dpTime.DisplayDate.ToString("dd-MM-yyyy");
        }
    }
}
